import {Component, Input} from '@angular/core';
import {ActivityDetails} from "../../models/activity-details.model";

@Component({
    selector: 'activity-item-details',
    templateUrl: 'activity-item-details.html'
})
export class ActivityItemDetailsComponent {

    @Input() activity: ActivityDetails;

    constructor() {
    }

}