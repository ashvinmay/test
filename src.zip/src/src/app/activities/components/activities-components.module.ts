import {NgModule} from '@angular/core';
import {TranslateModule} from '@ngx-translate/core';
import {IonicPageModule} from 'ionic-angular';
import {ActivitiesFilterComponent} from "./activities-filter/activities-filter";
import {ActivityAlertComponent} from "./activity-alert/activity-alert";
import {ActivityItemDetailsComponent} from "./activity-item-details/activity-item-details";
import {ActivityItemComponent} from "./activity-item/activity-item";
import {ActivityListComponent} from "./activity-list/activity-list";
import {LoadingProgressComponent} from "./loading-progress/loading-progress";

@NgModule({
    declarations: [
        ActivitiesFilterComponent,
        ActivityAlertComponent,
        ActivityListComponent,
        ActivityItemComponent,
        ActivityItemDetailsComponent,
        LoadingProgressComponent
    ],
    imports: [
        IonicPageModule.forChild(ActivitiesFilterComponent),
        TranslateModule.forChild()
    ],
    exports: [
        ActivitiesFilterComponent,
        ActivityAlertComponent,
        ActivityListComponent,
        ActivityItemComponent,
        ActivityItemDetailsComponent,
        LoadingProgressComponent
    ]
})
export class ActivitiesComponentsModule {
}