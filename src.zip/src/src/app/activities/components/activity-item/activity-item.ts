import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Activity} from "../../models/activity.model";

@Component({
    selector: 'activity-item',
    templateUrl: 'activity-item.html'
})
export class ActivityItemComponent {

    @Input()
    activity: Activity;

    @Output()
    selectActivity: EventEmitter<Activity> = new EventEmitter<Activity>();

    constructor() {
    }

    public onSelectedActivity(): void {
        this.selectActivity.emit(this.activity);
    }

}