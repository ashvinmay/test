import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ProjectType} from "../../../community/models/project-type.model";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {ALL_COUNTRIES} from "../../../core/models/all.countries";
import {ActivitiesFilter} from "../../models/activities.filter";

@Component({
    selector: 'activities-filter',
    templateUrl: 'activities-filter.html'
})
export class ActivitiesFilterComponent implements OnInit {

    @Input()
    totalActivities: number;
    @Input()
    topics: Array<ProjectType>;
    @Output()
    selectedActivitiesFilter: EventEmitter<ActivitiesFilter> = new EventEmitter<ActivitiesFilter>();

    public allCountries: Array<{ code: string, country: string }>;
    public selectedCountryCode: string;
    public selectedTopicId: number = -1;
    private logger: Logger;
    activitiesFilter: ActivitiesFilter;
    filterBtnDisable: boolean = true;
    filterClearBtnDisable: boolean = true;

    constructor(loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("ActivitiesFilterComponent");
        this.activitiesFilter = new ActivitiesFilter();
        this.countrySetup();
    }

    ngOnInit() {
        this.disableFilterBtn();
    }

    public onClickedFilterActivities() {
        this.logger.debug("selected filter is {}", this.activitiesFilter);
        this.filterBtnDisable = true;
        this.activitiesFilter.resetPage();
        this.selectedActivitiesFilter.emit(this.activitiesFilter);
    }

    public onClickedFilterRemove() {
        this.logger.debug("selected remove filter");
        this.activitiesFilter = new ActivitiesFilter();
        this.selectedActivitiesFilter.emit(this.activitiesFilter);
        setTimeout(() => {
            this.disableFilterBtn();
        }, 100);

    }

    private countrySetup() {
        let anyCountry = [{code: 'ANY', country: 'ACTIVITIES_ANY_COUNTRY'}];
        this.allCountries = anyCountry.concat(ALL_COUNTRIES);
        this.selectedCountryCode = "ANY";
    }

    public customPickerOptionStartDate: any = {
        buttons: [{
            text: 'Clear',
            handler: () => {
                this.activitiesFilter.startDate = null;
            }
        }]
    };

    public customPickerOptionEndDate: any = {
        buttons: [{
            text: 'Clear',
            handler: () => {
                this.activitiesFilter.endDate = null;
            }
        }]
    };

    public enableFilterBtn() {
        this.logger.debug("enableFilterBtn");
        this.filterBtnDisable = false;
        this.filterClearBtnDisable = false;
    }

    private disableFilterBtn() {
        this.logger.debug("disable");
        this.filterBtnDisable = true;
        this.filterClearBtnDisable = true;
    }

}