import {Component, Input} from '@angular/core';
import {ActivityDetails} from "../../models/activity-details.model";

@Component({
    selector: 'activity-alert',
    templateUrl: 'activity-alert.html'
})
export class ActivityAlertComponent {

    @Input() activity: ActivityDetails;

    constructor() {
    }

}