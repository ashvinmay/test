import {ChangeDetectionStrategy, Component, Input} from '@angular/core';

@Component({
  selector: 'loading-progress',
  templateUrl: 'loading-progress.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoadingProgressComponent {

  @Input()
  loading: boolean;

  constructor() {
  }

}
