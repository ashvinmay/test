import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Activity} from "../../models/activity.model";


@Component({
    selector: 'activity-list',
    templateUrl: 'activity-list.html'
})
export class ActivityListComponent {

    @Input()
    activityList: Array<Activity> = [];

    @Output()
    selectActivity: EventEmitter<Activity> = new EventEmitter<Activity>();

    constructor() {
    }

    public onSelectedActivity(activity: Activity): void {
        this.selectActivity.emit(activity);
    }

    trackById(index, item: Activity) {
        return item.id;
    }

}