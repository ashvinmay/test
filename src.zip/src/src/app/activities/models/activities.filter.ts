export class ActivitiesFilter {
  onlyMyActivities: boolean = true;
  page: number = 0;
  country: string = 'ANY';
  topic: number = -1;
  startDate: Date = null;
  endDate: Date = null;

  constructor(data?: any) {
    Object.assign(this, data);
  }

  public nextPage() {
    this.page++;
  }

  public resetPage() {
      this.page = 0;
  }
}
