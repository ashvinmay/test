import {Activity} from "./activity.model";

export class Activities {
    total: number;
    page: number;
    activityList: Array<Activity> = [];

    constructor(data?: any) {
        Object.assign(this, data);
    }

    public concatActivities(activities: Activities): Activities {
        this.activityList = this.activityList.concat(activities.activityList);
        this.page = activities.page;
        return new Activities(this);
    }

}