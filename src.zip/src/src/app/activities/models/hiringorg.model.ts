export class HiringOrg {
    id: string;
    name: string;

    constructor(data?: any) {
        Object.assign(this, data);
    }

}