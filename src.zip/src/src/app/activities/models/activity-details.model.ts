import {HiringOrg} from "./hiringorg.model";
import {JobLocation} from "./joblocation.model";

export class ActivityDetails {
    id: string;
    title: string;
    category: Array<string>;
    description: string;
    accommodation: string;
    training: string;
    datePosted: string;
    startDate: string;
    endDate: string;
    deadline: string;
    weeks: number;
    employmentType: string;
    hiringOrganization: HiringOrg;
    jobLocation: JobLocation;
    volunteerCountries: Array<string>;
    volunteeringProfile: string;
    url: string;
    image: string;
    eligible: boolean;
    ineligibilityMessage: string;

    // Client only fields filled on apply success event
    success: boolean = false;

    constructor(data?: any) {
        Object.assign(this, data);
    }

}