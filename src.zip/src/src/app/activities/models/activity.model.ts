import {HiringOrg} from "./hiringorg.model";
import {JobLocation} from "./joblocation.model";

export class Activity {
    id: string;
    datePosted: string;
    title: string;
    employmentType: string;
    description: string;
    startDate: string;
    endDate: string;
    hiringOrganization: HiringOrg;
    jobLocation: JobLocation;
    category: Array<string>;
    url: string;
    image: string;
    eligible: boolean;

    constructor(data?: any) {
        Object.assign(this, data);
    }

}