export class JobLocation {
    addressStreet: string;
    addressLocality: string;
    addressCountry: string;
    postalCode: string;
    countryName: string;

    constructor(data?: any) {
        Object.assign(this, data);
    }

}