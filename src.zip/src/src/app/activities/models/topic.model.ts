export class Topic {
    id: number;
    idStr: string;
    type: string;

    constructor(data?: any) {
        Object.assign(this, data);
    }

}