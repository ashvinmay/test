import {NgModule} from '@angular/core';
import {TranslateModule} from "@ngx-translate/core";
import {IonicPageModule} from 'ionic-angular';
import {ActivitiesComponentsModule} from "../../components/activities-components.module";
import {ActivitiesStoreModule} from "../../store/activities-store.module";
import {ActivityDetailsPage} from './activity-details';

@NgModule({
    declarations: [
        ActivityDetailsPage,
    ],
    imports: [
        IonicPageModule.forChild(ActivityDetailsPage),
        TranslateModule.forChild(),
        ActivitiesComponentsModule,
        ActivitiesStoreModule
    ],
})
export class ActivityDetailsPageModule {
}
