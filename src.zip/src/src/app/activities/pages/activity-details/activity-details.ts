import {Component, ViewChild} from '@angular/core';
import {Content, IonicPage, Loading, LoadingController, NavController, NavParams} from 'ionic-angular';
import {Observable, Subscription} from "rxjs";
import {AnalyticService} from "../../../core/analytics/analytic.service";
import {ActivitiesFeaturesService} from "../../services/activities-features.service";
import {ActivityDetails} from "../../models/activity-details.model";
import {AlertUtils} from "../../../core/alert-utils";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {TranslateService} from "@ngx-translate/core";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage({
    segment: 'activity-details/:activityId',
})
@Component({
    selector: 'page-activity-details',
    templateUrl: 'activity-details.html',
})
export class ActivityDetailsPage {

    private logger: Logger;

    @ViewChild(Content) content: Content;
    loading: Loading;

    activity$: Observable<ActivityDetails>;
    activityId: string;
    isActivityLoading$: Observable<boolean>;
    subscriptions: Array<Subscription> = [];

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                public alertUtils: AlertUtils,
                public loadingCtrl: LoadingController,
                public translateService: TranslateService,
                private statusBar: StatusBar,
                private activitiesService: ActivitiesFeaturesService,
                loggerFactory: LoggerFactory,
                private analyticService: AnalyticService) {
        this.logger = loggerFactory.getLogger("ActivitiesService");
        this.activityId = this.navParams.get('activityId');
    }

    ionViewDidLoad() {
        this.activity$ = this.activitiesService.selectActivity(this.activityId);
        this.isActivityLoading$ = this.activitiesService.isActivityLoading();
        this.subscriptions.push(this.activity$.subscribe((activity: ActivityDetails) => {
            if (activity && activity.success === true) {
                this.content.scrollToTop();
            }
            if (this.loading) this.loading.dismiss();
        }));
        this.subscriptions.push(this.activitiesService.isActivityError().subscribe((error: boolean) => {
            if (error === true) {
                this.navCtrl.pop();
            }
            if (this.loading) this.loading.dismiss();
        }));
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#154194');
        this.statusBar.styleLightContent();
    }

    ionViewWillUnload() {
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
    }

    apply() {
        this.alertUtils.showConfirmApplyForActivity(() => {
            this.logger.debug("Confirmed apply");
            this.loading = this.loadingCtrl.create({
                content: this.translateService.instant("APPLYING")
            });
            this.loading.present();
            this.trackApplyActivityEvent();
            this.activitiesService.apply(this.activityId);
        });
    }

    private trackApplyActivityEvent() {
        let eventDetails = {
            "activityId": this.activityId
        };
        this.analyticService.trackEvent('ApplyActivity', eventDetails);
    }
}