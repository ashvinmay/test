import {Component, NgZone, ViewChild} from '@angular/core';
import {
    Content, IonicPage, NavController, NavParams, ScrollEvent
} from 'ionic-angular';
import {Observable, Subscription} from "rxjs";
import {AnalyticService} from "../../../core/analytics/analytic.service";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {ActivitiesFilter} from "../../models/activities.filter";
import {Activity} from "../../models/activity.model";
import {Topic} from "../../models/topic.model";
import {ActivitiesFeaturesService} from "../../services/activities-features.service";
import {TopicsFeatureService} from "../../services/topics-feature.service";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-activities',
    templateUrl: 'activities.html',
})
export class ActivitiesPage {
    @ViewChild(Content) content: Content;

    activitiesTopics$: Observable<Array<Topic>>;
    totalActivities$: Observable<number>;
    activityList$: Observable<Array<Activity>>;
    isActivitiesLoading$: Observable<boolean>;
    isMoreActivitiesLoaded$: Observable<boolean>;
    hasMoreActivities$: Observable<boolean>;
    activitiesFilter: ActivitiesFilter;
    subscriptions: Array<Subscription> = [];
    private logger: Logger;
    private loader: any;


    public showScrollTop: boolean = false;
    isScrollTopBtnEnable: boolean = true;

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                public loggerFactory: LoggerFactory,
                private statusBar: StatusBar,
                private activitiesService: ActivitiesFeaturesService,
                private topicService: TopicsFeatureService, public zone: NgZone,  private analyticService: AnalyticService) {

        this.logger = loggerFactory.getLogger("ActivitiesPage");
        this.activitiesFilter = new ActivitiesFilter();
    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad ActivitiesPage');

        this.topicService.loadTopics();
        this.activitiesTopics$ = this.topicService.getTopics();

        this.activitiesService.loadActivities(this.activitiesFilter);
        this.isActivitiesLoading$ = this.activitiesService.isActivitiesLoading();
        this.isMoreActivitiesLoaded$ = this.activitiesService.isMoreActivitiesLoaded();
        this.subscriptions.push(this.isMoreActivitiesLoaded$.subscribe((loaded: boolean) => {
            if (loaded && this.loader) {
                this.loader.complete();
            }
        }));
        this.totalActivities$ = this.activitiesService.getTotal();
        this.activityList$ = this.activitiesService.getActivityList();
        this.hasMoreActivities$ = this.activitiesService.hasMoreActivities();
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#154194');
        this.statusBar.styleLightContent();
    }

    ionViewWillUnload() {
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
    }

    scrollHandler(event: ScrollEvent) {
        // console.log(this.content.isScrolling);
        //console.log(event);
        this.zone.run(() => {
            // since showScrollTop is data-binded,
            // the update needs to happen in zone
            if (event.scrollTop > 600) {
                if (!this.showScrollTop) {
                    setTimeout(() => {
                        this.showScrollTop = true;
                        this.isScrollTopBtnEnable = true;
                    }, 1000);
                }
            } else {
                this.showScrollTop = false;
            }
        });
    }

    public onSelectedActivity(activity: Activity): void {
        this.navCtrl.push("ActivityDetailsPage", {
            activityId: activity.id
        }).then(data => {
            let pageDetails = {
                "activityId" : activity.id
            }
            this.analyticService.trackPageView('ActivityDetailsPage', pageDetails);
        });
    }

    public isOnlyActivitiesSelected(selected: boolean): void {
        this.activitiesFilter.onlyMyActivities = selected;
    }

    public loadMoreActivities(loader) {
        this.loader = loader;
        this.logger.debug('Loading more...');
        this.activitiesFilter.nextPage();
        this.activitiesService.loadMoreActivities(this.activitiesFilter);

    }

    public applyFilter(activitiesFilter: ActivitiesFilter) {
        this.activitiesFilter = activitiesFilter;
        this.activitiesService.loadActivities(activitiesFilter);
    }

    public scrollToTop() {
        this.isScrollTopBtnEnable = false;
        this.content.scrollToTop();
    }

}