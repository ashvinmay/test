import {NgModule} from '@angular/core';
import {TranslateModule} from '@ngx-translate/core';
import {IonicPageModule} from 'ionic-angular';
import {ActivitiesComponentsModule} from "../../components/activities-components.module";
import {ActivitiesStoreModule} from "../../store/activities-store.module";
import {ActivitiesPage} from './activities';

@NgModule({
  declarations: [
    ActivitiesPage,
  ],
  imports: [
    IonicPageModule.forChild(ActivitiesPage),
    TranslateModule.forChild(),
    ActivitiesComponentsModule,
    ActivitiesStoreModule
  ],
})
export class ActivitiesPageModule {}
