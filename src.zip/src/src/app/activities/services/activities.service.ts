import {map} from "rxjs/operators";
import {EnvConfiguration} from "../../../env/env.configuration";
import {ProjectType} from "../../community/models/project-type.model";
import {EscHttp} from "../../core/http/esc-http";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Injectable} from "@angular/core";
import {Observable} from "rxjs/Observable";
import {Activities} from "../models/activities";
import {ActivitiesFilter} from "../models/activities.filter";
import {Activity} from "../models/activity.model";

@Injectable()
export class ActivitiesService {
    private logger: Logger;

    constructor(public escHttp: EscHttp,
                private config: EnvConfiguration,
                loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("ActivitiesService");
    }

    public getActivitiesTopics(): Observable<Array<ProjectType>> {
        this.logger.debug("Get topics for filter activities");
        let url = this.config.activitiesTopicsUrl;
        return this.escHttp.getJson<Array<ProjectType>>(url).map(res => {
            return res;
        });
    }

    public getActivities(activitiesFilter: ActivitiesFilter): Observable<Activities> {
        this.logger.debug("Get activities");
        let url = this.config.activitiesUrl;
        let params = this.buildFilterParams(activitiesFilter);
        return this.escHttp.getJson<Activities>(url, params).pipe(
            map(res => {
                this.logger.debug("Response for activities is {}", res);
                return res;
            })
        );
    }

    public getActivity(activityId: string): Observable<Activity> {
        this.logger.debug("Get activity with id=" + activityId);
        let url = this.config.activityUrl + activityId;
        return this.escHttp.getJson<Activity>(url).pipe(
            map(res => {
                this.logger.debug("Response for activity is {}", res);
                return res;
            })
        );
    }

    public applyActivity(activityId: string): Observable<any> {
        this.logger.debug("Apply activity id=" + activityId);
        let url = this.config.activityUrl + activityId;
        return this.escHttp.postJson<void>(url);
    }

    private buildFilterParams(activitiesFilter: ActivitiesFilter): any {
        let params = {"page": activitiesFilter.page};
        if (activitiesFilter.country !== 'ANY') {
            params["country"] = activitiesFilter.country;
        }
        if (activitiesFilter.topic !== -1) {
            params["topicId"] = activitiesFilter.topic;
        }

        if (activitiesFilter.startDate) {
            params["startDate"] = activitiesFilter.startDate;
        }

        if (activitiesFilter.endDate) {
            params["endDate"] = activitiesFilter.endDate;
        }
       params["eligible"] = activitiesFilter.onlyMyActivities;

        return params;
    }
}
