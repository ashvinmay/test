import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs";
import {Activities} from "../models/activities";
import {ActivitiesFilter} from "../models/activities.filter";
import {Activity} from "../models/activity.model";
import * as ActivitiesStore from '../store/index';
import {ActivityDetails} from "../models/activity-details.model";

@Injectable()
export class ActivitiesFeaturesService {

    constructor(private store: Store<ActivitiesStore.ActivitiesFeature>) {

    }

    public loadActivities(activitiesFilter: ActivitiesFilter) {
        this.store.dispatch(new ActivitiesStore.LoadActivitiesAction(activitiesFilter));
    }

    public loadMoreActivities(activitiesFilter: ActivitiesFilter) {
        this.store.dispatch(new ActivitiesStore.LoadMoreActivitiesAction(activitiesFilter));
    }




    public getActivities(): Observable<Activities> {
        return this.store.select(ActivitiesStore.getActivities);
    }

    public getTotal(): Observable<number> {
        return this.store.select(ActivitiesStore.getTotalActivities);
    }

    public getActivityList(): Observable<Array<Activity>> {
        return this.store.select(ActivitiesStore.getActivityList);
    }

    public isMoreActivitiesLoaded(): Observable<boolean> {
        return this.store.select(ActivitiesStore.isMoreActivitiesLoaded);
    }

    public isActivitiesLoading(): Observable<boolean> {
        return this.store.select(ActivitiesStore.isActivitiesLoading);
    }

    public hasMoreActivities(): Observable<boolean> {
        return this.store.select(ActivitiesStore.hasMoreActivities);
    }

    /**
     * Retrieves activity from the store. If there are no activities
     * then the store will try to retrieve them with a service call.
     * @param {number} activityId id of the activity
     * @returns {Observable<ActivityDetails>} observable with activity when found
     */
    public selectActivity(activityId: string): Observable<ActivityDetails> {
        this.store.dispatch(new ActivitiesStore.GetActivityDetailsAction(activityId));
        return this.store.select(ActivitiesStore.getActivityDetails);
    }

    public isActivityError(): Observable<boolean> {
        return this.store.select(ActivitiesStore.isActivityError);
    }

    public isActivityLoading(): Observable<boolean> {
        return this.store.select(ActivitiesStore.isActivityLoading);
    }

    public apply(activityId: string) {
        this.store.dispatch(new ActivitiesStore.ApplyActivityAction(activityId));
    }

}