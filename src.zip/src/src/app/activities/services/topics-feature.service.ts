import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs";
import {Topic} from "../models/topic.model";
import * as TopicsStore from '../store';

@Injectable()
export class TopicsFeatureService {

  constructor(private store: Store<TopicsStore.ActivitiesFeature>){
  }

  public loadTopics() {
    this.store.dispatch(new TopicsStore.LoadTopicsAction());
  }

  public getTopics(): Observable<Array<Topic>> {
    return this.store.select(TopicsStore.getTopics);
  }
}
