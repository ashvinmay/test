import {createSelector} from "@ngrx/store";
import * as fromActivitiesFeature from "../reducers"
import * as ActivitiesReducer from "../reducers/activities.reducer"

export const getActivitiesState = createSelector(
    fromActivitiesFeature.getFeature,
    (state: fromActivitiesFeature.ActivitiesFeature) => state.activities
);

export const isActivitiesLoading = createSelector(getActivitiesState, ActivitiesReducer.isActivitiesLoading);
export const isMoreActivitiesLoaded = createSelector(getActivitiesState, ActivitiesReducer.isMoreActivitiesLoaded);
export const hasMoreActivities = createSelector(getActivitiesState, ActivitiesReducer.hasMoreActivities);

export const getActivities = createSelector(getActivitiesState, ActivitiesReducer.getActivities);
export const getActivityList = createSelector(getActivitiesState, ActivitiesReducer.getActivityList);
export const getTotalActivities = createSelector(getActivitiesState, ActivitiesReducer.getTotalActivities);

export const isActivityLoading = createSelector(getActivitiesState, ActivitiesReducer.isActivityLoading);
export const isActivityError = createSelector(getActivitiesState, ActivitiesReducer.isActivityError);
export const getActivityDetails = createSelector(getActivitiesState, ActivitiesReducer.getActivityDetails);
