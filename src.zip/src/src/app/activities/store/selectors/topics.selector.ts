import {createSelector} from "@ngrx/store";
import * as fromTopicsFeature from "../reducers"
import * as TopicsReducer from "../reducers/topics.reducer"


export const getTopicsState = createSelector(
  fromTopicsFeature.getFeature,
  (state:fromTopicsFeature.ActivitiesFeature) => state.topics
)

export const isTopicsLoaded = createSelector(getTopicsState, TopicsReducer.isTopicsLoaded);
export const isTopicsLoading = createSelector(getTopicsState, TopicsReducer.isTopicsLoading);
export const getTopics = createSelector(getTopicsState, TopicsReducer.getTopics);
