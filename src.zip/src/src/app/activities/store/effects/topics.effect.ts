import {Injectable} from "@angular/core";
import {Actions, Effect} from "@ngrx/effects";
import {of} from "rxjs/observable/of";
import {catchError, map, switchMap, tap} from "rxjs/operators";
import {AlertUtils} from "../../../core/alert-utils";
import {ActivitiesService} from "../../services/activities.service";
import {LoadTopicsFailAction} from "../actions";
import * as TopicsAction from "../actions/topics.action"
import {Topic} from "../../models/topic.model";

@Injectable()
export class TopicsEffect {

    constructor(private action$: Actions, private activitiesService: ActivitiesService, private alertUtils: AlertUtils) {
    }

    @Effect()
    loadTopics$ = this.action$.ofType(TopicsAction.LOAD_TOPICS)
        .pipe(
            switchMap(() => {
                return this.activitiesService.getActivitiesTopics()
                    .pipe(
                        map((topics: Array<Topic>) => {
                            return new TopicsAction.LoadTopicsSuccessAction(topics)
                        }),
                        catchError(error => of(new TopicsAction.LoadTopicsFailAction(error)))
                    )
            })
        );

    @Effect({dispatch: false})
    showErrors$ = this.action$.ofType(TopicsAction.LOAD_TOPICS_FAIL)
        .pipe(
            tap((action: LoadTopicsFailAction) => {
                if (action.error.status != 304 && action.error.message) {
                    this.alertUtils.showToastAlert(action.error.message, "esc-toast-error")
                }
            })
        );

}