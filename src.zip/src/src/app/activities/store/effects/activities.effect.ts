import {Injectable} from "@angular/core";
import {Actions, Effect} from "@ngrx/effects";
import {of} from "rxjs/observable/of";
import {catchError, map, switchMap, tap} from "rxjs/operators";
import {AlertUtils} from "../../../core/alert-utils";
import {Activities} from "../../models/activities";
import {ActivitiesService} from "../../services/activities.service";
import * as ActivitiesAction from "../actions/activities.action";
import {ActivityDetails} from "../../models/activity-details.model";


@Injectable()
export class ActivitiesEffect {

    constructor(private actions$: Actions,
                private activitiesService: ActivitiesService,
                private alertUtils: AlertUtils) {
    }

    @Effect()
    loadActivities$ = this.actions$.ofType(ActivitiesAction.LOAD_ACTIVITIES)
        .pipe(
            switchMap((action: ActivitiesAction.LoadActivitiesAction) => {
                return this.activitiesService.getActivities(action.payload)
                    .pipe(
                        map((activities: Activities) => {
                            return new ActivitiesAction.LoadActivitiesSuccessAction(activities)
                        }),
                        catchError(error => of(new ActivitiesAction.LoadActivitiesFailAction(error)))
                    )
            })
        );

    @Effect()
    loadMoreActivities$ = this.actions$.ofType(ActivitiesAction.LOAD_MORE_ACTIVITIES)
        .pipe(
            switchMap((action: ActivitiesAction.LoadActivitiesAction) => {
                return this.activitiesService.getActivities(action.payload)
                    .pipe(
                        map((activities: Activities) => {
                            return new ActivitiesAction.LoadMoreActivitiesSuccessAction(activities)
                        }),
                        catchError(error => of(new ActivitiesAction.LoadActivitiesFailAction(error)))
                    )
            })
        );

    @Effect()
    getActivity$ = this.actions$.ofType(ActivitiesAction.GET_ACTIVITY_DETAILS)
        .pipe(
            switchMap((action: ActivitiesAction.GetActivityDetailsAction) => {
                return this.activitiesService.getActivity(action.payload)
                    .pipe(
                        map((result: ActivityDetails) => {
                            return new ActivitiesAction.GetActivityDetailsSuccessAction(result);
                        }),
                        catchError(error => {
                            return of(new ActivitiesAction.GetActivityDetailsFailAction(error))
                        })
                    );
            })
        );

    @Effect()
    applyActivity$ = this.actions$.ofType(ActivitiesAction.APPLY_ACTIVITY)
        .pipe(
            switchMap((action: ActivitiesAction.ApplyActivityAction) => {
                return this.activitiesService.applyActivity(action.payload)
                    .pipe(
                        map(() => {
                            return new ActivitiesAction.ApplyActivitySuccessAction();
                        }),
                        catchError(error => {
                            return of(new ActivitiesAction.ApplyActivityFailAction(error))
                        })
                    );
            })
        );

    @Effect({dispatch: false})
    showCreateErrors$ = this.actions$.ofType(
        ActivitiesAction.APPLY_ACTIVITY_FAIL,
        ActivitiesAction.LOAD_ACTIVITIES_FAIL,
        ActivitiesAction.GET_ACTIVITY_DETAILS_FAIL,
    )
        .pipe(
            tap((action: any) => {
                if (action.payload) {
                    this.alertUtils.showToastAlert(action.payload.message, "esc-toast-error");
                }
            })
        );

}
