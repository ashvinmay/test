import {ActivitiesEffect} from "./activities.effect";
import {TopicsEffect} from "./topics.effect";

export const activitiesEffects: any[] =[ActivitiesEffect, TopicsEffect]

export * from './activities.effect';
export * from './topics.effect'
