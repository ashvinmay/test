import {ActionReducerMap, createFeatureSelector} from "@ngrx/store";
import * as ActivitiesReducer from "./activities.reducer";
import * as TopicsReducer from "./topics.reducer"

export interface ActivitiesFeature {
  activities: ActivitiesReducer.ActivitiesState,
  topics: TopicsReducer.TopicsState
}

export const activityReducers: ActionReducerMap<ActivitiesFeature> = {
  activities: ActivitiesReducer.reducer,
  topics: TopicsReducer.reducer,
};

export const getFeature = createFeatureSelector<ActivitiesFeature>('activities');


