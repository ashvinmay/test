import {Topic} from "../../models/topic.model";
import * as TopicsActions from "../actions/topics.action"


export interface TopicsState {
    topics: Array<Topic>;
    loaded: boolean;
    loading: boolean;
}

export const initialState: TopicsState = {
    topics: [],
    loaded: false,
    loading: false,
};

export function reducer(state = initialState, action: TopicsActions.topicsActions): TopicsState {
    switch (action.type) {
      case TopicsActions.LOAD_TOPICS: {
          return {
            ...state,
            loading: true,
          }
      }
      case TopicsActions.LOAD_TOPICS_SUCCESS: {
          return {
            ...state,
            topics: [{"id":-1, "idStr":"-1", "type":"ACTIVITIES_ANY_TOPIC"}].concat(action.payload),
            loading: false,
            loaded: true
          }
      }
      case TopicsActions.LOAD_TOPICS_FAIL: {
        return {
          ...state,
          loading: false,
          loaded: false
        }
      }
    }
    return state;
}

export const isTopicsLoading = (state: TopicsState) => state.loading;
export const isTopicsLoaded = (state: TopicsState) => state.loaded;
export const getTopics = (state: TopicsState) => state.topics;
