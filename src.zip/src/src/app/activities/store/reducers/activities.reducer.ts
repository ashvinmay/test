import {Activities} from "../../models/activities";
import {ActivitiesFilter} from "../../models/activities.filter";
import * as ActivitiesAction from "../actions/activities.action";
import {ActivityDetails} from "../../models/activity-details.model";


export interface ActivitiesState {
    activities: Activities,
    loading: boolean,
    loaded: boolean,
    loadedMore: boolean
    activitiesFilter?: ActivitiesFilter,
    activityLoading: boolean,
    activityError: boolean,
    activityDetails?: ActivityDetails,
}

export const initialState: ActivitiesState = {
    activities: undefined,
    loading: false,
    loaded: false,
    loadedMore: false,
    activityLoading: false,
    activityError: false
};

export function reducer(state = initialState, action: ActivitiesAction.activitiesAction): ActivitiesState {
    switch (action.type) {
        case ActivitiesAction.LOAD_ACTIVITIES: {
            return {
                ...state,
                loading: true,
                activitiesFilter: action.payload
            }
        }
        case ActivitiesAction.LOAD_MORE_ACTIVITIES: {
            return {
                ...state,
                loadedMore: false,
                activitiesFilter: action.payload
            }
        }
        case ActivitiesAction.LOAD_ACTIVITIES_SUCCESS: {
            const activities = new Activities(action.payload);
            return {
                ...state,
                activities,
                loading: false,
                loaded: true
            }
        }
        case ActivitiesAction.LOAD_MORE_ACTIVITIES_SUCCESS: {
            return {
                ...state,
                activities: moreActivities(state, action.payload),
                loadedMore: true
            }
        }
        case ActivitiesAction.LOAD_ACTIVITIES_FAIL: {
            return {
                ...state,
                loading: false,
                loaded: false
            }
        }
        case ActivitiesAction.GET_ACTIVITY_DETAILS: {
            return {
                ...state,
                activityDetails: undefined,
                activityLoading: true,
                activityError: false
            };
        }
        case ActivitiesAction.GET_ACTIVITY_DETAILS_SUCCESS: {
            return {
                ...state,
                activityDetails: new ActivityDetails(action.payload),
                activityLoading: false,
                activityError: false
            };
        }
        case ActivitiesAction.GET_ACTIVITY_DETAILS_FAIL: {
            return {
                ...state,
                activityDetails: undefined,
                activityLoading: false,
                activityError: true
            };
        }
        case ActivitiesAction.APPLY_ACTIVITY_SUCCESS: {
            return {
                ...state,
                activityDetails: updateActivityDetails(state.activityDetails),
                activityError: false
            };
        }
    }
    return state;
}

export const isActivitiesLoading = (state: ActivitiesState) => state.loading;
export const isActivitiesLoaded = (state: ActivitiesState) => state.loaded;
export const isMoreActivitiesLoaded = (state: ActivitiesState) => state.loadedMore;
export const isActivityLoading = (state: ActivitiesState) => state.activityLoading;
export const isActivityError = (state: ActivitiesState) => state.activityError;

export const getActivityDetails = (state: ActivitiesState) => state.activityDetails;
export const getActivities = (state: ActivitiesState) => state.activities;
export const getTotalActivities = (state: ActivitiesState) => {
    if (state.activities) {
        return state.activities.total;
    }
    return 0;
};
export const getActivityList = (state: ActivitiesState) => {
    if (state.activities) {
        return state.activities.activityList;
    }
    return [];
};
export function moreActivities(state: ActivitiesState, payload: Activities): Activities {
    if (state.activities) {
        return state.activities.concatActivities(payload);
    }
    return new Activities(payload);
}

/**
 * To enable or disable infinite loading
 * @param state
 */
export const hasMoreActivities = (state: ActivitiesState) => {
    if (state.activities) {
        return state.activities.activityList.length < state.activities.total;
    }
    return true;
};

export const updateActivityDetails = (activityDetails: ActivityDetails) => {
    activityDetails.success = true;
    activityDetails.eligible = false;
    return new ActivityDetails(activityDetails)
};