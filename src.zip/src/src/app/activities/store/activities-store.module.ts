import {NgModule} from "@angular/core";
import {EffectsModule} from "@ngrx/effects";
import {StoreModule} from "@ngrx/store";
import {TranslateModule} from "@ngx-translate/core";
import {ActivitiesFeaturesService} from "../services/activities-features.service";
import {ActivitiesService} from "../services/activities.service";
import {TopicsFeatureService} from "../services/topics-feature.service";
import {activitiesEffects} from "./effects";
import {activityReducers} from "./reducers";


@NgModule({
  declarations: [
  ],
  imports: [
    TranslateModule.forChild(),
    StoreModule.forFeature('activities', activityReducers),
    EffectsModule.forFeature(activitiesEffects)
  ],
  providers: [
    ActivitiesFeaturesService,
    TopicsFeatureService,
    ActivitiesService
  ]
})
export class ActivitiesStoreModule {

}
