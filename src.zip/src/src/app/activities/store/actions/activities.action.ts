import {Action} from '@ngrx/store'
import {Activities} from "../../models/activities";
import {ActivitiesFilter} from "../../models/activities.filter";
import {ActivityDetails} from "../../models/activity-details.model";

export const LOAD_ACTIVITIES = "[Activities] Load activities";
export const LOAD_ACTIVITIES_FAIL = "[Activities] Load activities fail";
export const LOAD_ACTIVITIES_SUCCESS = "[Activities] Load activities success";
export const LOAD_MORE_ACTIVITIES = "[Activities] Load more activities";
export const LOAD_MORE_ACTIVITIES_SUCCESS = "[Activities] Load more activities success";
export const GET_ACTIVITY_DETAILS = "[Activities] Get activity details";
export const GET_ACTIVITY_DETAILS_FAIL = "[Activities] Get activity details fail";
export const GET_ACTIVITY_DETAILS_SUCCESS = "[Activities] Get activity details success";
export const APPLY_ACTIVITY = "[Activity] Apply";
export const APPLY_ACTIVITY_SUCCESS = "[Activity] Apply Success";
export const APPLY_ACTIVITY_FAIL = "[Activity] Apply Fail";

export class LoadActivitiesAction implements Action {
    readonly type = LOAD_ACTIVITIES;

    constructor(public payload: ActivitiesFilter){
    }
}

export class LoadMoreActivitiesAction implements Action {
    readonly type = LOAD_MORE_ACTIVITIES;

    constructor(public payload: ActivitiesFilter){
    }
}

export class LoadMoreActivitiesSuccessAction implements Action {
    readonly type = LOAD_MORE_ACTIVITIES_SUCCESS;

    constructor(public payload: Activities){
    }
}

export class LoadActivitiesFailAction implements Action {
    readonly type = LOAD_ACTIVITIES_FAIL;

    constructor(public payload: any) {
    }
}

export class LoadActivitiesSuccessAction implements Action {
    readonly type = LOAD_ACTIVITIES_SUCCESS;

    constructor(public payload: Activities) {
    }
}

export class GetActivityDetailsAction implements Action {
    readonly type = GET_ACTIVITY_DETAILS;

    constructor(public payload: string) {
    }
}

export class GetActivityDetailsFailAction implements Action {
    readonly type = GET_ACTIVITY_DETAILS_FAIL;

    constructor(public payload: string) {
    }
}

export class GetActivityDetailsSuccessAction implements Action {
    readonly type = GET_ACTIVITY_DETAILS_SUCCESS;

    constructor(public payload: ActivityDetails) {
    }
}

export class ApplyActivityAction implements Action {
    readonly type = APPLY_ACTIVITY;

    constructor(public payload: string) {
    }
}

export class ApplyActivitySuccessAction implements Action {
    readonly type = APPLY_ACTIVITY_SUCCESS;

    constructor() {
    }
}

export class ApplyActivityFailAction implements Action {
    readonly type = APPLY_ACTIVITY_FAIL;

    constructor(public payload: string) {
    }
}

// Action types
export type activitiesAction =
    | LoadActivitiesAction
    | LoadActivitiesFailAction
    | LoadActivitiesSuccessAction
    | LoadMoreActivitiesAction
    | LoadMoreActivitiesSuccessAction
    | GetActivityDetailsAction
    | GetActivityDetailsFailAction
    | GetActivityDetailsSuccessAction
    | ApplyActivityAction
    | ApplyActivitySuccessAction
    | ApplyActivityFailAction;
