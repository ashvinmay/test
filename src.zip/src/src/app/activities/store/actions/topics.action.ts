import {Action} from "@ngrx/store"
import {Topic} from "../../models/topic.model";

export const LOAD_TOPICS = "[Topics] Get Topics";
export const LOAD_TOPICS_FAIL = "[Topics] Get Topics Fail";
export const LOAD_TOPICS_SUCCESS = "[Topics] Get Topics Success";

export class LoadTopicsAction implements Action {
  readonly type = LOAD_TOPICS;
}

export class LoadTopicsFailAction implements Action {
  readonly type = LOAD_TOPICS_FAIL;

  constructor(public error: any) {
  }
}

export class LoadTopicsSuccessAction implements Action {
  readonly type = LOAD_TOPICS_SUCCESS;

  constructor(public payload: Array<Topic>) {
  }
}

export type topicsActions = LoadTopicsAction | LoadTopicsFailAction | LoadTopicsSuccessAction;
