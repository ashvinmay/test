import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {PartVPage} from "./part-v";
import {MyProfileToolBarModule} from "../my-profile-tool-bar/my-profile-tool-bar.module";

@NgModule({
    declarations : [
        PartVPage
    ],
    imports : [
        IonicPageModule.forChild(PartVPage),
        TranslateModule.forChild(),
        MyProfileToolBarModule
    ]
})
export class PartVPageModule {}