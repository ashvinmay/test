/**
 * For storing information for PartIV of user profile
 */
export class PartV {
    isProtectingDataPrivacy : boolean;
    isProfileVisibility: boolean;
    isContactNewsLetter: boolean = false;
    isContactTextAlert: boolean = false;
    isContactNotification : boolean = false;

    constructor(data : any) {
       this.isProtectingDataPrivacy = data.isProtectingDataPrivacy;
       this.isProfileVisibility = data.isProfileVisibility;
       this.isContactNewsLetter = data.isContactNewsLetter;
       this.isContactTextAlert = data.isContactTextAlert;
       this.isContactNotification = data.isContactNotification;
    }

}