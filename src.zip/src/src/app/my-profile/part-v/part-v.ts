import {Component, ViewChild} from '@angular/core';
import {IonicPage, NavController, NavParams, Slides} from 'ionic-angular';
import {PartV} from "./part-v.model";
import {MyProfile} from "../my-profile.model";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {FormBuilder, FormGroup} from "@angular/forms";
import {MyProfileCommon} from "../myProfile-common";
import {Subscription} from "rxjs/Subscription";

@IonicPage()
@Component({
    selector: 'page-part-v',
    templateUrl: 'part-v.html'
})
export class PartVPage {

    private partV: PartV;
    private myProfile: MyProfile;
    private logger: Logger;
    private formSubscribe: any;
    myProfilePartVForm: FormGroup;

    @ViewChild(Slides) slides: Slides;
    private subscriptions: Array<Subscription> = [];
    public editMode: boolean = false;

    constructor(public navCtrl: NavController, public navParams: NavParams, loggerFactory: LoggerFactory,
                private formBuilder: FormBuilder, private myProfileCommon : MyProfileCommon) {
        this.logger = loggerFactory.getLogger("PartVPage");
    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad');
        this.subscriptions.push(this.myProfileCommon.subscribeLoadMyProfile().subscribe( myProfile => {
            if (myProfile != null) {
                this.myProfile = myProfile;
                this.partV = this.myProfile.partv;
                this.editMode = this.myProfile.editMode;
                this.createPartVForm();
            }
        }));
        this.subscriptions.push(this.myProfileCommon.getUpdateProfile()
            .subscribe(myProfile => {
                this.myProfile = myProfile;
                this.partV = this.myProfile.partv;
                this.editMode = this.myProfile.editMode;
                this.disableFields();
                this.createPartVForm();
            }));
        this.subscriptions.push(this.myProfileCommon.getCancelEditProfile().subscribe(myProfile => {
            if(myProfile!=null) {
                if(this.formSubscribe) {
                    this.formSubscribe.unsubscribe();

                }
                this.myProfile = myProfile;
                this.partV = this.myProfile.partv;
                this.editMode = this.myProfile.editMode;
                this.disableFields();
                this.createPartVForm();
            }
        }));

        this.subscriptions.push(this.myProfileCommon.getEnableEditProfile().subscribe(myProfile => {
            if(myProfile!=null) {
                if(this.formSubscribe) {
                    this.formSubscribe.unsubscribe();
                }
                this.myProfile = myProfile;
                this.partV = this.myProfile.partv;
                this.editMode = this.myProfile.editMode;
                this.enableFields();
                this.createPartVForm();
            }
        }));
    }

    ionViewWillUnload() {
        // Prevent memory leak when component destroyed
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
        if(this.formSubscribe) {
            this.formSubscribe.unsubscribe();
        }
    }

    private createPartVForm(): void {
        this.myProfilePartVForm = this.formBuilder.group({
            isProfileVisibility: [this.partV.isProfileVisibility],
            isProtectingDataPrivacy: [this.partV.isProtectingDataPrivacy],
            isContactNewsLetter: [this.partV.isContactNewsLetter],
            isContactTextAlert: [this.partV.isContactTextAlert],
            isContactNotification :[this.partV.isContactNotification]
        });
        this.disableFields();

        this.formSubscribe = this.myProfilePartVForm.valueChanges.subscribe(data => {
            this.partV = new PartV(data);
            this.myProfile.partv = this.partV;
            this.myProfileCommon.setTempUpdateProfile(this.myProfile);
        });


    }

    private disableFields(): void {
        if(this.myProfilePartVForm && !this.myProfile.editMode) {
            this.myProfilePartVForm.get('isProfileVisibility').disable();
            this.myProfilePartVForm.get('isProtectingDataPrivacy').disable();
            this.myProfilePartVForm.get('isContactNewsLetter').disable();
            this.myProfilePartVForm.get('isContactTextAlert').disable();
            this.myProfilePartVForm.get('isContactNotification').disable();
        }
    }

    get hasData() {
        return null != this.myProfile;
    }

    private enableFields(): void {
        if(this.myProfilePartVForm) {
            this.myProfilePartVForm.get('isProfileVisibility').enable();
            this.myProfilePartVForm.get('isProtectingDataPrivacy').enable();
            this.myProfilePartVForm.get('isContactNewsLetter').enable();
            this.myProfilePartVForm.get('isContactTextAlert').enable();
            this.myProfilePartVForm.get('isContactNotification').enable();
        }
    }

}