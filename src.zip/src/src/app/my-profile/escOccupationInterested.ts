
export const ESC_OCCUPATION_INTERESTED = [
    "Working with children/young people",

    "Working with the elderly",

    "Working with disabled people",

    "Working with refugees",

    "Working with migrants",

    "Healthcare",

    "Interpreting/translating",

    "Teaching/training/coaching",

    "Catering",

    "Environment/natural protection",

    "Building/construction/engineering",

    "Transport",

    "Arts/music",

    "IT – website/software/infrastructure development",

    "Media/communications/events",

    "Project management",

    "Administration",

    "Physical education and sport"
]