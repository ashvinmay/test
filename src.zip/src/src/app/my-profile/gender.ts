
export const GENDER = [
    {code: 'male'          ,value: 'Male'},
    {code: 'female'          ,value: 'Female'},
    {code: 'other'          ,value: 'Other'}
]