export abstract class AbstractPart {
    protected errors:string[]=[];

    hasErrors(): boolean {
        return this.errors.length > 0;
    }

    addError(error:string) : void {
        this.errors.push(error);
    }

    getErrors() : string[] {
        return this.errors;
    }

    clearErrors() : void {
        this.errors = [];
    }
}