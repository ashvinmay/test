export const ESC_PROJECT_TYPES = [
    "Social challenges",

    "Reception and integration of refugees and migrants",

    "Citizenship and democratic participation",

    "Disaster prevention and recovery",

    "Environment and natural protection",

    "Health and wellbeing",

    "Education and training",

    "Employment and entrepreneurship",

    "Creativity and culture",

    "Physical education and sport",
]