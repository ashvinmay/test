import {Component, ViewChild} from '@angular/core';
import {
    NavController, NavParams, Events, Loading, IonicPage, Tabs, LoadingController
} from 'ionic-angular';
import {MyProfile} from "./my-profile.model";
import 'rxjs/add/operator/map';
import {TranslateService} from "@ngx-translate/core";
import {MyProfileCommon} from "./myProfile-common";
import {LoggerFactory} from "../core/logger/logger-factory";
import {Logger} from "../core/logger/logger";
import {AlertUtils} from "../core/alert-utils";
import "rxjs/add/operator/finally";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-my-profile',
    templateUrl: 'my-profile.html',
})
export class MyProfilePage {
    partI: string;
    partII: string;
    partIII: string;
    partIV: string;
    partV: string;
    myProfile: MyProfile;
    private loading: Loading;
    private logger: Logger;
    @ViewChild(Tabs) tabRef: Tabs;


    constructor(public navCtrl: NavController, public navParams: NavParams,
                public events: Events,
                private translate: TranslateService,
                private alertUtils: AlertUtils,
                private statusBar: StatusBar,
                private myProfileCommon: MyProfileCommon,
                loggerFactory: LoggerFactory,
                private loadingCtrl: LoadingController) {

        this.logger = loggerFactory.getLogger("MyProfilePage");
        this.partI = 'PartIPage';
        this.partII = 'PartIIPage';
        this.partIII = 'PartIIIPage';
        this.partIV = 'PartIVPage';
        this.partV = 'PartVPage';
    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad');
        this.loading = this.loadingCtrl.create({
            content: '<b>' + this.translate.instant('LOADING') + '</b>'
        });
        this.loading.present().then(() => {
            return this.myProfileCommon.getMyProfile().finally(() => {
                this.loading.dismiss();
                })
                .subscribe(
                    (data) => {
                        this.myProfile = data;
                    },
                    (err) => {
                        this.alertUtils.handleGetPostsError(err);
                        this.navCtrl.pop();
                    });
        });
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#660E49');
        this.statusBar.styleLightContent();
    }

    ionViewWillUnload() {
        //this.myProfileCommon.cancelEdit();
        this.myProfileCommon.resetMyProfileOnExit();
    }

    ionViewWillLeave() {
        if(this.tabRef) {
            // Need to use this to go back to first tab
            this.tabRef.select(0);
        }

    }

}