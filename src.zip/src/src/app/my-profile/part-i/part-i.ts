import {Component, ViewChild} from "@angular/core";
import {IonicPage, NavController, NavParams, Slides} from "ionic-angular";
import {PartI} from "./part-i.model";
import {MyProfile} from "../my-profile.model";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {ADDRESS_COUNTRIES} from "../address.countries";
import {NATIONALITY} from "../nationality";
import {ESCPREFERREDCONTACTLANGUAGE} from "../esc-preferred-contact-language";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import * as moment from 'moment';
import {DobValidator} from "./dobValidator";
import {MyProfileCommon} from "../myProfile-common";
import {Subscription} from "rxjs/Subscription";
import {TranslateService} from "@ngx-translate/core";

@IonicPage()
@Component({
    selector: 'page-part-i',
    templateUrl: 'part-i.html'
})
export class PartIPage {
    private logger: Logger;
    private partI: PartI;
    private myProfile: MyProfile;
    languages: Array<{ code: string, language: string }>;
    addressCountries: Array<{ code: string, country: string }>;
    nationalities: Array<{ code: string, nationality: string }>;
    genderOpt: Array<String>;

    genderSelectOption: any;
    countrySelectOption: any;
    nationalitySelectOption: any;
    languageSelectOption: any;
    countryResiSelectOption: any;
    private formSubscribe: any;

    public editMode: boolean = false;
    public cancelTranslation: string ="";

    @ViewChild(Slides) slides: Slides;
    myProfilePartIForm: FormGroup;
    private subscriptions: Array<Subscription> = [];

    constructor(public navCtrl: NavController, public navParams: NavParams,
                loggerFactory: LoggerFactory, private formBuilder: FormBuilder,
                private myProfileCommon: MyProfileCommon,  private translate: TranslateService) {

        this.logger = loggerFactory.getLogger("MyProfile-PartIPage");
        this.logger.debug('constructor');
        this.languages = ESCPREFERREDCONTACTLANGUAGE;
        this.addressCountries = ADDRESS_COUNTRIES;
        this.nationalities = NATIONALITY;
        this.genderOpt = ['male', 'female', 'other'];
        this.cancelTranslation = this.translate.instant("GLOBAL_CANCEL");
    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad');
        this.subscriptions.push(this.myProfileCommon.subscribeLoadMyProfile().subscribe( myProfile => {
            if(myProfile !=null) {
                this.myProfile = myProfile;
                this.partI = this.myProfile.parti;
                this.editMode = this.myProfile.editMode;
                this.createPartIForm();
            }
        }));
        this.subscriptions.push(this.myProfileCommon.getUpdateProfile()
            .subscribe(myProfile => {
                this.myProfile = myProfile;
                this.partI = this.myProfile.parti;
                this.editMode = this.myProfile.editMode;
                this.createPartIForm();
            }));
        this.subscriptions.push(this.myProfileCommon.getCancelEditProfile().subscribe(myProfile => {
            if(myProfile !=null) {
                if(this.formSubscribe) {
                    this.formSubscribe.unsubscribe();
                    this.myProfilePartIForm.reset();
                }
                this.myProfile = myProfile;
                this.partI = this.myProfile.parti;
                this.editMode = this.myProfile.editMode;
                this.createPartIForm();
            }
        }));
        this.subscriptions.push(this.myProfileCommon.getEnableEditProfile().subscribe(myProfile => {
            if(myProfile!=null) {
                if(this.formSubscribe) {
                    this.formSubscribe.unsubscribe();
                }
                this.myProfile = myProfile;
                this.partI= this.myProfile.parti;
                this.editMode = this.myProfile.editMode;
                this.createPartIForm();
            }
        }));
    }

    ionViewWillUnload() {
        console.log("his.subscriptions.forEach( unsubscribe");
        // Prevent memory leak when component destroyed
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
        if(this.formSubscribe) {
            this.formSubscribe.unsubscribe();
        }
        this.myProfile = null;
    }

    get hasData() {
        return null != this.myProfile;
    }

    /**
     * Create form for partI of myprofile
     */
    private createPartIForm(): void {
        let emailRegex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        let dateOfBirth = moment.utc(this.partI.dob, 'DD/MM/YYYY');
        this.myProfilePartIForm = this.formBuilder.group({
            familyName: [this.partI.familyName, Validators.compose([Validators.required])],
            firstName: [this.partI.firstName, Validators.compose([Validators.required])],
            dob: [dateOfBirth.toISOString(), Validators.compose([Validators.required, DobValidator.isValid])],
            gender: [this.partI.gender],
            emailAddress: [this.partI.emailAddress, Validators.compose([Validators.required, Validators.pattern(emailRegex)])],
            preferredContactLang: [this.partI.preferredContactLang],
            countryOfResidence: [this.partI.countryOfResidence],
            nationality: [this.partI.nationality],
            streetAndNumber: [this.partI.streetAndNumber],
            townCity: [this.partI.townCity],
            postCode: [this.partI.postCode],
            telephone: [this.partI.telephone],
            mobilePhone: [this.partI.mobilePhone]
        });

        this.genderSelectOption = {
            title: this.translate.instant('PARTI_GENDER')
        };
        this.countryResiSelectOption = {
            title: this.translate.instant('PARTI_COUNTRY_RESIDENCE')
        };
        this.nationalitySelectOption = {
            title: this.translate.instant('PARTI_NATIONALITY')
        };
        this.languageSelectOption = {
            title: this.translate.instant('PARTI_PCL')
        };
        this.countrySelectOption = {
            title: this.translate.instant('PARTI_COUNTRY')
        };

        this.formSubscribe = this.myProfilePartIForm.valueChanges.subscribe(data => {
            data.dob = moment(data.dob).format('DD/MM/YYYY');
            data.country = data.countryOfResidence;
            this.partI = new PartI(data);
            this.myProfile.parti = this.partI;
            if (this.myProfilePartIForm.invalid) {
                if (this.myProfilePartIForm.get('familyName').hasError('required')) {
                    this.myProfile.parti.addError(this.translate.instant('PARTI_FA_NAME_VALIDATION_MSG'))
                }
                if (this.myProfilePartIForm.get('firstName').hasError('required')) {
                    this.myProfile.parti.addError(this.translate.instant('PARTI_FI_NAME_VALIDATION_MSG'))
                }
                if (this.myProfilePartIForm.get('emailAddress').hasError('pattern')) {
                    this.myProfile.parti.addError(this.translate.instant('PARTI_EMAIL_VALIDATION_MSG'))
                }
                if (this.myProfilePartIForm.get('emailAddress').hasError('required')) {
                    this.myProfile.parti.addError(this.translate.instant('PARTI_EMAIL_REQ_VALIDATION_MSG'))
                }
                if (this.myProfilePartIForm.get('dob').hasError('too young')) {
                    this.myProfile.parti.addError(this.translate.instant('PARTI_AGE_YOUNG_VALIDATION_MSG'))
                }
            }

            this.myProfileCommon.setTempUpdateProfile(this.myProfile);
        });

    }

   /* get editMode() {
        if (this.myProfile === undefined) {
            return false;
        }
        return this.myProfile.editMode;
    }*/

    getLanguage(code: string): string {
        for (let lang of this.languages) {
            if (lang.code == code) {
                return lang.language;
            }
        }
    }

    getCountryLabel(code: string): string {
        for (let country of this.addressCountries) {
            if (country.code == code) {
                return country.country;
            }
        }
    }

    getNationalityLabel(code: string): string {
        for (let nationality of this.nationalities) {
            if (nationality.code == code) {
                return nationality.nationality;
            }
        }
    }
}
