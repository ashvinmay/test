import { FormControl } from '@angular/forms';
import * as moment from 'moment';

export class DobValidator {
    static isValid(control: FormControl): any {
        let minDobAllowed = moment.utc().subtract(17, 'year');
       // let maxDobAllowed = moment.utc().subtract(30, 'year');
        let providedDob = moment.utc(control.value);

        if(providedDob.isAfter(minDobAllowed)) {
            return {
                "too young": true
            };
        }

       /* if(providedDob.isBefore(maxDobAllowed)) {
            return {
                "too old": true
            };
        }*/
        return null;
    }
}