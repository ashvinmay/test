import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {PartIPage} from "./part-i";
import {MyProfileToolBarModule} from "../my-profile-tool-bar/my-profile-tool-bar.module";

@NgModule({
    declarations : [
        PartIPage
    ],
    imports : [
        IonicPageModule.forChild(PartIPage),
        TranslateModule.forChild(),
        MyProfileToolBarModule
    ]
})
export class PartIPageModule {}