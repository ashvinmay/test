/**
 * For storing information for PartI of user profile
 */
import {AbstractPart} from "../AbstractPart.model";

export class PartI extends AbstractPart{
    familyName: string;
    firstName: string;
    dob: string;
    gender: string;
    emailAddress: string;
    preferredContactLang: string;
    countryOfResidence: string;
    nationality: string;
    streetAndNumber: string;
    townCity: string;
    postCode: string;
    telephone: string;
    mobilePhone: string;

    constructor(data : any) {
        super();
        Object.assign(this, data);
    }
}