import {Component, ViewChild} from "@angular/core";
import {IonicPage, NavController, NavParams, Slides} from "ionic-angular";
import {PartIV} from "./part-iv.model";
import {MyProfile} from "../my-profile.model";
import {CONUTRIES_WITH_CODE} from "../../core/models/countries-code";
import {ESC_OCCUPATION_INTERESTED} from "../escOccupationInterested";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {MyProfileCommon} from "../myProfile-common";
import {Subscription} from "rxjs/Subscription";

@IonicPage()
@Component({
    selector: 'page-part-iv',
    templateUrl: 'part-iv.html'
})
export class PartIVPage {

    private partIV: PartIV;
    private myProfile: MyProfile;
    countriesWithCode: Array<{ code: string, country: string, countrywithcode: string }>;
    escOccupationTypes: Array<string>;
    private logger: Logger;

    myProfilePartIVForm: FormGroup;
    private formSubscribe: any;
    public editMode: boolean = false;

    @ViewChild(Slides) slides: Slides;
    private subscriptions: Array<Subscription> = [];

    private isAllCountryCBSelected : boolean = false;

    constructor(public navCtrl: NavController, public navParams: NavParams, loggerFactory: LoggerFactory,
                private formBuilder: FormBuilder, private myProfileCommon : MyProfileCommon) {
        this.logger = loggerFactory.getLogger("PartIVPage");
        this.countriesWithCode = CONUTRIES_WITH_CODE;
        this.escOccupationTypes = ESC_OCCUPATION_INTERESTED;

    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad');
        this.subscriptions.push(this.myProfileCommon.subscribeLoadMyProfile().subscribe( myProfile => {
            if (myProfile != null) {
                this.myProfile = myProfile;
                this.partIV = this.myProfile.partiv;
                this.editMode = this.myProfile.editMode;
                this.createPartIVForm();
            }
        }));
        this.subscriptions.push(this.myProfileCommon.getUpdateProfile()
            .subscribe(myProfile => {
                this.myProfile = myProfile;
                this.partIV = this.myProfile.partiv;
                this.editMode = this.myProfile.editMode;
                this.createPartIVForm();
        }));
        this.subscriptions.push(this.myProfileCommon.getCancelEditProfile().subscribe(myProfile => {
            if(myProfile!=null) {
                if (this.formSubscribe) {
                    this.formSubscribe.unsubscribe();
                    this.myProfilePartIVForm.reset();
                }
                this.myProfile = myProfile;
                this.partIV = this.myProfile.partiv;
                this.editMode = this.myProfile.editMode;
                this.createPartIVForm();
            }
        }));
        this.subscriptions.push(this.myProfileCommon.getEnableEditProfile().subscribe(myProfile => {
            if(myProfile!=null) {
                if(this.formSubscribe) {
                    this.formSubscribe.unsubscribe();
                }
                this.myProfile = myProfile;
                this.partIV= this.myProfile.partiv;
                this.editMode = this.myProfile.editMode;
                this.createPartIVForm();
            }
        }));
    }

    ionViewWillUnload() {
        // Prevent memory leak when component destroyed
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
        if(this.formSubscribe) {
            this.formSubscribe.unsubscribe();
        }
    }

    get hasData() {
        return null != this.myProfile;
    }

    isCountrySelected(country: string): boolean {
        if (this.partIV.countries) {
            for (let countryCode of this.partIV.countries) {
                if (country == countryCode.trim()) {
                    return true;
                }
            }
        }
        return false;
    }

    escOccupationChecked(projectType: string): boolean {
        if (this.partIV.interestedOccupations) {
            for (let project of this.partIV.interestedOccupations) {
                if (projectType == project.trim()) {
                    return true;
                }
            }
        }
        return false;
    }

    hasOtherOccupation(): boolean {
        if (this.partIV.interestedOccupations) {
            for (let interestedOccupation of this.partIV.interestedOccupations) {
                if (this.escOccupationTypes.indexOf(interestedOccupation.trim()) === -1) {
                    return true;
                }
            }
        }
        return false;
    }

    getOtherOccupation(): string {
        if (this.partIV.interestedOccupations) {
            for (let interestedOccupation of this.partIV.interestedOccupations) {
                if (this.escOccupationTypes.indexOf(interestedOccupation.trim()) === -1) {
                    return interestedOccupation;
                }
            }
        }
        //return false;
    }


    private createPartIVForm(): void {
        this.myProfilePartIVForm = this.formBuilder.group({
            isConsiderOccupationalProj: [this.partIV.isConsiderOccupationalProj],
            countries: this.getCountriesFormArray(),
            interestedOccupations: this.getInterestedOccFormArray(),
            reasonToOccupational: [this.partIV.reasonToOccupational, Validators.compose([Validators.maxLength(400)])],
            hasOtherOccupationControl : this.getHasOtherOccupationFormControl(),
            otherOccupation : [this.getOtherOccupation()]

        });

        if (this.editMode) {
            this.formSubscribe = this.myProfilePartIVForm.valueChanges.subscribe(data => {
                data.countries = this.setCountries(data.countries);
                data.interestedOccupations = this.setInterestedOccupationstoModel(data.interestedOccupations);
                if(data.hasOtherOccupationControl) {
                    data.interestedOccupations.push(data.otherOccupation);
                }
                this.partIV = new PartIV(data);
                this.myProfile.partiv = this.partIV;
                this.myProfileCommon.setTempUpdateProfile(this.myProfile);
            });
        }
    }

    private setInterestedOccupationstoModel(dataArray:any) : Array<string> {
        let interestedOccupations: Array<string> =[];
        for(let data of dataArray ) {
            if(data.isChecked) {
                interestedOccupations.push(data.label);
            }
        }
        return interestedOccupations;
    }

    private setCountries(dataArray:any) : Array<string> {
        let countryArray: Array<string> =[];
        for(let data of dataArray ) {
            if(data.isSelected) {
                let countryCode = this.getCountryCode(data.label);
                countryArray.push(countryCode);
            }
        }
        return countryArray;
    }

    private getCountryCode(countryWithCode: string) : string {
        for(let c of this.countriesWithCode) {
            if(countryWithCode === c.countrywithcode) {
                return c.code;
            }
        }
        return "";
    }

    private getHasOtherOccupationFormControl() : FormControl {
        let isDisabled = !this.myProfile.editMode;

        return new FormControl({ value:this.hasOtherOccupation(), disabled: isDisabled})
    }

    private getCountriesFormArray(): FormArray {
        let isDisabled = !this.myProfile.editMode;
        let countryControlArray = this.formBuilder.array(this.countriesWithCode.map((c) => {
            let isSelectedCountry = this.isCountrySelected(c.code);
            return this.formBuilder.group({
                label: new FormControl(c.countrywithcode),
                isSelected: new FormControl({value: isSelectedCountry, disabled: isDisabled})
            });
        }));
        return countryControlArray;
    }

    private getInterestedOccFormArray(): FormArray {
        let isDisabled = !this.myProfile.editMode;

        let intOccControlArray = this.formBuilder.array(this.escOccupationTypes.map((io) => {
            return this.formBuilder.group({
                label: new FormControl(io),
                isChecked: new FormControl({value: this.escOccupationChecked(io), disabled: isDisabled})
            });
        }));
        return intOccControlArray;
    }


  selectAllCountries($event): void {
    let countriesControl = <FormArray> this.myProfilePartIVForm.controls['countries'];
    if (!this.isAllCountryCBSelected) {
      for (let i = 0; i < countriesControl.length; i++) {
        countriesControl.at(i).get('isSelected').setValue(true);
      }
    } else {
      for (let i = 0; i < countriesControl.length; i++) {
        countriesControl.at(i).get('isSelected').setValue(false);
      }
    }
  }

  checkAllSelected(): boolean {
    let countriesControl = <FormArray> this.myProfilePartIVForm.controls['countries'];
    let isAllSelected: boolean = false;
    for (let i = 0; i < countriesControl.length; i++) {
      if (countriesControl.at(i).get('isSelected').value == true) {
        isAllSelected = true;

      } else {
        isAllSelected = false;
        break;
      }
    }
    this.isAllCountryCBSelected = isAllSelected;
    return isAllSelected;
  }



}
