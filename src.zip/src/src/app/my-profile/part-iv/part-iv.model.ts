/**
 * For storing information for PartIV of user profile
 */
export class PartIV {
    isConsiderOccupationalProj : boolean;
    countries: Array<string>;
    interestedOccupations: Array<string>;
    reasonToOccupational: string ="";

    constructor(data : any) {
        Object.assign(this, data);
    }


}