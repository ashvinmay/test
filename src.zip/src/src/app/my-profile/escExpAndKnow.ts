export const ESC_EXP_AND_KNOW = [
    "Working with children/young people",

    "Working with the elderly",

    "Working with disabled people",

    "Working with refugees",

    "Working with migrants",

    "Healthcare",

    "First aid",

    "Interpreting/translating",

    "Teaching/training/coaching",

    "Catering",

    "Environment and natural protection",

    "Building/construction/engineering",

    "Driving",

    "Arts/music",

    "IT – website/software/infrastructure development",

    "Media/communications/events",

    "Project management",

    "Administration",
]
