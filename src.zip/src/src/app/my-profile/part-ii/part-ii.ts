import {Component, ViewChild} from "@angular/core";
import {IonicPage, NavController, NavParams, Slides} from "ionic-angular";
import {PartII} from "./part-ii.model";
import {MyProfile} from "../my-profile.model";
import {ESC_PROJECT_TYPES} from "../escProjectTypes";
import {ESC_EXP_AND_KNOW} from "../escExpAndKnow";
import {ALL_LANGUAGE_WITH_CODE} from "./all-language-with-code";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import * as moment from 'moment';
import {YourAvailability} from "./yourAvailability.model";
import {MyProfileCommon} from "../myProfile-common";
import {Subscription} from "rxjs/Subscription";
import {TranslateService} from "@ngx-translate/core";
import {LanguageAndLevel} from "./languageAndLevel.model";


@IonicPage()
@Component({
    selector: 'page-part-ii',
    templateUrl: 'part-ii.html'
})
export class PartIIPage {
    private partII: PartII;
    private myProfile: MyProfile;
    private escProjectTypes: Array<string>;
    private escExpAndKnow: Array<string>;
    allLanguageWithCode: Array<{ code: string, language: string }>;
    private logger: Logger;
    myProfilePartIIForm: FormGroup;
    private formSubscribe: any;
    allowedCharForEducationSummary: number = 800;
    allowedCharForadditionalInformation: number = 400;
    levelsOfLang: Array<string> = ["native", "advanced", "basic"];
    languageSelectOption: any;
    levelSelectOption: any;
    maxPeriodOption: any;
    periods: Array<number>;
    public editMode: boolean = false;
    public cancelTranslation: string ="";

    @ViewChild(Slides) slides: Slides;
    private subscriptions: Array<Subscription> = [];

    constructor(public navCtrl: NavController, public navParams: NavParams, loggerFactory: LoggerFactory,
                private formBuilder: FormBuilder, private myProfileCommon: MyProfileCommon,  private translate: TranslateService) {
        this.logger = loggerFactory.getLogger("PartIIPage");
        this.escProjectTypes = ESC_PROJECT_TYPES;
        this.escExpAndKnow = ESC_EXP_AND_KNOW;
        this.allLanguageWithCode = ALL_LANGUAGE_WITH_CODE;
        this.periods = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
        this.cancelTranslation = this.translate.instant("GLOBAL_CANCEL");
    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad');
        this.subscriptions.push(this.myProfileCommon.subscribeLoadMyProfile().subscribe( myProfile => {
            if (myProfile != null) {
                this.myProfile = myProfile;
                this.partII = this.myProfile.partii;
                this.editMode = this.myProfile.editMode;
                this.createPartIIForm();
            }
        }));

        this.subscriptions.push(this.myProfileCommon.getUpdateProfile()
            .subscribe(myProfile => {
                this.myProfile = myProfile;
                this.partII = this.myProfile.partii;
                this.editMode = this.myProfile.editMode;
                this.createPartIIForm();
            }));

        this.subscriptions.push(this.myProfileCommon.getCancelEditProfile().subscribe(myProfile => {
            if (myProfile != null) {
                if (this.formSubscribe) {
                    this.formSubscribe.unsubscribe();
                    this.myProfilePartIIForm.reset();
                }
                this.myProfile = myProfile;
                this.partII = this.myProfile.partii;
                this.editMode = this.myProfile.editMode;
                this.createPartIIForm();
            }
        }));

        this.subscriptions.push(this.myProfileCommon.getEnableEditProfile().subscribe(myProfile => {
            if(myProfile!=null) {
                if(this.formSubscribe) {
                    this.formSubscribe.unsubscribe();
                }
                this.myProfile = myProfile;
                this.partII= this.myProfile.partii;
                this.editMode = this.myProfile.editMode;
                this.createPartIIForm();
            }
        }));
    }

    ionViewWillUnload() {
        // Prevent memory leak when component destroyed
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
        if(this.formSubscribe) {
            this.formSubscribe.unsubscribe();
        }
    }

    get hasData() {
        return null != this.myProfile;
    }

    hasLanguage(): boolean {
        if (this.partII.languageAndLevel && this.partII.languageAndLevel.length > 0) {
            return true;
        }
        return false;
    }

    get myCVLink() {
        if(this.partII.escProvCV) {
            return this.partII.escProvCV;
        }
    }

    hasCV(): boolean {
        if(this.partII.escProvCV) {
            return true;
        }
        return false;
    }

    editModeCVMessage(): string {
        return this.translate.instant("PARTIV_NO_CV_EDIT_MODE_MSG");
    }

    showLanguage(code: string): string {
        for (let language of this.allLanguageWithCode) {
            if (code == language.code) {
                return language.language
            }
        }
        return "";
    }

    escProjectChecked(projectType: string): boolean {
        if (this.partII.escProjectTypes) {
            for (let project of this.partII.escProjectTypes) {
                if (projectType == project.trim()) {
                    return true;
                }
            }
        }
        return false;
    }

    escExpKnowChecked(expAndKnow: string): boolean {
        if (this.partII.expAndKnow) {
            for (let expKnow of this.partII.expAndKnow) {
                if (expAndKnow == expKnow.trim()) {
                    return true;
                }
            }
        }
        return false;
    }

    hasOtherKnowAndExp(): boolean {
        if (this.partII.expAndKnow) {
            for (let expKnow of this.partII.expAndKnow) {
                if (this.escExpAndKnow.indexOf(expKnow.trim()) === -1) {
                    return true;
                }
            }
        }
        return false;
    }

    getOtherKnowAndExp(): string {
        if (this.partII.expAndKnow) {
            for (let expKnow of this.partII.expAndKnow) {
                if (this.escExpAndKnow.indexOf(expKnow.trim()) === -1) {
                    return expKnow;
                }
            }
        }
        //return false;
    }

    private createPartIIForm(): void {
        this.myProfilePartIIForm = this.formBuilder.group({
            educationSummary: this.getEducationSummaryCtrl(),
            additionalInformation: this.getAdditionalInformationCtrl(),
            languageAndLevel: this.getLanguageAndLevelFormArray(),
            alwaysAvailable: [this.partII.alwaysAvailable],
            yourAvailability: this.getYourAvailabilityFormArray(),
            escProjectTypes: this.getEscProjectTypeFormArray(),
            expAndKnow: this.getExpAndKnowFormArray(),
            hasOtherExpAndKnowControl: this.getHasOtherKnowAndExpFormControl(),
            otherExpAndKnow: [this.getOtherKnowAndExp()],
            escProvCV: [this.partII.escProvCV]

        });

        this.languageSelectOption = {
            title: this.translate.instant('PARTII_SELECT_LANG_DD')
        };

        this.levelSelectOption = {
            title: this.translate.instant('PARTII_SELECT_LANG_LEVEL_DD')
        };

        this.maxPeriodOption = {
            title: this.translate.instant('PARTII_SELECT_LAP_AMOUNT_DD')
        };


        this.formSubscribe = this.myProfilePartIIForm.valueChanges.subscribe(data => {
            data.yourAvailability = this.setDataYourAvailability(data.yourAvailability, data.alwaysAvailable);
            data.escProjectTypes = this.setEscProjectTypes(data.escProjectTypes);
            data.expAndKnow = this.setEscExpAndKnows(data.expAndKnow);
            if (data.hasOtherExpAndKnowControl) {
                data.expAndKnow.push(data.otherExpAndKnow);
            }
            this.checkLanguageLevel(data.languageAndLevel);
            data.languageAndLevel = this.setLangAndLevel(data.languageAndLevel);
            this.partII = new PartII(data);
            this.myProfile.partii = this.partII;

            if (data.languageAndLevel && data.languageAndLevel.length > 1) {
                for (let i=0 ; i<data.languageAndLevel.length; i++ ) {
                    if ((<FormArray>this.myProfilePartIIForm.controls['languageAndLevel']).at(i).get('lang').hasError('duplicate')) {
                        this.myProfile.partii.addError(this.translate.instant('PARTII_LANG_DUPLICATE_ERROR'))
                        break;
                    }
                }
                for (let i=0 ; i<data.languageAndLevel.length; i++ ) {
                    if ((<FormArray>this.myProfilePartIIForm.controls['languageAndLevel']).at(i).get('level').hasError('emptyLevel')) {
                        this.myProfile.partii.addError(this.translate.instant('PARTII_LANG_LEVEL_MISSING_ERROR'))
                        break;
                    }
                }
            }
            this.myProfileCommon.setTempUpdateProfile(this.myProfile);
        });

    }


    private setLangAndLevel(langandLevels: LanguageAndLevel[]): LanguageAndLevel[] {
        let langLevelArray: LanguageAndLevel[] =[];
        if(langandLevels.length > 0) {
            for(let langLevel of langandLevels) {
                if(langLevel.lang == '' && langLevel.level == '') {

                } else {
                    langLevelArray.push(langLevel)
                }
            }
            return langLevelArray;
        }
        return null;
    }

    private getEducationSummaryCtrl(): FormControl {
        if (this.partII.educationSummary == null) {
            return this.formBuilder.control('');
        } else {
            return this.formBuilder.control(this.partII.educationSummary);
        }
    }

    private getAdditionalInformationCtrl(): FormControl {
        if (this.partII.additionalInformation == null) {
            return this.formBuilder.control('');
        }
        return this.formBuilder.control(this.partII.additionalInformation);

    }

    private setEscProjectTypes(dataArray: any): Array<string> {
        let escProjectTypes: Array<string> = [];
        for (let data of dataArray) {
            if (data.isChecked) {
                escProjectTypes.push(data.label);
            }
        }
        return escProjectTypes;
    }

    private setEscExpAndKnows(dataArray: any): Array<string> {
        let expAndKnows: Array<string> = [];
        for (let data of dataArray) {
            if (data.isChecked) {
                expAndKnows.push(data.label);
            }
        }
        return expAndKnows;
    }

    private checkLanguageLevel(langandLevels: LanguageAndLevel[]): void {
        if (langandLevels.length > 1) {
            let duplicatesIndex: Array<number> = [];
            langandLevels.reduce(function (allLanguage, langNLevel, currentIndex) {
                if (langNLevel.lang in allLanguage) {
                    allLanguage[langNLevel.lang]++;
                    duplicatesIndex.push(currentIndex);
                } else {
                    allLanguage[langNLevel.lang] = 1;
                }
                return allLanguage;
            }, {});
            if (duplicatesIndex.length > 0) {
                let control = <FormArray>this.myProfilePartIIForm.controls['languageAndLevel'];
                for(let i of duplicatesIndex) {
                    control.at(i).markAsPristine();
                    control.at(i).get("lang").setErrors({"duplicate":true});

                }
            }
        }
        if(langandLevels) {
            let langLevelFormControl = <FormArray>this.myProfilePartIIForm.controls['languageAndLevel'];
            for(let i=0 ; i<langandLevels.length ; i++) {
                if(langLevelFormControl.at(i).get("lang").value != '' && langLevelFormControl.at(i).get("level").value == ''){
                    langLevelFormControl.at(i).markAsPristine();
                    let control = langLevelFormControl.at(i).get('level');
                    control.setErrors({"emptyLevel":true});
                }
            }
        }


    }

    private setDataYourAvailability(availabilities: YourAvailability[], alwaysAvailable: boolean): YourAvailability[] {
        if(availabilities.length >0 &&  !alwaysAvailable){
            let yourAvailabilityAfterChange: YourAvailability[] = [];
            for (let yourAva of availabilities) {
                if(yourAva.from && yourAva.to) {
                    let lapAmount = yourAva.lapAmount;
                    let lapType = yourAva.lapType;
                    let from = moment(yourAva.from).format('DD/MM/YYYY');
                    let to = moment(yourAva.to).format('DD/MM/YYYY');
                    yourAvailabilityAfterChange.push(new YourAvailability(from, to, lapAmount, lapType));
                }
            }
            return yourAvailabilityAfterChange;
        }
        return null;

    }

   /* private getIsAvailableAnyTime(): boolean {
        return !this.partII.yourAvailability;

    }*/

    private getHasOtherKnowAndExpFormControl(): FormControl {
        let isDisabled = !this.myProfile.editMode;

        return new FormControl({value: this.hasOtherKnowAndExp(), disabled: isDisabled})
    }

    private getEscProjectTypeFormArray(): FormArray {
        let isDisabled = !this.myProfile.editMode;
        let projectTypeControlArray = this.formBuilder.array(this.escProjectTypes.map((pt) => {
            let isProjectTypeChecked = this.escProjectChecked(pt);
            return this.formBuilder.group({
                label: new FormControl(pt),
                isChecked: new FormControl({value: isProjectTypeChecked, disabled: isDisabled})
            });
        }));
        return projectTypeControlArray;
    }

    private getExpAndKnowFormArray(): FormArray {
        let isDisabled = !this.myProfile.editMode;
        let expAndKnowControlArray = this.formBuilder.array(this.escExpAndKnow.map((ek) => {
            let isExpAndKnowChecked = this.escExpKnowChecked(ek);
            return this.formBuilder.group({
                label: new FormControl(ek),
                isChecked: new FormControl({value: isExpAndKnowChecked, disabled: isDisabled})
            });
        }));
        return expAndKnowControlArray;
    }

    private getYourAvailabilityFormArray(): FormArray {
        let yourAvailabilityControlArray = this.formBuilder.array([]);
        if (this.partII.yourAvailability != null) {
            this.partII.yourAvailability.forEach((yourAva: any) => {
                let yourAvaFrom = moment.utc(yourAva.from, 'DD/MM/YYYY');
                let yourAvaTo = moment.utc(yourAva.to, 'DD/MM/YYYY');
                let yourAvailGroup = this.formBuilder.group({
                    from: new FormControl(yourAvaFrom.toISOString()),
                    to: new FormControl(yourAvaTo.toISOString()),
                    lapAmount: new FormControl(yourAva.lapAmount),
                    lapType: new FormControl(yourAva.lapType)
                });
                yourAvailabilityControlArray.push(yourAvailGroup)
            });
        }
        return yourAvailabilityControlArray;
    }

    initYourAvailability() {
        // initialize our YourAvailability
        return this.formBuilder.group({
            from: new FormControl('', Validators.required),
            to: new FormControl('',Validators.required),
            lapAmount: new FormControl(Validators.required),
            lapType: new FormControl('m')
        });
    }

    addYourAvailability() {
        // add yourAvailability to the list
        const control = <FormArray>this.myProfilePartIIForm.controls['yourAvailability'];
        control.push(this.initYourAvailability());
    }

    removeYourAvailability(i: number) {
        // remove your availability from the list
        const control = <FormArray>this.myProfilePartIIForm.controls['yourAvailability'];
        control.removeAt(i);
    }

    changeAvailableAnyTime(event: any): void {
        if(this.myProfilePartIIForm.controls['alwaysAvailable'].value === false) {
            const control = <FormArray>this.myProfilePartIIForm.controls['yourAvailability'];
            control.push(this.initYourAvailability());
        } else {
            this.myProfilePartIIForm.controls['yourAvailability'] = this.formBuilder.array([])
        }
    }

    private getLanguageAndLevelFormArray(): FormArray {
        let languageAndLevelControlArray = this.formBuilder.array([]);
        if (this.partII.languageAndLevel != null) {
            this.partII.languageAndLevel.forEach((lal :any) => {
                let lalGroup = this.formBuilder.group({
                    lang: new FormControl(lal.lang),
                    level: new FormControl(lal.level)
                });
                languageAndLevelControlArray.push(lalGroup)
            });
        }
        return languageAndLevelControlArray;
    }

    initLanguageAndLevel() {
        // initialize our LanguageAndLevel
        return this.formBuilder.group({
            lang: new FormControl(''),
            level: new FormControl('')
        });
    }

    addLanguageAndLevel() {
        const control = <FormArray>this.myProfilePartIIForm.controls['languageAndLevel'];
        control.push(this.initLanguageAndLevel());
    }

    removeLanguageAndLevel(i: number) {
        // remove languageAndLevel from the list
        const control = <FormArray>this.myProfilePartIIForm.controls['languageAndLevel'];
        control.removeAt(i);
    }

}


