import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {PartIIPage} from "./part-ii";
import {MyProfileToolBarModule} from "../my-profile-tool-bar/my-profile-tool-bar.module";
import {ElasticModule} from "angular2-elastic";

@NgModule({
    declarations : [
        PartIIPage
    ],
    imports : [
        ElasticModule,
        IonicPageModule.forChild(PartIIPage),
        TranslateModule.forChild(),
        MyProfileToolBarModule
    ]
})
export class PartIIPageModule {}