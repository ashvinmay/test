/**
 * For storing information for your availability
 */
export class YourAvailability {

    from: string;
    to: string;
    lapAmount: string;
    lapType: string = 'm';

    constructor(from: string, to: string, lapAmount: string, lapType: string) {
        this.from = from;
        this.to = to;
        this.lapAmount = lapAmount;
        this.lapType = lapType;
    }
}