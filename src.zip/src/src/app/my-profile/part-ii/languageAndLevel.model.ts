/**
 * For storing information for language and level
 */
export interface LanguageAndLevel {
    lang: string;
    level: string;
}