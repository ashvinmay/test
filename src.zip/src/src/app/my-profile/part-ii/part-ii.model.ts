import {LanguageAndLevel} from "./languageAndLevel.model";
import {YourAvailability} from "./yourAvailability.model";
import {AbstractPart} from "../AbstractPart.model";
/**
 * For storing information for PartII of user profile
 */
export class PartII extends AbstractPart {
    educationSummary : string;
    additionalInformation : string;
    alwaysAvailable : boolean;
    languageAndLevel : LanguageAndLevel[];
    yourAvailability : YourAvailability[];
    escProjectTypes : Array<string>;
    expAndKnow : Array<string>;
    escProvCV:string = null;

    constructor(data : any) {
        super();
        this.educationSummary = data.educationSummary;
        this.additionalInformation = data.additionalInformation;
        this.alwaysAvailable = data.alwaysAvailable;
        this.languageAndLevel = data.languageAndLevel;
        this.yourAvailability = data.yourAvailability;
        this.escProjectTypes = data.escProjectTypes;
        this.expAndKnow = data.expAndKnow;
        this.escProvCV = data.escProvCV;
    }
}
