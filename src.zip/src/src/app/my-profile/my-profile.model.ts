import {PartV} from "./part-v/part-v.model";
import {PartIV} from "./part-iv/part-iv.model";
import {PartIII} from "./part-iii/part-iii.model";
import {PartII} from "./part-ii/part-ii.model";
import {PartI} from "./part-i/part-i.model";
/**
 * For storing information of user profile
 */
export class MyProfile {
    editMode:boolean;
    userId : number;
    version: number;
    lastModificationDate:number;
    structVersion: string;
    parti: PartI;
    partii: PartII;
    partiii:PartIII;
    partiv:PartIV;
    partv:PartV;
    prn:string;
    hasAcceptedOffer:boolean;
    escMissionAgree:boolean;
    escPrivacy:boolean;
    escTermsConditions:boolean;

    constructor(data : any) {
        this.editMode = false;
        this.userId = data.userId;
        this.version = data.version;
        this.lastModificationDate = data.lastModificationDate;
        this.structVersion = data.structVersion;
        this.prn = data.prn;
        this.hasAcceptedOffer = data.hasAcceptedOffer;
        this.escMissionAgree = data.escMissionAgree;
        this.escPrivacy = data.escPrivacy;
        this.escTermsConditions = data.escTermsConditions;
        this.parti = new PartI(data.parti);
        this.partii = new PartII(data.partii);
        this.partiii = new PartIII(data.partiii);
        this.partiv = new PartIV(data.partiv);
        this.partv = new PartV(data.partv);
    }

}