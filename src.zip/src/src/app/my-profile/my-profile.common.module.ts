import {MyProfileCommon} from "./myProfile-common";
import {MyProfileService} from "./my-profile.service";
import {NgModule} from "@angular/core";
import {TranslateModule} from "@ngx-translate/core";
import {CommonModule} from "@angular/common";

@NgModule({
    declarations: [
    ],
    imports: [
        CommonModule,
        TranslateModule.forChild()
   ],
    exports: [
    ],
    providers: [MyProfileService, MyProfileCommon]
})
export class MyProfileCommonModule {
}
