import {Injectable} from "@angular/core";
import {Observable} from "rxjs/Rx";
import "rxjs/add/operator/map";
import {MyProfile} from "./my-profile.model";
import {Logger} from "../core/logger/logger";
import {LoggerFactory} from "../core/logger/logger-factory";
import {EscHttp} from "../core/http/esc-http";
import {EnvConfiguration} from "../../env/env.configuration";

@Injectable()
export class MyProfileService {
    private logger: Logger;
    private myProfile: MyProfile;

    constructor(public authHttp: EscHttp, private config: EnvConfiguration,
                loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("MyProfileService");
    }

    public getMyProfile(): Observable<MyProfile> {
        let url = this.config.myProfileUrl;
        return this.authHttp.getJson<any>(url)
            .map(res => {
                this.myProfile = new MyProfile(res);
                this.logger.debug("My Profile\n:", this.myProfile)
                return this.myProfile;
            });
    }

    public updateMyProfile(tempUpdateProfile: MyProfile) : Observable<MyProfile> {
            let myProfileJson = tempUpdateProfile;
            return this.authHttp.postJson<any>(this.config.myProfileUrl, myProfileJson)
                .map(res => {
                    this.myProfile = new MyProfile(res);
                    console.log("My Profile\n:", this.myProfile)
                    return this.myProfile;
                });
    }

}
