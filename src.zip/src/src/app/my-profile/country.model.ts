/**
 * For storing information for PartIII Country of user profile
 */
export interface Country {
    label: string;
    isSelected: boolean;
}