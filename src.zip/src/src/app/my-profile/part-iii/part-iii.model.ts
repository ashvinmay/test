/**
 * For storing information for PartIII of user profile
 */
export class PartIII {
    isConsiderVolunteeringProj : boolean;
    countries: Array<string>
    previouslyPlaced: string;
    prevPlacedDuration: string;
    prevPlacedSummary: string = "";
    reasonToVolunteer: string = "";

    constructor(data : any) {
        Object.assign(this, data);
    }
}