import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {PartIIIPage} from "./part-iii";
import {MyProfileToolBarModule} from "../my-profile-tool-bar/my-profile-tool-bar.module";
import {ElasticModule} from "angular2-elastic";

@NgModule({
    declarations : [
        PartIIIPage
    ],
    imports : [
        ElasticModule,
        IonicPageModule.forChild(PartIIIPage),
        TranslateModule.forChild(),
        MyProfileToolBarModule
    ]
})
export class PartIIIPageModule {}