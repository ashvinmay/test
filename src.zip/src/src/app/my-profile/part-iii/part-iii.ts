import {Component, ViewChild} from "@angular/core";
import {IonicPage, NavController, NavParams, Slides} from "ionic-angular";
import {PartIII} from "./part-iii.model";
import {MyProfile} from "../my-profile.model";
import {CONUTRIES_WITH_CODE} from "../../core/models/countries-code";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {MyProfileCommon} from "../myProfile-common";
import {Subscription} from "rxjs/Subscription";

@IonicPage()
@Component({
    selector: 'page-part-iii',
    templateUrl: 'part-iii.html'
})
export class PartIIIPage {

    private partIII: PartIII;
    private myProfile: MyProfile;

    countriesWithCode: Array<{ code: string, country: string, countrywithcode: string }>;

    private formSubscribe: any;
    private durations: Array<number> = [];
    durationSelectOption: any;
    myProfilePartIIIForm: FormGroup;

    private logger: Logger;
    public editMode: boolean = false;

    @ViewChild(Slides) slides: Slides;
    private subscriptions: Array<Subscription> = [];

    private isAllCountryCBSelected : boolean = false;

    constructor(public navCtrl: NavController, public navParams: NavParams, loggerFactory: LoggerFactory,
                private formBuilder: FormBuilder, private myProfileCommon : MyProfileCommon) {
        this.logger = loggerFactory.getLogger("PartIIIPage");
        this.countriesWithCode = CONUTRIES_WITH_CODE;
    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad');
        this.subscriptions.push(this.myProfileCommon.subscribeLoadMyProfile().subscribe( myProfile => {
            if (myProfile != null) {
                this.myProfile = myProfile;
                this.partIII = this.myProfile.partiii;
                this.editMode = this.myProfile.editMode;
                this.createPartIIIForm();
            }
        }));
        this.subscriptions.push(this.myProfileCommon.getUpdateProfile()
            .subscribe(myProfile => {
                this.myProfile = myProfile;
                this.partIII = this.myProfile.partiii;
                this.editMode = this.myProfile.editMode;
                this.createPartIIIForm();
            }));
        this.subscriptions.push(this.myProfileCommon.getCancelEditProfile().subscribe(myProfile => {
            if(myProfile!=null) {
                if (this.formSubscribe) {
                    this.formSubscribe.unsubscribe();
                    this.myProfilePartIIIForm.reset();
                }
                this.myProfile = myProfile;
                this.partIII = this.myProfile.partiii;
                this.editMode = this.myProfile.editMode;
                if(this.myProfilePartIIIForm) {
                    this.myProfilePartIIIForm.get('isConsiderVolunteeringProj').disable();
                }
                this.createPartIIIForm();
            }
        }));

        this.subscriptions.push(this.myProfileCommon.getEnableEditProfile().subscribe(myProfile => {
            if(myProfile!=null) {
                if(this.formSubscribe) {
                    this.formSubscribe.unsubscribe();
                }
                this.myProfile = myProfile;
                this.partIII= this.myProfile.partiii;
                this.editMode = this.myProfile.editMode;
                if(this.myProfilePartIIIForm) {
                    this.myProfilePartIIIForm.get('isConsiderVolunteeringProj').enable();
                }
                this.createPartIIIForm();
            }
        }));
        this.buildDurationOptions();
    }

    ionViewWillUnload() {
        // Prevent memory leak when component destroyed
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
        if(this.formSubscribe) {
            this.formSubscribe.unsubscribe();
        }
    }

    get hasData() {
        return null != this.myProfile;
    }

    private isPreviouslyParticipated(): boolean {
        if (this.partIII.previouslyPlaced && this.partIII.previouslyPlaced == "yes") {
            return true;
        }
        return false;
    }

    isCountrySelected(code: string): boolean {
        if (this.partIII.countries) {
            for (let countryCode of this.partIII.countries) {
                if (code == countryCode) {
                    return true;
                }
            }
        }
        return false;
    }


    private createPartIIIForm(): void {
        let isDisabled = !this.myProfile.editMode;
        this.myProfilePartIIIForm = this.formBuilder.group({
            isConsiderVolunteeringProj: this.formBuilder.control({value:this.partIII.isConsiderVolunteeringProj, disabled: isDisabled}),
            countries: this.getCountriesFormArray(),
            previouslyPlaced: [this.isPreviouslyParticipated()],
            prevPlacedDuration: [this.partIII.prevPlacedDuration],
            prevPlacedSummary: [this.partIII.prevPlacedSummary.slice(0, 400), Validators.compose([Validators.maxLength(400)])],
            reasonToVolunteer: [this.partIII.reasonToVolunteer.slice(0, 400), Validators.compose([Validators.maxLength(400)])]
        });

        this.durationSelectOption = {
            title: 'Duration'
        };

        if (this.editMode) {
            this.formSubscribe = this.myProfilePartIIIForm.valueChanges.subscribe(data => {
                data.countries = this.setCountries(data.countries);
                data.previouslyPlaced = this.setIsPreviouslyPlaced(data.previouslyPlaced);
                data.prevPlacedDuration = data.previouslyPlaced == 'yes' ? data.prevPlacedDuration : null;
                this.partIII = new PartIII(data);
                this.myProfile.partiii = this.partIII;
                this.myProfileCommon.setTempUpdateProfile(this.myProfile);
            });
        }
    }

    private setCountries(dataArray:any) : Array<string> {
        let countryArray: Array<string> =[];
        for(let data of dataArray ) {
            if(data.isSelected) {
                let countryCode = this.getCountryCode(data.label);
                countryArray.push(countryCode);
            }
        }
        return countryArray;
    }

    private setIsPreviouslyPlaced(previouslyPlaced :boolean) :string {
        if(previouslyPlaced) {
            return "yes";
        }
        return "no";
    }

    private getCountryCode(countryWithCode: string) : string {
        for(let c of this.countriesWithCode) {
            if(countryWithCode === c.countrywithcode) {
                return c.code;
            }
        }
        return "";
    }

    private getCountriesFormArray(): FormArray {
        let isDisabled = !this.myProfile.editMode;

        let countryControlArray = this.formBuilder.array(this.countriesWithCode.map((c) => {
            let isSelectedCountry = this.isCountrySelected(c.code);
            return this.formBuilder.group({
                label: new FormControl(c.countrywithcode),
                isSelected: new FormControl({value: isSelectedCountry, disabled: isDisabled})
            });
        }));
        return countryControlArray;
    }

    private buildDurationOptions(): void {
        for (let i = 2; i <= 53; i++) {
            this.durations.push(i);
        }
    }

    selectAllCountries($event): void {
        let countriesControl = <FormArray> this.myProfilePartIIIForm.controls['countries'];
        if (!this.isAllCountryCBSelected) {
            for (let i = 0; i < countriesControl.length; i++) {
                countriesControl.at(i).get('isSelected').setValue(true);
            }
        } else {
            for (let i = 0; i < countriesControl.length; i++) {
                countriesControl.at(i).get('isSelected').setValue(false);
            }
        }
    }

    checkAllSelected(): boolean {
      let countriesControl = <FormArray> this.myProfilePartIIIForm.controls['countries'];
      let isAllSelected: boolean = false;
      for (let i = 0; i < countriesControl.length; i++) {
        if (countriesControl.at(i).get('isSelected').value == true) {
          isAllSelected = true;

        } else {
          isAllSelected = false;
          break;
        }
      }
      this.isAllCountryCBSelected = isAllSelected;
      return isAllSelected;
    }

}
