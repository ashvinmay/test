import {LoadingController,  Loading} from "ionic-angular";
import { ToastController } from 'ionic-angular';
import { Injectable } from '@angular/core';
import {LoggerFactory} from "../core/logger/logger-factory";
import {Logger} from "../core/logger/logger";
import {MyProfileService} from "./my-profile.service";
import {MyProfile} from "./my-profile.model";
import {Subject} from "rxjs/Subject";
import {TranslateService} from "@ngx-translate/core";
import {Observable} from "rxjs/Observable";
import {BehaviorSubject} from "rxjs/BehaviorSubject";

@Injectable()
export class    MyProfileCommon {

    private logger: Logger;
    private saveProfileSubject = new Subject<MyProfile>();
    private loadProfileSubject = new BehaviorSubject<MyProfile>(null);
    private cancelEditSubject = new BehaviorSubject<MyProfile>(null);
    private enableEditSubject = new BehaviorSubject<MyProfile>(null);
    private loading: Loading;
    private myProfile : MyProfile;
    private tempUpdateProfile: MyProfile;

    constructor(private loadingCtrl: LoadingController,
                private toastCtrl: ToastController, private translate: TranslateService,
                loggerFactory: LoggerFactory, private myProfileService: MyProfileService) {
        this.logger = loggerFactory.getLogger("MyProfileCommon");
    }

    public getMyProfile(): Observable<MyProfile> {
        return this.myProfileService.getMyProfile().map((data) => {
            this.myProfile = data;
            this.logger.debug("My Profile\n:", this.myProfile)
            this.loadProfileSubject.next(this.myProfile);
            return this.myProfile;
        });
    }

    public subscribeLoadMyProfile(): Observable<MyProfile> {
           return this.loadProfileSubject.asObservable();
    }

    public saveProfile() {
        this.logger.debug("Save profile\n:", this.tempUpdateProfile)
        if(this.hasErrors()) {
            let message: string = '';
            for (let errorMsg of this.getMyProfileErrors()) {
                message += errorMsg + '\n';
            }
            this.showErrors(message);
        } else {
            this.loading = this.loadingCtrl.create({
                content: '<b>' + this.translate.instant('LOADING') + '</b>'
            });
            this.loading.present().then(() => {
                return this.myProfileService.updateMyProfile(this.tempUpdateProfile).subscribe(
                    (data) => {
                        this.tempUpdateProfile.editMode=false;
                        this.clearMyProfileErrors();
                        this.myProfile = data;
                        this.myProfile.editMode=false;
                        this.saveProfileSubject.next(this.myProfile);
                        this.loading.dismiss();
                    },
                    (err) => {
                        this.loading.dismiss();
                        if(err.errorDetails.length > 0) {
                            let errorMessage = "";
                            for(let error of err.errorDetails) {
                                errorMessage = errorMessage + '\n' + error.issue;
                            }
                            this.showErrors(errorMessage);
                        } else {

                            this.showErrors(err.message);
                        }
                    });
            });

        }
    }

    public cancelEdit() {
        console.log("My profile common cancel edit");
        this.myProfile.editMode=false;
        let cancelledMyProfile = new MyProfile(this.myProfile)
        cancelledMyProfile.editMode = false;
        this.tempUpdateProfile = cancelledMyProfile;
        this.cancelEditSubject.next(cancelledMyProfile);
        this.enableEditSubject.next(cancelledMyProfile);
    }

    public enableEdit() {
        this.myProfile.editMode=true;
        let editMyProfile = new MyProfile(this.myProfile)
        editMyProfile.editMode = true;
        this.tempUpdateProfile = editMyProfile;
        this.enableEditSubject.next(editMyProfile);
    }

    public getUpdateProfile(): Observable<MyProfile> {
        return this.saveProfileSubject.asObservable();
    }

    public getCancelEditProfile(): Observable<MyProfile> {
        return this.cancelEditSubject.asObservable();
    }

    public getEnableEditProfile(): Observable<MyProfile> {
        return this.enableEditSubject.asObservable();
    }

    public setTempUpdateProfile(myTempProfile: MyProfile) {
        this.tempUpdateProfile = myTempProfile;
    }

    public resetMyProfileOnExit() {
        this.myProfile = null;
        this.cancelEditSubject.next(this.myProfile);
        this.enableEditSubject.next(this.myProfile);
        this.loadProfileSubject.next(this.myProfile);
    }

    showErrors(message:string) {
        let toast = this.toastCtrl.create({
            message: message,
            duration: 10000,
            showCloseButton: true,
            position:'bottom',
            cssClass:'esc-toast-error'
        });
        toast.present();
    }

    hasErrors(): boolean {
        if(this.tempUpdateProfile.parti.hasErrors() || this.tempUpdateProfile.partii.hasErrors()) {
            return true;
        }
        return false;
    }

    getMyProfileErrors() : string[] {
        let errors :string[] = [];
        if(this.tempUpdateProfile.parti.hasErrors()) {
            errors = errors.concat(this.tempUpdateProfile.parti.getErrors());
        }
        if(this.tempUpdateProfile.partii.hasErrors()) {
            errors =errors.concat(this.tempUpdateProfile.partii.getErrors());
        }

        return errors;
    }

    clearMyProfileErrors() : void {
        this.tempUpdateProfile.parti.clearErrors();
        this.tempUpdateProfile.partii.clearErrors();
    }


}
