import {NgModule} from "@angular/core";
import {TranslateModule} from "@ngx-translate/core";
import {IonicPageModule} from "ionic-angular";
import {MyProfilePage} from "./my-profile";
import {DobValidator} from "./part-i/dobValidator";
import {ReactiveFormsModule} from "@angular/forms";

@NgModule({
    imports: [
        ReactiveFormsModule,
        TranslateModule.forChild(),
        IonicPageModule.forChild(MyProfilePage)
    ],
    declarations: [MyProfilePage],
    providers: [DobValidator]
})
export class MyProfilePageModule {
}
