import {NgModule} from "@angular/core";
import {MyProfileToolBarPage} from "./my-profile-tool-bar";
import {TranslateModule} from "@ngx-translate/core";
import { IonicPageModule} from "ionic-angular";

@NgModule({
    imports :[
        IonicPageModule.forChild(MyProfileToolBarPage),
        TranslateModule.forChild()
    ],
    declarations : [
        MyProfileToolBarPage
    ],
    exports : [
        MyProfileToolBarPage
    ]
})
export class MyProfileToolBarModule {}