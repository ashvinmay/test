import {Component, Input, EventEmitter, Output} from '@angular/core';
import {NavController, NavParams, Slides, Events} from 'ionic-angular';
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {MyProfileCommon} from "../myProfile-common";

@Component({
    selector: 'page-my-profile-tool-bar',
    templateUrl: 'my-profile-tool-bar.html'
})
export class MyProfileToolBarPage {

    @Input()
    isLastTab: boolean = false;

    @Input()
    slides: Slides;

    @Input()
    isEditMode: boolean = false;

    @Output()
    isEditing: EventEmitter<boolean> = new EventEmitter<boolean>();

    @Output()
    isCanceled: EventEmitter<boolean> = new EventEmitter<boolean>();

    @Output()
    isSaving: EventEmitter<boolean> = new EventEmitter<boolean>();

    private logger: Logger;

    constructor(public navCtrl: NavController, public navParams: NavParams, public events: Events, loggerFactory: LoggerFactory,  private myProfileCommon : MyProfileCommon) {
        this.logger = loggerFactory.getLogger('MyProfileToolBarPage');
        this.logger.debug('constructor');
    }

    goForward() {
        if(this.slides) {
            if (this.slides.isEnd()) {
                let tabIndex = this.navCtrl.parent.getSelected().index;
                this.navCtrl.parent.select(tabIndex + 1);
            } else {
                this.slides.slideNext();
            }
        }
    }

    goBackward() {
        if(this.slides) {
            if (this.slides.isBeginning()) {
                let tabIndex = this.navCtrl.parent.getSelected().index;
                this.navCtrl.parent.select(tabIndex - 1);
            } else {
                this.slides.slidePrev();
            }
        }
    }

    showBackButton(): boolean {
        if(this.slides) {
            if (this.navCtrl.parent === null) {
                return false;
            }
            if (this.navCtrl.parent.getSelected() === null) {
                return false;
            }
            let tabIndex = this.navCtrl.parent.getSelected().index;
            return !(tabIndex == 0 && this.slides.isBeginning());
        }
    }

    showForwardButton(): boolean {
        if (this.slides == null) {
            return true;
        }
        return !(this.isLastTab && this.slides.isEnd());
    }

    editProfile() {
        this.logger.debug('Edit profile');
        this.isEditing.emit(true);
        this.myProfileCommon.enableEdit();
    }

    /* isEditing(): boolean {
     return this.editing;
     }*/
    saveProfile() {
        this.logger.debug('Save profile');
        this.isSaving.emit(true);
        this.myProfileCommon.saveProfile();
    }

    cancelEdit() {
        this.logger.debug('Cancel Edit profile');
        this.isCanceled.emit(true);
        this.myProfileCommon.cancelEdit();
    }

}
