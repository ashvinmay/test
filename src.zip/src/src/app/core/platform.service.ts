import {Platform} from "ionic-angular";
import {Injectable} from "@angular/core";

@Injectable()
export class PlatformService {

    constructor(public platform: Platform) {
    }

    public isAndroid(): boolean {
        return this.platform.is('android');
    }

    public isIOS(): boolean {
        return this.platform.is('ios');
    }

    public isCordova(): boolean {
        return this.platform.is('cordova');
    }

    public isTablet(): boolean {
        return this.platform.is('tablet') || this.platform.is("core");
    }

    public isDesktop(): boolean {
        return this.platform.is("core");
    }

    public isPortrait(): boolean {
        return this.platform.isPortrait();
    }

    public isLandscape(): boolean {
        return this.platform.isLandscape();
    }
}