import {Injectable} from "@angular/core";
import stringify from "fast-safe-stringify";
import {Observable} from "rxjs/Observable";
import {EscHttp} from "../http/esc-http";
import {EnvConfiguration} from "../../../env/env.configuration";
import {Logger} from "../logger/logger";
import {LoggerFactory} from "../logger/logger-factory";
import {Subject} from "rxjs";


@Injectable()
export class AnalyticService {

  private trackStream  = new Subject();
  private logger: Logger;

  constructor(private loggerFactory: LoggerFactory, private escHttp: EscHttp, private config: EnvConfiguration,) {
    this.logger = this.loggerFactory.getLogger("AnalyticService");
    this.init();

  }

  /**
   * Track page view and send to server
   * @param {string} page
   * @param pageDetails
   */
  public trackPageView(page: string, pageDetails?: any): void {
    this.logger.debug("track page : ", page);
    this.trackStream.next({
      name: page,
      details: pageDetails,
      url: this.config.analyticsUrl + "/page"
    })
  }

  /**
   * Track event and send to server
   * @param {string} page
   * @param pageDetails
   */
  public trackEvent(event: string, eventDetails?: any): void {
    this.logger.debug("track event : ", event);
    this.trackStream.next({
      name: event,
      details: eventDetails,
      url: this.config.analyticsUrl + "/event"
    })
  }

  private init() {
    this.logger.debug("init..")
    this.trackStream.subscribe((track : clientTrack)=> {
      let toTrack = this.buildTrackModel(track.name, track.details);
      this.sendToServer(toTrack, track.url).subscribe(() => {
        //do nothing
        this.logger.debug("Track successfully... ")
      }, (error) => {
        this.logger.error("AnalyticService -- Could not send page/event analytics: " + stringify(error));
      });
    });
  }

  private buildTrackModel(name: string, details: any): TrackModel {
    let eventToTrack = new TrackModel();
    eventToTrack.name = name;
    if (details) {
      eventToTrack.details = stringify(details);
    }
    eventToTrack.clientDateTime = new Date().toISOString();
    return eventToTrack;
  }

  private sendToServer(toTrack: TrackModel, url: string): Observable<any> {
    return this.escHttp.postJsonNoErrorHandling(url, toTrack);
  }
}


export class TrackModel {
  name: string;
  details: string;
  clientDateTime: string;
}

export class clientTrack {
  name: string;
  details: string;
  url: string;
}
