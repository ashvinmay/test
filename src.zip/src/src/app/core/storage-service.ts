import {Injectable} from "@angular/core";
import {Storage} from "@ionic/storage";
import {LoggerFactory} from "./logger/logger-factory";
import {Logger} from "./logger/logger";
import {Observable} from "rxjs/Observable";

@Injectable()
export class StorageService {

    private logger: Logger;

    /**
     * Key for displaying not acceptedOffer alert message.
     */
    private static UNACCEPTED_OFFER_ALERT: string = "unaccepted_offer_alert";

    /**
     * Key for displaying acceptedOffer alert message.
     */
    private static ACCEPTED_OFFER_ALERT: string = "accepted_offer_alert";

    /**
     * Key for displaying edit profile not allowed alert message.
     */
    private static EDIT_PROFILE_ALERT: string = "edit_profile_alert";

    /**
     * Key for user selected language. Need to store, in case user log out
     */
    private static USER_SELECTED_LANG: string = "user_selected_lang";

    /**
     * Key for user first login
     */
    private static USER_FIRST_LOGIN: string = "user_first_login";

    constructor(private storage: Storage, loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("StorageService");
    }

    public getUnAcceptedOfferAlertDisplayed(): Observable<boolean> {
        let self = this;
        function getValueInternal() : Promise<boolean> {
            return self.storage.get(StorageService.UNACCEPTED_OFFER_ALERT);
        }
        return Observable.fromPromise(
            this.storage.ready().then(() => {
                return getValueInternal();
            })
        );
    }

    public setUnAcceptedOfferAlertDisplayed(displayed: boolean): Promise<any> {
        return this.storage.set(StorageService.UNACCEPTED_OFFER_ALERT, displayed)
            .then(() => {
                this.logger.debug("Persisted unaccepted_offer_alert=" + displayed);
                return {
                    result: true
                };
            });
    }

    public getAcceptedOfferAlertDisplayed(): Observable<boolean> {
        let self = this;
        function getValueInternal() : Promise<boolean> {
            return self.storage.get(StorageService.ACCEPTED_OFFER_ALERT);
        }
        return Observable.fromPromise(
            this.storage.ready().then(() => {
                return getValueInternal();
            })
        );
    }

    public setAcceptedOfferAlertDisplayed(displayed: boolean): Promise<any> {
        return this.storage.set(StorageService.ACCEPTED_OFFER_ALERT, displayed)
            .then(() => {
                this.logger.debug("Persisted accepted_offer_alert=" + displayed);
                return {
                    result: true
                };
            });
    }

    public getEditProfileAlertDisplayed(): Observable<boolean> {
        let self = this;
        function getValueInternal() : Promise<boolean> {
            return self.storage.get(StorageService.EDIT_PROFILE_ALERT);
        }
        return Observable.fromPromise(
            this.storage.ready().then(() => {
                return getValueInternal();
            })
        );
    }

    public setEditProfileAlertDisplayed(displayed: boolean): Promise<any> {
        return this.storage.set(StorageService.EDIT_PROFILE_ALERT, displayed)
            .then(() => {
                this.logger.debug("Persisted edit_profile_alert=" + displayed);
                return {
                    result: true
                };
            });
    }

    public getUserSelectedLanguage(): Observable<string> {
        let self = this;
        function getValueInternal() : Promise<string> {
            return self.storage.get(StorageService.USER_SELECTED_LANG);
        }
        return Observable.fromPromise(
            this.storage.ready().then(() => {
                return getValueInternal();
            })
        );
    }

    public setUserSelectedLanguage(lang: string): Promise<any> {
        return this.storage.set(StorageService.USER_SELECTED_LANG, lang)
            .then(() => {
                this.logger.debug("Persisted user selected language=" + lang);
                return {
                    result: true
                };
            });
    }

    public getUserFirstLogin(): Observable<boolean> {
        let self = this;
        function getValueInternal() : Promise<boolean> {
            return self.storage.get(StorageService.USER_FIRST_LOGIN).then((firstLogin) =>{
                    return null === firstLogin;
            });
        }
        return Observable.fromPromise(
            this.storage.ready().then(() => {
                return getValueInternal().then();
            })
        );
    }

    public setUserFirstLogin(firstLogin: boolean): Promise<any> {
        return this.storage.set(StorageService.USER_FIRST_LOGIN, firstLogin)
            .then(() => {
                this.logger.debug("Persisted user_first_login=" + firstLogin);
                return {
                    result: true
                };
            });
    }

}
