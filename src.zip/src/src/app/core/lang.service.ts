import {Injectable} from "@angular/core";
import {LoggerFactory} from "./logger/logger-factory";
import {Logger} from "./logger/logger";
import {TranslateLoader, TranslateService} from "@ngx-translate/core";
import {StorageService} from "./storage-service";
import localeFr from '@angular/common/locales/fr';
import localeBg from '@angular/common/locales/bg';
import localeCs from '@angular/common/locales/cs';
import localeDa from '@angular/common/locales/da';
import localeDe from '@angular/common/locales/de';
import localeEl from '@angular/common/locales/el';
import localeEn from '@angular/common/locales/en';
import localeEs from '@angular/common/locales/es';
import localeEt from '@angular/common/locales/et';
import localeFi from '@angular/common/locales/fi';
import localeGa from '@angular/common/locales/ga';
import localeHr from '@angular/common/locales/hr';
import localeHu from '@angular/common/locales/hu';
import localeIs from '@angular/common/locales/is';
import localeIt from '@angular/common/locales/it';
import localeLt from '@angular/common/locales/lt';
import localeLv from '@angular/common/locales/lv';
import localeMk from '@angular/common/locales/mk';
import localeMt from '@angular/common/locales/mt';
import localeNl from '@angular/common/locales/nl';
import localeNo from '@angular/common/locales/nb';
import localePl from '@angular/common/locales/pl';
import localePt from '@angular/common/locales/pt';
import localeRo from '@angular/common/locales/ro';
import localeSk from '@angular/common/locales/sk';
import localeSl from '@angular/common/locales/sl';
import localeSv from '@angular/common/locales/sv';
import localeTr from '@angular/common/locales/tr';
import {map, switchMap, tap} from "rxjs/operators";
import {Observable} from "rxjs/Observable";
import {LangChangeEvent} from "@ngx-translate/core/src/translate.service";
import {registerLocaleData} from "@angular/common";

/**
 * Manages current app language
 */
@Injectable()
export class LangService {
  static readonly DEFAULT_APP_LANGUAGE:string = 'en';
  private logger: Logger;
  // app lang codes to ng resource names
  private _langCodesToNgLangResourceMap = {
    'bg': localeBg, 'cs': localeCs, 'da': localeDa, 'de': localeDe, 'el': localeEl,
    'en': localeEn, 'es': localeEs, 'et': localeEt, 'fi': localeFi, 'fr': localeFr,
    'ga': localeGa, 'hr': localeHr, 'hu': localeHu, 'is': localeIs, 'it': localeIt,
    'lt': localeLt, 'lv': localeLv, 'mk': localeMk, 'mt': localeMt, 'nl': localeNl,
    'no': localeNo, 'pl': localePl, 'pt': localePt, 'ro': localeRo, 'sk': localeSk,
    'sl': localeSl, 'sv': localeSv, 'tr': localeTr};

  constructor(loggerFactory: LoggerFactory
    , private translateService: TranslateService
    , private storageService: StorageService
    ,private translateLoader: TranslateLoader
  ) {
    this.logger = loggerFactory.getLogger("LangService");
    this.translateService.addLangs(Object.keys(this._langCodesToNgLangResourceMap));
    // this language will be used as a fallback when a translation isn't found in the current language
    this.translateService.setDefaultLang(LangService.DEFAULT_APP_LANGUAGE);
    // the en - default_app_lang is loaded by default by Angular!
    this.use(LangService.DEFAULT_APP_LANGUAGE).subscribe(x=> {
      this.logger.debug("Init lang service to default lang!")
    });
    this.translateService.onLangChange.subscribe( (event:LangChangeEvent) => {
      const newLang = event.lang;
      this.logger.debug("change resources to new language: ", newLang)
      let ngLangLocaleFile = this.langCodesToNgLangResourceMap[newLang];
      registerLocaleData(ngLangLocaleFile, newLang, this.translateLoader.getTranslation(newLang));
    })
  }


  public initTranslations() {
    // the lang to use, if the lang isn't available, it will use the current loader to get them
    this.storageService.getUserSelectedLanguage().subscribe((lang) => {
      this.logger.info("Init Translations to...", lang);
      if (lang) {
        // update app language // load lang
        this.switchTranslationsTo(lang);
      } /*else {
        // the en - default_app_lang is loaded by default by Angular!
        this.translateService.use(LangService.DEFAULT_APP_LANGUAGE);
        //this.switchTranslationsTo(LangService.DEFAULT_APP_LANGUAGE);
      }*/
    })
  }

  /**
   * tries to switch to new language, if it doesn't succeed it will switch to #DEFAULT_APP_LANGUAGE.
   * @param {string} lang
   * @returns {string} the given lang or the #DEFAULT_APP_LANGUAGE
   */
  private switchTranslationsTo(lang:string): Observable<string> {
    this.logger.debug("changing app language to: ", lang);

    let currentLang = this.checkLangOrUseDefault(lang);

    // System.import(`@angular/common/locales/${localeId}.js`) // declare var System;
    // update translation files
    return this.use(currentLang);


  }

  private use(currentLang: string):Observable<string> {
    return this.translateService.use(currentLang).
      pipe(
        map(value => currentLang),
        tap(value => {
          this.logger.debug("Language changed to", value)
        })
      );
  }

  /**
   * updates application language to the new one, meaning
   *  - switching translations
   *  - updates user language
   *
   * @param {string} newLanguage
   * @returns {string}
   */
  public updateLanguage(newLanguage: string):Observable<string> {
    this.logger.debug("update language to ", newLanguage);
    return Observable.fromPromise(this.storageService.setUserSelectedLanguage(newLanguage)).pipe(
      switchMap(_ => this.switchTranslationsTo(newLanguage))
    );

  }

  /**
   * if the translation service doesn't support the newLanguage, the #DEFAULT_APP_LANGUAGE - en will be returned
   * @param {string} newLanguage
   * @returns {string}
   */
  private checkLangOrUseDefault(newLanguage: string):string {
    let currentLang: string = newLanguage;
    // not found fallback to default
    if (this.translateService.getLangs().indexOf(newLanguage) < 0) {
      this.logger.debug(`could not find ${newLanguage}, falling back to default: `, this.translateService.defaultLang);
      currentLang = this.translateService.defaultLang;
    }
    this.logger.debug(`check new lang ${newLanguage} to ${currentLang}`);
    return currentLang;
  }

  get langCodesToNgLangResourceMap(): any {
    return this._langCodesToNgLangResourceMap;
  }
}
