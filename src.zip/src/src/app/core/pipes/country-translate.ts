/**
 * FromNowPipe let's us convert a date into a human-readable relative-time
 * such as "10 minutes ago".
 */
import {Pipe, PipeTransform} from "@angular/core";
import {TranslateService} from "@ngx-translate/core";
import {ADDRESS_COUNTRIES} from "../../my-profile/address.countries";

@Pipe({
  name: 'countryLabel'
})
export class CountryTranslatePipe implements PipeTransform {

  constructor(private translateService:TranslateService) {

  }

  /**
   * first value of args is expected to be a boolean: stripCountryCode from translation!.
   *
   * returns the translated country code i.e
   * from [AU] to [AU] Australia
   * or if first argument(strip country code) is true, then from [AU] to Australia
   */
  transform(value: string, stripCountryCode: boolean): string {
    // no value - no translation
    if(!value || value.trim().length === 0) {
      return "";
    }
    let countryLabel = this.getCountryLabel(value);

    let translation = this.translateService.instant(countryLabel);
    //console.log("countryLabel:", countryLabel, " - translation: ", translation)
    if(stripCountryCode) {
      return translation.substr(translation.lastIndexOf("]")+1);
    }
    return translation
    // return this.getCountryLabel(value);
  }

  getCountryLabel(code: string): string {
    for (let country of ADDRESS_COUNTRIES) {
      if (country.code == code) {
        return country.country;
      }
    } // else

    return code;
  }
}
/*

export const countryTranslatPipeInjectables: Array<any> = [
  CountryTranslatePipe
];
*/
