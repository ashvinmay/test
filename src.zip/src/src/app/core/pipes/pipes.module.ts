import {NgModule} from "@angular/core";
import {TranslateService} from "@ngx-translate/core";
import {CountryTranslatePipe} from "./country-translate";

@NgModule({
  declarations: [CountryTranslatePipe],
  imports: [],
  exports: [CountryTranslatePipe]
})
export class PipesModule {

  static forRoot() {
    return {
      ngModule: PipesModule,
      providers: [TranslateService],
    };
  }

}
