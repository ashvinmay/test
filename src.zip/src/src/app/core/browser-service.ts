import {Injectable} from "@angular/core";
import {BrowserTab} from "@ionic-native/browser-tab";
import {InAppBrowser} from "@ionic-native/in-app-browser";
import {Platform} from "ionic-angular";
import { SafariViewController } from '@ionic-native/safari-view-controller';
import stringify from "fast-safe-stringify";
import {LoggerFactory} from "./logger/logger-factory";
import {Logger} from "./logger/logger";


/**
 * @author steduda
 * @since 20/04/2017
 */
@Injectable()
export class BrowserService {

  private logger : Logger;

  constructor(private browserTab: BrowserTab, private iab: InAppBrowser, private platform: Platform, private safariViewController: SafariViewController,
    loggerFactory : LoggerFactory) {
    this.logger = loggerFactory.getLogger("BrowserService");
  }

  openUrl(url: string) {
    this.platform.ready().then(() => {
      if (this.platform.is('ios')) {
        this.openUrlUsingSafariViewController(url);
      } else {
        this.openUrlUsingBrowserTab(url);
      }
    });
  }

  /**
   * Register an 'onclick' listener for all 'a' tags so that the registered browser is used to open links.
   *
   * @param {any] nativeElement DOM element obtained from an 'ElementRef' instance via 'ElementRef.nativeElement'
   */
  fixLinks(nativeElement : any) {
    try {
      let elems = nativeElement.querySelectorAll('a');
      if (elems && elems.length > 0) {
        let index = 0;
        for (index = 0; index < elems.length; index++) {
          this.registerClickHandler(elems[index]);
        }
      }
    } catch (error) {
      this.logger.error("Could not register onclick listeners for A elements! Details: " + stringify(error));
    }
  }

  private registerClickHandler(el) {
    const clickHandler = (e) => {
      this.logger.debug("Inside registered click handler ...");
      e.preventDefault();
      e.stopPropagation();

      this.openUrl(el.href);
      return false;
    };

    if (el && el.href) {
      console.log("Found 'a' using href " + el.href + ". Trying to use onclick ...");
      try {
        el.onclick = clickHandler;
      } catch (error) {
        this.logger.error("Do not know how to register handler for a.onclick. Got error: " + stringify(error));
      }
    }
  }

  private openUrlUsingBrowserTab(url : string) {
    this.browserTab.isAvailable()
      .then((isAvailable: boolean) => {
        if (isAvailable) {
          // Use new advanced BrowserTab
          this.browserTab.openUrl(url);
        } else {
          this.openUrlUsingInAppBrowser(url);
        }
      });
  }

  private openUrlUsingInAppBrowser(url : string) {
    // Open URL with InAppBrowser instead or SafariViewController
    const browser = this.iab.create(url);
    browser.show();
  }

  private openUrlUsingSafariViewController(url: string) {
    this.safariViewController.isAvailable()
      .then((available: boolean) => {
          if (available) {
            this.safariViewController.show({
              url: url,
              hidden: false,
              animated: false,
              transition: 'curl',
              enterReaderModeIfAvailable: false
            })
            .subscribe((result: any) => {
                if(result.event === 'opened') this.logger.debug('Opened link using SafariViewController ...');
                else if(result.event === 'loaded') this.logger.debug('Loaded link using SafariViewController ...');
                else if(result.event === 'closed') this.logger.debug('Closed');
              },
              (error: any) => console.error(error)
            );
          } else {
            // use fallback browser - InAppBrowser
            this.openUrlUsingInAppBrowser(url);
          }
        }
      );
  }
}
