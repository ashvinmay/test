import {Injectable} from "@angular/core";

import {Observable, Subject} from "rxjs/Rx";
import {EscAppVersion} from "../app-info/esc-app-version";
import stringify from "fast-safe-stringify";
import {EnvConfiguration} from "../../../env/env.configuration";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {catchError} from "rxjs/operators";

/**
 * Report error to server.
 */
@Injectable()
export class ErrorReporterService {

  private errorStream  = new Subject();

  // HTTP headers to be used when reporting errors
  private contentTypeHeaders = {
    headers: new HttpHeaders({
      "Content-Type": "application/json; charset=utf-8"
    })
  };

  constructor( private http: HttpClient, private config: EnvConfiguration, private escAppVersion : EscAppVersion) {
    this.init();
  }

  /**
   * Report error to server.
   *
   * @param stringifiedError {string} The error to be reported.
   */
  reportError(message: string, stackTrace: string) {
    if (this.config.reportErrors) {
      this.errorStream.next({
        message: message,
        stackTrace: stackTrace
      });
    }
  }

  private init(): void {
    this.errorStream
      // Do not report same error twice (when received one after another)
      .distinctUntilChanged((obj1:ClientError, obj2:ClientError) => {
        return obj1.message === obj2.message && obj1.stackTrace === obj2.stackTrace;
      })
      .flatMap((err : ClientError) => {
        return this.sendToServer(err);
      })
      .subscribe(
        (value) =>{
          // Nothing to do here, but WE DO NEED TO SUBSCRIBE to
          // the stream in order for the event emitter to pass its
          // values downstream to the HTTP flat-mapper.
          console.warn("ErrorReporterService -- Successfully sent: " + stringify(value) );
        },
        (error ) => {
          console.error("ErrorReporterService -- Could not send error: " + stringify(error));
        }
      );
  }

  private sendToServer(clientError: ClientError) : Observable<any> {
    var body = this.buildErrorBody(clientError);

    return this.http
        .post(
          this.config.logErrorUrl,
          JSON.stringify(body),
          this.contentTypeHeaders
        ).pipe(
            catchError((err) =>  this.handleHttpError(err, clientError))
        );
                /*if (err instanceof AuthHttpError) {
                    // not token, or token has expired. Try to re-send using simple HTTP
                    return this.http.post(
                        this.config.logErrorUrl,
                        JSON.stringify(body),
                        this.contentTypeHeaders
                    ).pipe(
                        catchError(err => this.handleHttpError(err))
                    )
                }*/
                //return this.handleHttpError(err);
  }

  private handleHttpError(err, clientError:ClientError) : Observable<any> {
    try {
      return( Observable.throw( {
        message: 'Could not report client error!',
        clientError: clientError,
        httpError: err.json()
      }) );
    } catch ( jsonError ) {
      console.warn("Could not parse error: " + stringify(err) + "! Got conversion error: " + stringify(jsonError));

      // If the error couldn't be parsed as JSON data
      // then it's possible the API is down or something
      // went wrong with the parsing of the successful
      // response. In any case, to keep things simple,
      // we'll just create a minimum representation of
      // a parsed error.
      var minimumViableError = {
        message: 'Could not report client error and could not parse server response as JSON',
        clientError: clientError,
        jsonError: jsonError
      };
      return( Observable.throw( minimumViableError ) );
    }
  }

  private buildErrorBody(clientError: ClientError) {
    let appInfo = this.escAppVersion.getInstantAppInfo();
    let appVersion = (appInfo ? appInfo.appVersion : '');
    var body = {
      location: window.location.href,
      message: clientError.message,
      stackTrace: clientError.stackTrace,
      appVersion: appVersion
    };
    return body;
  }
}

export class ClientError {
  message: string;
  stackTrace: string;
}
