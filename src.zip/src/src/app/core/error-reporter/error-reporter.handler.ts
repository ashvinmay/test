import {IonicErrorHandler} from "ionic-angular";
import * as ErrorStackParser from "error-stack-parser";
import {ErrorReporterService} from "./error-reporter.service";

/**
 * @author morujca
 * @since 20/03/2017
 */
export class ErrorReporterHandler extends IonicErrorHandler {
    constructor(private errorReporterService: ErrorReporterService) {
        super();
    }

    /**
     * @internal
     */
    handleError(err: any): void {
        console.error(err); // Keep default behaviour of logging message to the console
        if (err.message && err.name && err.stack) {
            try {
                let stack = ErrorStackParser.parse(err)
                    .map(sf => sf.toString())
                    .join("\n");

                var message = err.message.replace(/\\s\\s+/gm, ' ');
                if (message.length > 100) {
                    message = message.substr(0, 97) + '...';
                }

                this.errorReporterService.reportError(`${err.name} : ${message}`, stack);
            } catch (newError) {
                console.warn("ErrorReporterHandler -- Could not send error");
                console.warn(newError);
            }
        } else {
            console.debug("ErrorReporterHandler -- Cannot handle this error:");
            console.debug(err);
        }
    }
}