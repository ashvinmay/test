import {Injectable} from "@angular/core";
import {Observable} from "rxjs/Observable";
import {AlertController, ToastController} from "ionic-angular";
import {TranslateService} from "@ngx-translate/core";
import {BrowserService} from "./browser-service";

@Injectable()
export class AlertUtils {

    constructor(private translateService: TranslateService,
                private alertCtrl: AlertController,
                private toastCtrl: ToastController,
                private browserService: BrowserService,) {
    }

    public handleGetPostsError(error: any) : Observable<any> {
        this.showToastAlert(error.message, 'esc-toast-error');
        return Observable.throw(error);
    }

    public showToastAlert(message: string, cssClass: string) {
        let toast = this.toastCtrl.create({
            message: message,
            duration: 5000,
            showCloseButton: true,
            position: 'bottom',
            cssClass: cssClass
        });
        toast.present();
    }

    public showAlert(message: string) {
        let alert = this.alertCtrl.create({
            message: message,
            buttons: [
                {
                    text: this.translateService.instant('GLOBAL_OK'),
                    role: 'cancel',
                    handler: () => {
                    }
                }
            ]
        });
        alert.present();
    }

    public showConfirmForPortal(url: string) {
        let alert = this.alertCtrl.create({
            message: this.translateService.instant('ALERT_MSG_REDIRECT_PORTAL'),
            buttons: [
                {
                    text: this.translateService.instant('GLOBAL_CANCEL'),
                    role: 'cancel',
                    handler: () => {
                    }
                },
                {
                    text: this.translateService.instant('GLOBAL_OK'),
                    role: 'cancel',
                    handler: () => {
                        this.browserService.openUrl(url);
                    }
                }
            ]
        });
        alert.present();
    }

    public showConfirmApplyForActivity(handler: any) {
        let alert = this.alertCtrl.create({
            message: this.translateService.instant('ALERT_MSG_APPLY_FOR_ACTIVITY'),
            buttons: [
                {
                    text: this.translateService.instant('GLOBAL_CANCEL'),
                    role: 'cancel',
                    handler: () => {
                    }
                },
                {
                    text: this.translateService.instant('SEND'),
                    handler: handler
                }
            ]
        });
        alert.present();
    }

}