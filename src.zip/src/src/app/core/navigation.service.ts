import {Injectable} from "@angular/core";
import {App} from "ionic-angular";


@Injectable()
export class NavigationService {

  previousPage: string;
  currentPage: string;

  constructor(private app:App){

  }

  goToMyJournal(): void {

  }

  goToCommunity():void {
    this.currentPage = 'CommunityPage';
    this.app.getActiveNav().push('CommunityPage')
  }


}
