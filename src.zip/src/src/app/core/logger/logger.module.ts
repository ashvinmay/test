import {ModuleWithProviders, NgModule, Optional, SkipSelf} from "@angular/core";
import {LoggerFactory, LoggerFactoryConfig} from "./logger-factory";

@NgModule()
export class LoggerModule {
  // constructor added to prevent re-import of the LoggerModule
  constructor(@Optional() @SkipSelf() parentModule: LoggerModule) {
    if (parentModule) {
      throw new Error('LoggerModule is already loaded. Import it in the AppModule only');
    }
  }

  static forRoot(config?: LoggerFactoryConfig): ModuleWithProviders {
    return {
      ngModule: LoggerModule,
      providers: [
        {provide: LoggerFactoryConfig, useValue: config },
        LoggerFactory
      ]
    };
  }
}
