import {Injectable, Optional} from '@angular/core';
import {Logger} from "./logger";

export class LoggerFactoryConfig {
  prodMode : boolean;
  disabledLoggers: Array<any>
}

@Injectable()
export class LoggerFactory {

    /**
     * When set to true only WARN and ERROR messages are to be logged. Default is false.
     * @type {boolean}
     */
    private prodMode : boolean = false;

    constructor(@Optional() private config: LoggerFactoryConfig) {
      if (config) {
        this.prodMode = !!config.prodMode;
      }
    }

    public getLogger(name: string): Logger {
        let loggerDisabled = this.prodMode;
        if(this.config && this.config.disabledLoggers) {
          if(!this.prodMode) { // if not prod mode, then enable custom enabling
            loggerDisabled = this.config.disabledLoggers.filter(x=> x.name.trim() === name).length == 1;
            // console.log("logger ", name, " is disabled ", loggerDisabled);
          }
        }
        //return new Logger(name, this.prodMode);
        return new Logger(name, loggerDisabled);
    }

}
