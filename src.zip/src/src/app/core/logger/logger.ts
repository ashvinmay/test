/**
 * Class responsible for logging to the console.
 */
export class Logger {

  name: string;
  prodMode: boolean = false;

  /**
   * @param {string} name The name to be printed as a prefix for all messages logged by this new instance.
   * @param {boolean} prodMode Enable/ disable the production mode. When set to true only WARN and ERROR messages are
   *        to be logged. Default is false.
   */
  constructor(name: string, prodMode?: boolean) {
    this.name = name;
    if (prodMode) {
      this.prodMode = prodMode;
    }
  }

  public debug(message?: string, ...optionalParams: any[]) {
    if (this.prodMode) {
      return;
    }
    if (optionalParams) {
      console.debug.apply(console, [this.getMessage(message), ...optionalParams]);
    } else {
      console.debug.apply(console, [this.getMessage(message)]);
    }
  }

  public info(message?: string, ...optionalParams: any[]) {
    if (this.prodMode) {
      return;
    }
    if (optionalParams) {
      console.info.apply(console, [this.getMessage(message), ...optionalParams]);
    } else {
      console.info.apply(console, [this.getMessage(message)]);
    }
  }

  public warn(message?: string, ...optionalParams: any[]) {
    if (optionalParams) {
      console.warn.apply(console, [this.getMessage(message), ...optionalParams]);
    } else {
      console.warn.apply(console, [this.getMessage(message)]);
    }
  }

  public error(message?: string, ...optionalParams: any[]) {
    if (optionalParams) {
      console.error.apply(console, [this.getMessage(message), ...optionalParams]);
    } else {
      console.error.apply(console, [this.getMessage(message)]);
    }
  }

  private getMessage(message?: string): any {
    if (message) {
      return `${this.name} -- ${message}`;
    }
    return `${this.name} -- `;
  }
}
