
export const COUNTRIES = [
     {value: "Austria"}
    ,{value: "Belgium"}
    ,{value: "Bulgaria"}
    ,{value: "Croatia"}
    ,{value: "Cyprus"}
    ,{value: "Czech Republic"}
    ,{value: "Denmark"}
    ,{value: "Estonia"}
    ,{value: "FYRo Macedonia"}
    ,{value: "Finland"}
    ,{value: "France"}
    ,{value: "Germany"}
    ,{value: "Greece"}
    ,{value: "Hungary"}
    ,{value: "Iceland"}
    ,{value: "Ireland"}
    ,{value: "Italy"}
    ,{value: "Latvia"}
    ,{value: "Lithuania"}
    ,{value: "Luxembourg"}
    ,{value: "Liechtenstein"}
    ,{value: "Netherlands"}
    ,{value: "Norway"}
    ,{value: "Poland"}
    ,{value: "Portugal"}
    ,{value: "Romania"}
    ,{value: "Serbia"}
    ,{value: "Slovakia"}
    ,{value: "Slovenia"}
    ,{value: "Spain"}
    ,{value: "Sweden"}
    ,{value: "Turkey"}
    ,{value: "United Kingdom"}
];