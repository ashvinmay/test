export const LANGUAGES = [
     {code: 'bg'          ,language: 'Български'}
    ,{code: 'cs'          ,language: 'Čeština'}
    ,{code: 'da'          ,language: 'Dansk'}
    ,{code: 'de'          ,language: 'Deutsch'}
    ,{code: 'et'          ,language: 'Eesti'}
    ,{code: 'el'          ,language: 'Ελληνικά'}
    ,{code: 'en'          ,language: 'English'}
    ,{code: 'es'          ,language: 'Español'}
    ,{code: 'fr'          ,language: 'Français'}
    ,{code: 'ga'          ,language: 'Gaeilge'}
    ,{code: 'hr'          ,language: 'Hrvatski'}
    //,{code: 'is'          ,language: 'Íslenska'}
    ,{code: 'it'          ,language: 'Italiano'}
    ,{code: 'lv'          ,language: 'Latviešu'}
    ,{code: 'lt'          ,language: 'Lietuvių'}
    //,{code: 'mk'          ,language: 'Македонски'}
    ,{code: 'hu'          ,language: 'Magyar'}
    ,{code: 'mt'          ,language: 'Malti'}
    ,{code: 'nl'          ,language: 'Nederlands'}
    //,{code: 'no'          ,language: 'Norsk'}
    ,{code: 'pl'          ,language: 'Polski'}
    ,{code: 'pt'          ,language: 'Português, Portugal'}
    ,{code: 'ro'          ,language: 'Română'}
    ,{code: 'sk'          ,language: 'Slovenčina'}
    ,{code: 'sl'          ,language: 'Slovenščina'}
    ,{code: 'fi'          ,language: 'Suomi'}
    ,{code: 'sv'          ,language: 'Svenska'}
    //,{code: 'tr'          ,language: 'Türkçe'}
];
