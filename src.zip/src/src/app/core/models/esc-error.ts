/**
 * Error to be used by all services that do data manipulation, if needed.
 */
export class EscError {
    constructor(public readonly status: number, public readonly message: string, public readonly errorDetails: Array<{field: string, issue: string}>) {
    }
}