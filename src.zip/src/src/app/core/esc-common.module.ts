/**
 * @author morujca
 * @since 20/03/2017
 */
import {NgModule, Optional, SkipSelf} from '@angular/core';
import {EscAppVersion} from "./app-info/esc-app-version";
import {ReadMoreComponent} from "./components/read-more";
import {CommonModule} from "@angular/common";
import {HttpErrorHandler} from "./http/http-error-handler";
import {BrowserService} from "./browser-service";
import {PermissionsService} from "./permissions.service";
import {PhotoService} from "../community/services/photo.service";
import {PlatformService} from "./platform.service";

@NgModule({
    imports: [
        CommonModule],
    declarations: [
        ReadMoreComponent
    ],
    exports: [
        ReadMoreComponent
    ],
    providers: [
        EscAppVersion,
        HttpErrorHandler,
        BrowserService,
        PermissionsService,
        PhotoService,
        PlatformService
    ]
})
export class EscCommonModule {
    // constructor added to prevent re-import of the EscCommonModule
    constructor(@Optional() @SkipSelf() parentModule: EscCommonModule) {
        if (parentModule) {
            throw new Error('EscCommonModule is already loaded. Import it in the AppModule only');
        }
    }
}
