import {Injectable} from "@angular/core";
import {Platform} from "ionic-angular";
import {Diagnostic} from '@ionic-native/diagnostic';
import {Logger} from "./logger/logger";
import {LoggerFactory} from "./logger/logger-factory";
import stringify from "fast-safe-stringify";

@Injectable()
export class PermissionsService {

    private logger: Logger;

    constructor(public platform: Platform, public diagnostic: Diagnostic,
                loggerFactory: LoggerFactory) {

        this.logger = loggerFactory.getLogger("PermissionsService");
    }

    isAndroid() {
        return this.platform.is('android')
    }

    isiOS() {
        return this.platform.is('ios');
    }

    checkCameraPermission(): Promise<boolean> {
        return new Promise(resolve => {
            if (this.isiOS()) {
                this.diagnostic.getCameraAuthorizationStatus().then(status => {
                    this.logger.debug("iOS Camera Permission Status: " + status);
                    switch (status) {
                        case this.diagnostic.permissionStatus.GRANTED:
                            resolve(true);
                            break;
                        case this.diagnostic.permissionStatus.NOT_REQUESTED:
                            this.logger.debug("iOS Asks Camera Permission...");
                            this.diagnostic.requestCameraAuthorization().then(authorisation => {
                                this.logger.debug("iOS Camera Permission: " + authorisation);
                                resolve(authorisation == this.diagnostic.permissionStatus.GRANTED);
                            });
                            break;
                        default:
                            this.openSettings();
                    }
                });
            } else if (this.isAndroid()) {
                this.diagnostic.isCameraAuthorized().then(authorised => {
                    this.logger.debug("Android Camera Permission Status: " + authorised);
                    if (authorised) {
                        resolve(true);
                    } else {
                        this.logger.debug("Android Asks Camera Permission...");
                        this.diagnostic.requestCameraAuthorization().then(authorisation => {
                            this.logger.debug("Android Camera Permission: " + authorisation);
                            if (authorisation === this.diagnostic.permissionStatus.DENIED_ALWAYS) {
                                this.openSettings();
                            }
                            resolve(authorisation == this.diagnostic.permissionStatus.GRANTED);
                        });
                    }
                });
            }
        });
    }

    checkGalleryPermission(): Promise<boolean> {
        return new Promise(resolve => {
            // IOS Only
            if (this.isiOS()) {
                this.diagnostic.getCameraRollAuthorizationStatus().then(status => {
                    this.logger.debug("iOS Gallery Permission Status: " + status);
                    switch (status) {
                        case this.diagnostic.permissionStatus.GRANTED:
                            resolve(true);
                            break;
                        case this.diagnostic.permissionStatus.NOT_REQUESTED:
                            this.logger.debug("iOS Asks Gallery Permission...");
                            this.diagnostic.requestCameraRollAuthorization().then(authorisation => {
                                this.logger.debug("iOS Gallery Permission: " + authorisation);
                                resolve(authorisation == this.diagnostic.permissionStatus.GRANTED);
                            });
                            break;
                        default:
                            this.openSettings();
                    }
                });
            } else {
                resolve(true);
            }
        });
    }

    private openSettings() {
        this.logger.debug("Opening Settings...");
        this.diagnostic.switchToSettings().then(
            function () {
              this.logger.debug("Successfully switched to Settings");
            }, function (error) {
              this.logger.error("The following error occurred: " + stringify(error));
            });
    }

}
