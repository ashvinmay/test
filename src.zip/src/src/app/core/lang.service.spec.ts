import {inject, TestBed} from "@angular/core/testing";
import {LangService} from "./lang.service";
import {LoggerFactory} from "./logger/logger-factory";
import {TranslateLoader, TranslateModule} from "@ngx-translate/core";
import {StorageService} from "./storage-service";
import {HttpClient, HttpClientModule} from "@angular/common/http";
import {IonicStorageModule, StorageConfig} from "@ionic/storage";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
import localeFr from "@angular/common/locales/fr";

// or load it from app.module...?!
export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
  //return new TranslateFakeLoader();
}

const storageConfig: StorageConfig = {
  name: '_escstorage',
  storeName: '_esckv',
  driverOrder: ['sqlite', 'indexeddb', 'websql', 'localstorage']
};

describe('LangService tests', () => {
  let supportedLanguages: Array<string>  = ['bg', 'cs', 'da', 'de', 'el', 'en', 'es', 'et', 'fi', 'fr', 'ga', 'hr', 'hu', 'is', 'it', 'lt', 'lv', 'mk', 'mt', 'nl', 'no', 'pl', 'pt', 'ro', 'sk', 'sl', 'sv', 'tr'];
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[
        HttpClientModule,
        TranslateModule.forRoot({
            loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          }
        }),
        IonicStorageModule.forRoot(storageConfig),
      ],
      providers: [LangService, LoggerFactory, StorageService]
      // declarations: [
      //   LangService
      // ]
    });

  });

  it("should init all supported languages", inject([LangService],(langService: LangService) => {
    expect(langService).toBeTruthy();
    let languageSettings = Object.keys(langService.langCodesToNgLangResourceMap);

    expect(languageSettings).toEqual(supportedLanguages);
  }));

  it("should map 'fr' to 'localeFr' ", inject([LangService], (langService: LangService) => {
    expect(langService.langCodesToNgLangResourceMap['fr']).toEqual(localeFr);
  }));

  it("should be possible to change to known language' ", inject([LangService], (langService: LangService) => {
     let newLanguage = supportedLanguages[4];
     console.log("known language: ", newLanguage);
     expect(langService.updateLanguage(newLanguage)).toEqual(newLanguage);
  }));

  it("should fallback to default EN when change to unknown language' ", inject([LangService], (langService: LangService) => {
     let newLanguage = "pz";
     expect(langService.updateLanguage(newLanguage)).toEqual(LangService.DEFAULT_APP_LANGUAGE);
  }));

});
