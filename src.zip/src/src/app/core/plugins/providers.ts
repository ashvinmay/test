//import {PLUGIN_MOCKS} from "./mocks"
import {PLUGIN_NATIVES} from "./native"
import {Provider} from "@angular/core";

/**
 * Use the Ionic native plugins or their mocks depending on the real environment.
 * If the document.URL contains http:// or https:// then we must be running through the browser, since Cordova does not use this protocol.
 *
 * @type {Array<Provider>}
 */
export const PLUGIN_PROVIDERS : Array<Provider> =
 // (document.URL.includes('https://') || document.URL.includes('http://')) ?
    // Use mocks for native plugins when running 'ionic serve'
   // PLUGIN_MOCKS :
    // Use native plugins when running inside Cordova
    PLUGIN_NATIVES;
