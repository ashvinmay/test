import {Provider} from "@angular/core";
import {StatusBar} from "@ionic-native/status-bar";
import {SplashScreen} from "@ionic-native/splash-screen";
import {Camera} from "@ionic-native/camera";
import {AppVersion} from "@ionic-native/app-version";
import {FileTransfer} from "@ionic-native/file-transfer";
import {File} from '@ionic-native/file';
import {InAppBrowser} from "@ionic-native/in-app-browser";
import {ImagePicker} from "@ionic-native/image-picker";
import {Network} from "@ionic-native/network"
import {BrowserTab} from "@ionic-native/browser-tab";
import {Crop} from "@ionic-native/crop";
import {ImgCacheService} from "../../community/shared/img-cache/img-cache.service";
import {Diagnostic} from "@ionic-native/diagnostic";
import {SafariViewController} from "@ionic-native/safari-view-controller";
import {SocialSharing} from "@ionic-native/social-sharing";
import {Push} from "@ionic-native/push";
import {Badge} from "@ionic-native/badge";


/**
 * The list of all native Ionic plugins 3.x used by the app when running inside Cordova.
 */
export let PLUGIN_NATIVES: Array<Provider> = [
    StatusBar,
    SplashScreen,
    InAppBrowser,
    Camera,
    AppVersion,
    FileTransfer,
    File,
    ImagePicker,
    Network,
    BrowserTab,
    Crop,
    ImgCacheService,
    Diagnostic,
    SafariViewController,
    SocialSharing,
    Push,
    Badge

];
