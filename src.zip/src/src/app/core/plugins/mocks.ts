import {SplashScreen} from '@ionic-native/splash-screen';
import {StatusBar} from '@ionic-native/status-bar';
import {Provider} from "@angular/core";
import {Camera, CameraOptions} from "@ionic-native/camera";
import {AppVersion} from "@ionic-native/app-version";
import {FileTransfer, FileTransferObject} from '@ionic-native/file-transfer';
import {File} from '@ionic-native/file';
import {ImagePicker} from "@ionic-native/image-picker";
import {InAppBrowser} from "@ionic-native/in-app-browser";
import {Network} from "@ionic-native/network"
import {BrowserTab} from "@ionic-native/browser-tab";
import {Crop} from "@ionic-native/crop";
import {ImgCacheService} from "../../community/shared/img-cache/img-cache.service";
import {Diagnostic} from "@ionic-native/diagnostic";
import {
    SafariViewController,
    SafariViewControllerOptions
} from "@ionic-native/safari-view-controller";
import {Observable} from "rxjs/Observable";
import {SocialSharing} from "@ionic-native/social-sharing";

/**
 * Create mocks for the Ionic native 3.x plugins used by the app.
 * The mocks are to be used when running the app via 'ionic serve'.
 */
export class StatusBarMock extends StatusBar {
    styleDefault() {
    }
}

export class SplashScreenMock extends SplashScreen {
    show() {
    }

    hide() {
    }
}

export class CameraMock extends Camera {
    getPicture(options?: CameraOptions): Promise<any> {
        return null;
    }
}

export class AppVersionMock extends AppVersion {
    getAppName(): Promise<any> {
        return new Promise((resolve, reject) => {
            resolve("ESC Mobile");
        });
    }

    getVersionNumber(): Promise<any> {
        return new Promise((resolve, reject) => {
            resolve("0.1");
        });
    }

    getVersionCode(): Promise<any> {
        return new Promise((resolve, reject) => {
            resolve("browser-mock");
        });
    }
}

export class FileTransferMock extends FileTransfer {
    create(): FileTransferObject {
        return new FileTransferObject();
    }
}

export class FileMock extends File {
    cacheDirectory: "tmp"
}

export class ImagePickerMock extends ImagePicker {
}

export class InAppBrowserMock extends InAppBrowser {
}

export class NetworkMock extends Network {
}

export class SocialSharingMock extends SocialSharing {
}

export class BrowserTabMock extends BrowserTab {
    isAvailable(): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            resolve(true);
        });
    }

    /**
     * Opens specified URL in a new tab.
     * @param url
     * @return {Promise<T>}
     */
    openUrl(url: string): Promise<any> {
        return new Promise((resolve, reject) => {
            window.open(url, '_blank');
            resolve([]);
        });
    }
}

export class CropMock extends Crop {
    crop(pathToImage: string, options?: { quality: number; }): Promise<string> {
        return Promise.resolve(pathToImage);
    }
}

export class ImgCacheServiceMock extends ImgCacheService {

}


export class DiagnostickMock extends Diagnostic {

    isExternalStorageAuthorized(): Promise<boolean> {
        return Promise.resolve(true);
    }

    getExternalStorageAuthorizationStatus(): Promise<any> {
        return Promise.resolve("GRANTED");
    }
}

export class SafariViewControllerMock extends SafariViewController {
    isAvailable(): Promise<boolean> {
        return Promise.resolve(false);
    }

    show(options?: SafariViewControllerOptions): Observable<any> {
        return Observable.throw("show() for SafariViewController not supported when using the mock!")
    }

    hide(): Promise<any> {
        return Promise.reject("hide() for SafariViewController not supported when using the mock!");
    }
}

// Mocks for all ionic plugins
export let PLUGIN_MOCKS: Array<Provider> = [
    {provide: StatusBar, useClass: StatusBarMock},
    {provide: SplashScreen, useClass: SplashScreenMock},
    {provide: Camera, useClass: CameraMock},
    {provide: InAppBrowser, useClass: InAppBrowserMock},
    {provide: AppVersion, useClass: AppVersionMock},
    {provide: FileTransfer, useClass: FileTransferMock},
    {provide: File, useClass: FileMock},
    {provide: ImagePicker, useClass: ImagePickerMock},
    {provide: Network, useClass: NetworkMock},
    {provide: BrowserTab, useClass: BrowserTabMock},
    {provide: Crop, useClass: CropMock},
    {provide: ImgCacheService, useClass: ImgCacheServiceMock},
    {provide: Diagnostic, useClass: DiagnostickMock},
    {provide: SafariViewController, useClass: SafariViewControllerMock},
    {provide: SocialSharing, useClass: SocialSharingMock}

];