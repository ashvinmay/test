import {Injectable} from "@angular/core";
import {AuthService} from "../../login/services/auth.service";
import {FileTransfer, FileTransferObject, FileUploadOptions} from "@ionic-native/file-transfer";
import {TranslateService} from "@ngx-translate/core";
import {EscAppVersion} from "../app-info/esc-app-version";
import {HttpErrorHandler} from "./http-error-handler";

/**
 * Sends JPEG files to server and also downloads pictures from server.
 */
@Injectable()
export class EscFiles {
    constructor(private authService: AuthService,
                private transfer: FileTransfer,
                private translateService: TranslateService,
                private appVersion: EscAppVersion,
                private httpErrorHandler: HttpErrorHandler) {
    }

    /**
     * Sends a JPEG file to server.
     *
     * @param localImageUrl
     * @param remoteUrl
     * @return {Promise<FileUploadResult|EscError>} Returns a Promise that resolves to a FileUploadResult and rejects with EscError.
     */
    public uploadJpeg(localImageUrl: string, remoteUrl: string, onProgressCB ? :any): Promise<any> {
        return this.authService.getTokenAsPromise()
            .then(authToken => {
                let ft: FileTransferObject = this.transfer.create();

                if(onProgressCB) {
                   ft.onProgress(onProgressCB);
                }

                let options: FileUploadOptions = {
                    fileKey: 'file',
                    mimeType: 'image/jpeg',
                    chunkedMode: false,
                    headers: {
                        'Authorization': 'Bearer ' + authToken,
                        'Content-Type': undefined
                    }
                };

                return ft.upload(localImageUrl, remoteUrl, this.includeCustomHeaders(options), false)
                    .catch((error: any) => {
                        return this.httpErrorHandler.handleUploadError(error);
                    });
            });
    }

    /**
     * Download image from server.
     *
     * @param remoteImageUrl
     * @param localImageUrl
     * @returns {Promise<any>} Returns a Promise that resolves to a FileEntry object.
     */
    downloadImage(remoteImageUrl: string, localImageUrl: string): Promise<any> {
        const fileTransfer: FileTransferObject = this.transfer.create();

        let options = this.includeCustomHeaders({});
        return fileTransfer.download(remoteImageUrl, localImageUrl, false, options);
    }

    private includeCustomHeaders(options: FileUploadOptions): FileUploadOptions {
        let customHeaders = this.getCustomHeaders();
        if (options.headers) {
            for (var headerKey in customHeaders) {
                if (customHeaders.hasOwnProperty(headerKey)) {
                    options.headers[headerKey] = customHeaders[headerKey];
                }
            }
        } else {
            options.headers = customHeaders;
        }
        return options;
    }

    private getCustomHeaders(): { [s: string]: any; } {
        let customHeaders: { [s: string]: any; } = {};
        customHeaders['Accept-Language'] = this.translateService.currentLang;
        let appInfo = this.appVersion.getInstantAppInfo();
        if (appInfo) {
            customHeaders['X-App-Version'] = appInfo.appVersion;
        }
        return customHeaders;
    }
}
