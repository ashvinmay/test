import {HttpClient, HttpErrorResponse, HttpHeaders, HttpParams} from "@angular/common/http";
import {Injectable} from "@angular/core";
import {catchError} from "rxjs/operators";
import {Observable} from 'rxjs/Rx';
import {HttpErrorHandler} from "./http-error-handler";

/**
 * Allows for explicit authenticated HTTP requests.
 *
 * @author morujca, steduda
 * @since 20/03/2017
 */
@Injectable()
export class EscHttp {
    constructor(private http: HttpClient, private httpErrorHandler: HttpErrorHandler) {
    }

    private handleError(error: any): Observable<any> {
        return this.httpErrorHandler.handleError(error);
    }

  /**
   *
   * @param {string} url
   * @param headers: an object who's properties represent httpHeader keys, their value will be mapped as httpHeader.value
   * @param params: an object who's properties represent HttpParams keys, their value will be mapped as httpParam.value
   * @param {T} defaultEntity
   * @returns {Observable<T>}
   */
    getConditionally<T>(url: string, headers:any, params: any, defaultEntity: T): Observable<T> {
        let httpParams = new HttpParams();
        if(params) {
          httpParams = Object.keys(params).reduce((tmpParams, key) => tmpParams.append(key, params[key]), new HttpParams());
        }

        let httpHeaders = new HttpHeaders();
        if(headers) {
          httpHeaders = Object.keys(headers).reduce((tmpHeaders, key) => tmpHeaders.append(key, headers[key]), new HttpHeaders());
        }

        return this.http
            .get<T>(url, {
              headers: httpHeaders,
              params: httpParams
            })
            .pipe(
                catchError((errorResp:HttpErrorResponse) => {
                    if(errorResp.status == 304) {
                      return Observable.of(defaultEntity);
                    }
                    return this.handleError(errorResp);
                  }
                )
            );
    }

    getJson<T>(url: string, params?: any): Observable<T> {
        let httpParams = new HttpParams();
        if(params) {
          httpParams = Object.keys(params).reduce((tmpParams, key) => tmpParams.append(key, params[key]) , new HttpParams());
        }

        return this.http
            .get<T>(url, {params: httpParams})
            .pipe(
                catchError((errorResp) => this.handleError(errorResp))
            );
    }

    /*getValue<T>(url: string, params?: any): Observable<T> {
        let httpParams = new HttpParams();
        if(params) {
          // pass on params
        }
        return this.http
            .get<T>(url, {params: httpParams})
            .pipe(
                catchError((errorResp) => this.handleError(errorResp))
            );
    }*/

    postJson<T>(url: string, body?: any | null ): Observable<T> {
        let localBody = null;
        if(body) {
          localBody = body;
        }
        return this.http
            .post<T>(url, localBody, {headers: this.getJsonRelatedHttpHeaders()})
            .pipe(
                catchError((errorResp) => this.handleError(errorResp))
            );
    }

    postJsonNoErrorHandling<T>(url: string, body?: any | null ): Observable<T> {
      let localBody = null;
      if(body) {
        localBody = body;
      }
      return this.http
        .post<T>(url, localBody, {headers: this.getJsonRelatedHttpHeaders()});
    }

    putJson<T>(url: string, body?: any): Observable<T> {
        // always add json headers
        return this.http
            .put(url, body, {headers: this.getJsonRelatedHttpHeaders()})
            .pipe(
                catchError((errorResp) => this.handleError(errorResp))
            );
    }

    delete(url: string): Observable<any> {
        return this.http
            .delete(url)
            .pipe(
                catchError((errorResp) => this.handleError(errorResp))
            );
    }

    private getJsonRelatedHttpHeaders():HttpHeaders {
      return new HttpHeaders()
        .append("Accept", "application/json;charset=UTF-8")
        .append("Content-Type", "application/json;charset=utf-8");

    }

}
