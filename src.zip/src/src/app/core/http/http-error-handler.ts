import {Injectable} from "@angular/core";
import {Observable} from "rxjs/Observable";
import {EscError} from "../models/esc-error";
import {App} from "ionic-angular";
import {TranslateService} from "@ngx-translate/core";
import {Logger} from "../logger/logger";
import {LoggerFactory} from "../logger/logger-factory";
import {FileTransferError} from "@ionic-native/file-transfer";
import stringify from "fast-safe-stringify";
import {HttpErrorResponse} from "@angular/common/http";

@Injectable()
export class HttpErrorHandler {

    private logger: Logger;

    constructor(private translateService: TranslateService,
                loggerFactory: LoggerFactory,
                private app: App) {
        this.logger = loggerFactory.getLogger("HttpErrorHandler");
    }

    public handleError(error: HttpErrorResponse): Observable<any> {
        this.logger.warn("HTTP error response: " , error);
        let message = "";
        let errorDetails : Array<{ field: string, issue: string }> =[];
        switch (error.status) {
            case -1:
            case 0:
                message = this.translateService.instant('NO_INTERNET_CONNECTION');
                break;
            case 304:
                // No operation: not modified!
                break;
            case 400:
                if(error.error.errorDetails) {
                    errorDetails = error.error.errorDetails;
                }
                message = error.error.message;
                break;
            case 401:
            case 403:
                message = error.error.message;
                this.logout();
                break;
            default:
                message = this.translateService.instant('GENERIC_ERROR_MESSAGE');
                break;

        }
        return this.throwErrorForObservable(error.status, message, errorDetails);
    }

    public handleUploadError(error: FileTransferError): Promise<any> {
        this.logger.warn("File upload error response: " + stringify(error));
        let message = this.translateService.instant('GENERIC_ERROR_MESSAGE');
        if (error.http_status) {
            switch (error.http_status) {
                case -1:
                case 0:
                    message = this.translateService.instant('NO_INTERNET_CONNECTION');
                    break;
                case 400:
                    message = JSON.parse(error.body).message;
                    break;
                case 401:
                case 403:
                    message = JSON.parse(error.body).message;
                    this.logout();
                    break;
            }
        } else if (error.code && error.code === 3) {
            message = this.translateService.instant('NO_INTERNET_CONNECTION');
        }

        return this.throwErrorForPromise(error, message);
    }

    logout() {
        this.app.getRootNav().setRoot('LogoutPage');
    }

    //noinspection JSMethodCanBeStatic
    private throwErrorForObservable(status: number, message: string,  errorDetails: Array<{field: string, issue: string}>): Observable<any> {
        return Observable.throw(new EscError(status, message, errorDetails));
    }

    private throwErrorForPromise(error: FileTransferError, message: string) {
        return Promise.reject(new EscError(error.http_status, message, null));
    }

}
