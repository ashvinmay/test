/**
 * Object storing information like name and version about the app.
 */
export class AppInfo {
    constructor(public appName: string, public appVersion: string) {
    }
}