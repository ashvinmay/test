import {Injectable} from "@angular/core";
import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import {switchMap, tap} from "rxjs/operators";
import {LoggerFactory} from "../logger/logger-factory";
import {Logger} from "../logger/logger";
import {TranslateService} from "@ngx-translate/core";

@Injectable()
export class AppLanguageInterceptor implements HttpInterceptor {

  private logger: Logger;

    constructor(public translateService: TranslateService, loggerFactory: LoggerFactory) {
      this.logger = loggerFactory.getLogger("AppLanguageInterceptor");
    }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.logger.debug("intercept()", request);
        return Observable.of(this.translateService.currentLang).pipe(
            tap(currentLang => {
              this.logger.debug("Got current Language:", currentLang);
            }),
            switchMap(currentLang => {
                if (currentLang) {
                    this.logger.debug("Got current Language:", currentLang);
                    const newRequest = request.clone({
                        //headers: request.headers.set('Accept-Language', currentLang)
                        headers: request.headers.append('Accept-Language', currentLang)
                    });
                    return next.handle(newRequest);
                }
                this.logger.debug("No current Language");
                return next.handle(request);
            }
        )/*,
            catchError(error => {
                this.logger.error(error);
                //return next.handle(request);
              return this.httpErrorHandler.handleError(error);
            })*/
        );
    }
}
