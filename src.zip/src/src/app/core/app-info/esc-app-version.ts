import {Injectable} from "@angular/core";
import {AppVersion} from "@ionic-native/app-version";
import {Platform} from 'ionic-angular';
import "rxjs/add/operator/map";
import {Logger} from "../logger/logger";
import {LoggerFactory} from "../logger/logger-factory";
import {AppInfo} from "./app-info.model";

@Injectable()
export class EscAppVersion {

    private appInfo: AppInfo;

    private logger:Logger;

    constructor(platform: Platform, private appVersion: AppVersion, loggerFactory:LoggerFactory) {
      this.logger = loggerFactory.getLogger("EscAppVersion");
      platform.ready().then(readySource => {
        if (platform.is('cordova')) {
          this.printMainAppInfo();
        }
        return this.getAppInfo();
      }).then(appInfo => {
        this.appInfo = appInfo;
      });
    }

    private printMainAppInfo() {
      Promise.all([this.appVersion.getAppName(), this.appVersion.getPackageName(), this.appVersion.getVersionNumber()])
        .then((data:Array<any>) => {
          if (data && data.length == 3) {
            this.logger.info("Main app info is - name: " + data[0] +
              ", package " + data[1] + ", version: " + data[2]);
          } else {
            this.logger.warn("Could not get main app info");
          }
        });
    }

    /**
     * Get the currently cached AppInfo.
     * @return {AppInfo}
     */
    getInstantAppInfo() {
        return this.appInfo;
    }

    /**
     * Get the name of the application.
     * @return {Promise<AppInfo>}
     */
    getAppInfo(): Promise<AppInfo> {
        var self = this;
        return Promise.all([self.getAppName(), self.getVersionNumber(), self.getVersionCode()])
            .then(([appName, versionNumber, versionCode]) => {
                return new AppInfo(appName, versionNumber);
            });
    }

    private getAppName(): Promise<any> {
        return this.appVersion.getAppName();
    }

    private getVersionCode(): Promise<any> {
        return this.appVersion.getVersionCode();
    }

    private getVersionNumber(): Promise<any> {
        return this.appVersion.getVersionNumber();
    }
}
