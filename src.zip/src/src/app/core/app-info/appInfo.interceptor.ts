import {Injectable} from "@angular/core";
import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import {switchMap, tap} from "rxjs/operators";
import {LoggerFactory} from "../logger/logger-factory";
import {Logger} from "../logger/logger";
import {EscAppVersion} from "./esc-app-version";

@Injectable()
export class AppInfoInterceptor implements HttpInterceptor {

  private logger: Logger;

    constructor(public appVersion: EscAppVersion, loggerFactory: LoggerFactory) {
      this.logger = loggerFactory.getLogger("AppInfoInterceptor");
    }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.logger.debug("intercept()", request);
        return Observable.of(this.appVersion.getInstantAppInfo()).pipe(
            tap(appInfo => {
              this.logger.debug("Got info:", appInfo);
            }),
            switchMap(appInfo => {
                if (appInfo) {
                    this.logger.debug("Got info:", appInfo);
                    const newRequest = request.clone({
                        headers: request.headers.set('X-App-Version', appInfo.appVersion)
                    });
                    return next.handle(newRequest);
                }
                this.logger.debug("No appInfo");
                return next.handle(request);
            }
        )/*,
            catchError(error => {
                this.logger.error(error);
                // return next.handle(request);
              return this.httpErrorHandler.handleError(error);
            })*/
        );
    }
}
