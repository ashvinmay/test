import {Component, ViewChild} from "@angular/core";
import {SplashScreen} from "@ionic-native/splash-screen";
import {StatusBar} from "@ionic-native/status-bar";
import stringify from "fast-safe-stringify";
import {Nav, Platform} from "ionic-angular";
import {ImgCacheService} from "./community/shared/img-cache/img-cache.service";
import {AnalyticService} from "./core/analytics/analytic.service";
import {AuthenticationStatus} from "./login/auth.models";
import {AuthService} from "./login/services/auth.service";
import {EcasWebCallbackPage} from "./login/pages/ecas-web-callback/ecas-web-callback";
import {UserDetails} from "./login/user.details";
import {UserService} from "./login/services/user.service";
import {LangService} from "./core/lang.service";
import {EnvConfiguration} from "../env/env.configuration";
import {ContactService} from "./pages/contact/contact.service";
import {HomePage} from "./pages/home/home";
import {Logger} from "./core/logger/logger";
import {LoggerFactory} from "./core/logger/logger-factory";
import {PushNotificationService} from "./notification/services/push-notification.service";
import {InitialPage} from "./pages/initial/initial";
import {PAGES} from "./pages";

@Component({
    templateUrl: 'app.html'
})
export class EscApp {

    private logger: Logger;

    @ViewChild(Nav) nav: Nav;

    rootPage: any = InitialPage;
    pages: Array<{ title: string, component: any, activeWhenAuth: boolean, activeWhenNotAuth: boolean, icon: string }>;

    public _userDetails: UserDetails;

    private isAppStartEventTracked: boolean = false;


    constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen,
                private authService: AuthService,
                private userService: UserService,
                loggerFactory: LoggerFactory,
                private _config: EnvConfiguration,
                private contactService: ContactService,
                private pushService: PushNotificationService,
                private imgCacheService : ImgCacheService,
                private langService: LangService, private analyticService: AnalyticService) {

        this.initializeApp(loggerFactory);

        // Current pages
        this.pages = PAGES;
    }

    get authenticated() {
        return this._userDetails != null;
    }

    get fullyAuthenticated() {
        return this.authenticated && this._userDetails.termsAccepted;
    }

    initializeApp(loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("EscApp");
        this.platform.ready().then(() => {
            this.logger.info("Initializing app...");

            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            this.statusBar.styleDefault();
            this.langService.initTranslations();
            this.monitorAuthAndLoginStatus();
            this.pushService.initPushNotification();
            this.userService.getUserDetailsUpdates().subscribe(userDetails => {
                this._userDetails = userDetails;
            });

            this.imgCacheService.initImgCache().then(() => {
                this.splashScreen.hide();
            }, (error) => {
                this.logger.warn("Could not initialize cache for images: " + stringify(error) );
                this.splashScreen.hide();
            })

        });
    }




    openPage(item) {
        if (item.title == 'CONTACT_MENU') {
            this.analyticService.trackPageView('ContactPage');
            this.contactService.sendEmail(this.displayName, this._userDetails.prn);
        } else {
            this.nav.push(item.component).then(data => {
              this.analyticService.trackPageView(item.component);
            });
        }
    }

    logout() {
        this.nav.setRoot('LogoutPage');
    }

    get displayName(): string {
        if (this._userDetails != null) {
            let _displayName = "";
            if (this._userDetails.firstName != null) {
                _displayName = _displayName + this._userDetails.firstName;
            }
            if (this._userDetails.firstName != null) {
                if (_displayName.length > 0) {
                    _displayName = _displayName + " ";
                }
                _displayName = _displayName + this._userDetails.lastName;
            }
            if (_displayName.length > 0) {
                return _displayName;
            }
        }
        return "<Unknown>";
    }

    get userPRN(): string {
        if (this._userDetails != null) {
            return "PRN: " + this._userDetails.prn;
        }
    }

    private canChangePage(): boolean {
        // XXX first condition is needed once start using APP_INIT token
        return !this.nav.getActive() || !(this.nav.getActive().instance instanceof EcasWebCallbackPage);
    }

    private monitorAuthAndLoginStatus() {
        // This is the component that decides which page is displayed

        this.authService.getAuthenticationStatus()
            .take(1)
            .subscribe(status => {
                if (status === AuthenticationStatus.NOT_AUTHENTICATED) {
                    // XXX prevent changing the page to NotYetRegisteredPage while the app is actually
                    // on EcasWebCallbackPage (happens on login when using a desktop browser)
                    if (this.canChangePage()) {
                        this.selectPageForUnauthenticatedUser();
                    }

                } else if (status === AuthenticationStatus.AUTHENTICATED) {
                    this.userService.getUserDetails().take(1)
                        .subscribe((userDetails) => {
                           /* if (status === AuthenticationStatus.AUTHENTICATED) {
                                this.selectPageForAuthenticatedUser(userDetails);
                            }*/
                          this.trackAppStartEvent();
                          this.selectPageForAuthenticatedUser(userDetails);
                        });
                }
            });

        this.authService.getAuthenticationStatus()
            .subscribe(status => {
                if (status === AuthenticationStatus.NOT_AUTHENTICATED) {
                    this.cleanUser();
                }
            });
    }


  private trackAppStartEvent() {
    // Delayed so that app stared with app info and language
    if (!this.isAppStartEventTracked) {
      setTimeout(()=> {
        this.analyticService.trackEvent('AppStart');
        this.isAppStartEventTracked = true;
      }, 1000);
    }

  }

  private selectPageForAuthenticatedUser(userDetails: UserDetails) {
        this.logger.debug("selectPageForAuthenticatedUser(...)");
        if (userDetails.termsAccepted) {
            this.setRootPage(HomePage);
        } else {
            this.setRootPage('TermsConditionsPage');
        }
    }

    private selectPageForUnauthenticatedUser() {
        this.logger.debug("selectPageForUnauthenticatedUser()");
        this.setRootPage('NotRegisteredPage');
    }

    private setRootPage(page: any) {
        this.nav.setRoot(page);
    }

    private cleanUser() {
        this._userDetails = null;
    }

    public getAvatarUrl() {
        if (this._userDetails) {
            if (this._userDetails.avatarId) {
                return this._config.getAvatarUrl + this._userDetails.userIdStr + "?lastmodified=" + this._userDetails.avatarId;
            }
            return this._config.getAvatarUrl + this._userDetails.userIdStr;
        }
    }


}
