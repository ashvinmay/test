import {HTTP_INTERCEPTORS, HttpClient, HttpClientModule} from "@angular/common/http";
import {APP_INITIALIZER, ErrorHandler, NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {IonicStorageModule, Storage, StorageConfig} from "@ionic/storage";
import {EffectsModule} from "@ngrx/effects";
import {StoreModule} from "@ngrx/store";
import {StoreDevtoolsModule} from "@ngrx/store-devtools";
import {TranslateLoader, TranslateModule, TranslateService} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
import {IonicApp, IonicModule} from "ionic-angular";
import {EnvConfiguration} from "../env/env.configuration";
import {ActivitiesService} from "./activities/services/activities.service";
import {EscApp} from "./app.component";
import {CommunityCommonModule} from "./community/shared/community.common.module";
import {GalleryModal} from "./community/shared/gallery-modal/gallery-modal";
import {ZoomableImage} from "./community/shared/zoomable-image/zoomable-image";
import {AlertUtils} from "./core/alert-utils";
import {AnalyticService} from "./core/analytics/analytic.service";
import {AppInfoInterceptor} from "./core/app-info/appInfo.interceptor";
import {AppLanguageInterceptor} from "./core/app-info/appLanguage.interceptor";
import {EscAppVersion} from "./core/app-info/esc-app-version";
import {ErrorReporterHandler} from "./core/error-reporter/error-reporter.handler";
import {ErrorReporterService} from "./core/error-reporter/error-reporter.service";
import {EscCommonModule} from "./core/esc-common.module";
import {EscHttp} from "./core/http/esc-http";
import {LangService} from "./core/lang.service";
import {LoggerFactory} from "./core/logger/logger-factory";
import {LoggerModule} from "./core/logger/logger.module";
import {PermissionsService} from "./core/permissions.service";

import {PLUGIN_PROVIDERS} from "./core/plugins/providers"
import {StorageService} from "./core/storage-service";
import {TermsConditionsService} from "./login/pages/terms-and-conditions/terms-conditions.service";
import {AuthModule} from "./login/services/auth.module";
import {AuthService} from "./login/services/auth.service";
import {UserService} from "./login/services/user.service";
import {UserUpdateService} from "./login/services/user.update.service";
import {TokenInterceptor} from "./login/token.interceptor";
import {MyProfileCommonModule} from "./my-profile/my-profile.common.module";
import {BadgeService} from "./notification/services/badge.service";
import {DeviceService} from "./notification/services/device.service";
import {NotificationService} from "./notification/services/notification.service";
import {PushNotificationService} from "./notification/services/push-notification.service";
import {ContactService} from "./pages/contact/contact.service";
import {HomePage} from "./pages/home/home";
import {InitialPage} from "./pages/initial/initial";


export function createTranslateLoader(http: HttpClient) {
    return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}

const storageConfig: StorageConfig = {
    name: '_escstorage',
    storeName: '_esckv',
    driverOrder: ['sqlite', 'indexeddb', 'websql', 'localstorage']
};

export function provideTermsConditionService(loggerFactory: LoggerFactory, escHttp: EscHttp, config: EnvConfiguration, userService: UserService) {
    return new TermsConditionsService(loggerFactory, escHttp, config, userService);
}

export function provideErrorHandler(errorReporterService: ErrorReporterService) {
    return new ErrorReporterHandler(errorReporterService);
}



export function onAppInit(authService: AuthService): () => Promise<any> {
    return (): Promise<any> => {
        return Promise.all([authService.onAppInit()]);
    };
}

export function appInfoInterceptorFactory(appVersion: EscAppVersion, loggerFactory: LoggerFactory) {
  return new AppInfoInterceptor(appVersion, loggerFactory);
}

export function appLanguageInterceptorFactory(translateService: TranslateService, loggerFactory: LoggerFactory) {
  return new AppLanguageInterceptor(translateService, loggerFactory);
}

export function tokenInterceptorFactory(storage : Storage, loggerFactory: LoggerFactory) {
  return new TokenInterceptor(storage, loggerFactory);
}

@NgModule({
    declarations: [
        EscApp,
        InitialPage,
        HomePage,
        GalleryModal,
        ZoomableImage
    ],
    imports: [
        BrowserModule,
        HttpClientModule,

        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: (createTranslateLoader),
                deps: [HttpClient]
            }
        }),
        IonicModule.forRoot(EscApp, {tabsPlacement: 'top'}),
        IonicStorageModule.forRoot(storageConfig),
        LoggerModule.forRoot({
            prodMode: false,
            disabledLoggers: [
              // {name: "LangService"},
              {name: "PostService"},
              // {name: "TokenInterceptor"},
              // {name: "AppInfoInterceptor"},
              {name: "AppLanguageInterceptor"}
            ]
        }),
        AuthModule,
        EscCommonModule,
        CommunityCommonModule,
        MyProfileCommonModule,

        //ngrx
      StoreModule.forRoot({}),
      EffectsModule.forRoot([]),
      // Instrumentation must be imported after importing StoreModule
      StoreDevtoolsModule.instrument(), // NOTE: not used in production


    ],
    bootstrap: [IonicApp],
    entryComponents: [
        EscApp,
        InitialPage,
        HomePage,
        GalleryModal
    ],
    providers: [
        ErrorReporterService,

        {provide: ErrorHandler, useFactory: provideErrorHandler, deps: [ErrorReporterService]},

        EnvConfiguration,

        ...PLUGIN_PROVIDERS,

        PermissionsService,
        ContactService,
        UserUpdateService,
        StorageService,
        AlertUtils,
        NotificationService,
        PushNotificationService,
        DeviceService,
        BadgeService,
        LangService,
        AnalyticService,
        ActivitiesService,
        {
            provide: TermsConditionsService,
            useFactory: provideTermsConditionService,
            deps: [LoggerFactory, EscHttp, EnvConfiguration, UserService]
        },
        // { provide: LOCALE_ID, useFactory: localeIdFactory, deps: [UserService] },
        {provide: APP_INITIALIZER, useFactory: onAppInit, multi: true, deps: [AuthService]},
        {
          provide: HTTP_INTERCEPTORS,
          useFactory: appInfoInterceptorFactory,
          deps: [EscAppVersion, LoggerFactory],
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useFactory: appLanguageInterceptorFactory,
          deps: [TranslateService, LoggerFactory],
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useFactory: tokenInterceptorFactory,
          deps: [Storage, LoggerFactory],
          multi: true
        }
    ]
})
export class AppModule {
}
