import {Component} from '@angular/core';
import {IonicPage, ItemSliding, NavController, NavParams, AlertController} from 'ionic-angular';
import {AnalyticService} from "../core/analytics/analytic.service";
import {PostService} from "../community/services/post.service";
import {NotificationService} from "./services/notification.service";
import {TranslateService} from "@ngx-translate/core";
import {Notification} from "./notification.model";
import {AlertUtils} from "../core/alert-utils";
import {DatePipe} from "@angular/common";
import {Logger} from "../core/logger/logger";
import {LoggerFactory} from "../core/logger/logger-factory";
import {Subscription} from "rxjs/Subscription";
import {UserService} from "../login/services/user.service";
import {StatusBar} from "@ionic-native/status-bar";


@IonicPage()
@Component({
    selector: 'page-notification',
    templateUrl: 'notification.html'
})
export class NotificationPage {
    private logger: Logger;

    public notifications: Array<Notification> = [];
    public unreadCount: number = 0;
    private subscriptions: Array<Subscription>;
    infinite: boolean = true;
    showLoadingSpinner: boolean = false;

    constructor(public navCtrl: NavController, public navParams: NavParams,
                private notificationService: NotificationService,
                private alertUtils: AlertUtils, private translate: TranslateService,
                private alertCtrl: AlertController,
                loggerFactory: LoggerFactory,
                private userService: UserService,
                private postService: PostService,
                private statusBar: StatusBar,
                private analyticService: AnalyticService) {
        this.logger = loggerFactory.getLogger("NotificationPage");
    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad NotificationPage');
        this.subscriptions = [];
        this.subscriptions.push(this.notificationService.subscribeToNotificationsUpdates().subscribe(
            notificationsArray => {
                this.logger.debug("New count " + notificationsArray.length);
                this.notifications = notificationsArray;
            }
        ));
        this.subscriptions.push(this.notificationService.subscribeToUnreadCountUpdates().subscribe(
            count => {
                this.logger.debug("New count for unread is " + count);
                this.unreadCount = count;
            }
        ));
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#0F306B');
        this.statusBar.styleLightContent();

        this.showLoading();
        this.notificationService.getNotifications().finally(() => {
            this.hideLoading()
        }).subscribe(
            (data) => {
            },
            (err) => {
                this.alertUtils.handleGetPostsError(err);
                this.navCtrl.pop();
            });
    }

    ionViewWillUnload() {
        console.log("this.subscriptions.forEach unsubscribe");
        // Prevent memory leak when component destroyed
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
    }

    getNotificationTime(date: any): any {
        let datePipe = new DatePipe(this.translate.currentLang);
        return datePipe.transform(new Date(date), 'dd.MM.yyyy - hh:mm');
    }

    doRefresh(refresher) {
        this.logger.debug('Refreshing...');
        this.notificationService.getNotifications().finally(() => {
            if (refresher) refresher.complete();
        }).subscribe(
            (data) => {
                this.notifications = data;
                this.infinite = true;
            },
            (err) => {
                this.alertUtils.handleGetPostsError(err);
            });

    }

    openLink(notification: Notification) {
        if ("PORTAL" === notification.type || "NORMAl" === notification.type) {
            if (notification.read){
                if (notification.link) {
                    this.alertUtils.showConfirmForPortal(notification.link);
                }
            } else {
                this.notificationService.markAsRead(notification.notificationIdStr).subscribe(data => {
                    if (notification.link) {
                        this.alertUtils.showConfirmForPortal(notification.link);
                    }
                });
            }
        }
        if ("COMMUNITY" === notification.type) {
            if (!notification.read) {
                this.notificationService.markAsRead(notification.notificationIdStr).subscribe(data => {
                });
            }
            // Get user info
            this.userService.getUserDetails()
                .subscribe(userDetails => {
                    if (notification.postIdStr) {
                        this.postService.getPostForNotification(notification.postIdStr).subscribe(post => {
                            if (post.status === "COMPLETED") {
                                this.viewPost(post, userDetails);
                            } else {
                                let msg = this.translate.instant('DELETED_POST_MSG');
                                this.alertUtils.showToastAlert(msg, "esc-toast-error");
                            }
                        })
                    } else {
                        this.viewMyJournal(userDetails);
                    }
                });
        }
    }

    private viewMyJournal(userDetails) {
        // Set userId param for MyJournal
        let params = {
            userId: userDetails.userIdStr
        };
        this.navCtrl.push('CommunityProfilePage', params).then(data => {
            let pageDetails = {
                "userId": userDetails.userIdStr
            };
            this.analyticService.trackPageView('CommunityProfilePage', pageDetails);
        });
    }

    private viewPost(post, userDetails) {
        this.navCtrl.push('ViewPostPage', {
            post: post,
            userDetails: userDetails,
            lastComment: false,
            showKeyboard: false
        }).then(data => {
            let pageDetails = {
                "postId": post.postIdStr
            };
            this.analyticService.trackPageView('ViewPostPage', pageDetails);
        });
    }

    isUnread(read: boolean) {
        if (read) {
            return false;
        }
        return true;
    }

    trackNotificationByFn(index, notification: Notification) {
        return notification.notificationIdStr;
    }

    onDelete(swipingItem?: ItemSliding, notificationId?: string) {
        swipingItem.close();
        this.notificationService.deleteNotification(notificationId).subscribe(data => {

        });
    }

    onRead(swipingItem?: ItemSliding, notificationId?: string) {
        swipingItem.close();
        this.notificationService.markAsRead(notificationId).subscribe(data => {

        });
    }

    markAllDelete() {
        this.showConfirmDeleteAll();
    }

    public fetchOlderNotifications(loader) {
        this.logger.debug('Loading more...');
        this.notificationService.getOldNotifications()
            .finally(() => {
                if (loader) loader.complete();
            })
            .subscribe(
                (data) => {
                    if (!data) {
                        this.infinite = false;
                    } else {
                        this.infinite = true;
                    }
                },
                (err) => {
                    this.alertUtils.handleGetPostsError(err);
                });
    }

    private showLoading() {
        this.showLoadingSpinner = true;
    }

    private hideLoading() {
        this.showLoadingSpinner = false;
    }

    private showConfirmDeleteAll() {
        let alert = this.alertCtrl.create({
            message: this.translate.instant('MARK_ALL_NOTIF_READ_MSG'),
            buttons: [
                {
                    text: this.translate.instant('GLOBAL_CANCEL'),
                    role: 'cancel',
                    handler: () => {
                    }
                },
                {
                    text: this.translate.instant('GLOBAL_OK'),
                    role: 'cancel',
                    handler: () => {
                        this.markAllAsRead();
                    }
                }
            ]
        });
        alert.present();
    }

    private markAllAsRead() {
        this.logger.debug("Marking all notification as read");
        this.notificationService.markAllAsRead().subscribe((data) => {
            this.logger.debug("Marked all notification as read");
        });
    }

}