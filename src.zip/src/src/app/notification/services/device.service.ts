import {Injectable} from "@angular/core";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {EnvConfiguration} from "../../../env/env.configuration";
import {EscHttp} from "../../core/http/esc-http";
import stringify from "fast-safe-stringify";

@Injectable()
export class DeviceService {
    private logger: Logger;

    constructor(public escHttp: EscHttp, private config: EnvConfiguration,
                loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("DeviceService");
    }

    public register(token:string): void {
        this.logger.debug("register device ....");
        let url = this.config.registerDeviceUrl;
        let json = this.buildJsonDevice(token);
        this.escHttp.postJson<any>(url,json)
            .subscribe(response => {
                //if (response.ok) {
                    this.logger.debug(`Device registered successfully: `, response);
                //}
            },
            error => {
                this.logger.error("Error registering device: " + stringify(error));
            });
    }

    private buildJsonDevice(token: String) {
        return {
            "deviceToken": token
        }
    }
}
