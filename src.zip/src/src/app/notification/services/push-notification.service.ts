import stringify from "fast-safe-stringify";
import {Push, PushObject, PushOptions} from "@ionic-native/push";
import {Injectable, NgZone} from "@angular/core";
import {App, Platform} from "ionic-angular";
import {EnvConfiguration} from "../../../env/env.configuration";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {DeviceService} from "./device.service";
import {NotificationService} from "./notification.service";
import {AuthService} from "../../login/services/auth.service";
import { AuthenticationStatus } from "../../login/auth.models";
import {UserService} from "../../login/services/user.service";
import {CommunityProfilePage} from "../../community/pages/community-profile/community-profile";
import {NotificationPage} from "../notification";
import {BadgeService} from "./badge.service";

@Injectable()
export class PushNotificationService {
    private logger: Logger;

    private processedNotifIds: Array<string> =[];

    constructor(private deviceService : DeviceService,
                public push: Push, public platform: Platform,
                private userService: UserService,
                private notificationService: NotificationService,
                 private authService: AuthService,
                private app: App,
                private zone:NgZone,
                private badgeService: BadgeService,
                private config : EnvConfiguration,
                loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("PushNotificationService");
    }

    public initPushNotification() {
        this.authService.getAuthenticationStatus()
            .subscribe(status => {
               if (status === AuthenticationStatus.AUTHENTICATED) {
                          this.init();
                }
            });

        this.notificationService.subscribeToUnreadCountUpdates().subscribe(count => {
                this.logger.debug("New count for unread is "+ count)
                this.badgeService.setBadgeCount(count);
            }, () => {});
    }

    private init() {
        if (!this.platform.is('cordova')) {
            this.logger.warn('Push notifications not initialized. Cordova is not available - Run in physical device');
            return;
        }
        const options: PushOptions = this.createPushOptions();
        const pushObject: PushObject = this.push.init(options);

        pushObject.on('registration').subscribe((data: any) => {
            this.logger.debug(data);
            this.logger.debug('device token -> ' + data.registrationId);
            this.deviceService.register(data.registrationId);

        });

        pushObject.on('notification').subscribe((data: any) => {
            this.logger.debug("Notification received data" + stringify(data))
            let notificationId = data.additionalData.notId;
            if(this.wasNotificationNotProcessed(notificationId)) {
                this.markNotificationAsProcessed(notificationId);
                this.notificationService.getNotifications()
                    .finally(()=>{
                        pushObject.finish(notificationId).then(() => {
                            this.notificationReceiveHandler(data);
                        }, (err: any) => {
                            this.logger.error("something went wrong with push.finish for ID =", notificationId, err);
                        });
                    })
                    .subscribe(() => {}, () => {});

            } else {
                // User has pressed on a notification previously processed
                pushObject.finish(notificationId).then(() => {
                    this.navigateToPage(data.additionalData.notFrom, data.additionalData.notId);
                }, (err: any) => {
                    this.logger.error("something went wrong with re-processing the push.finish for ID =", notificationId, err);
                });

            }

        });

        pushObject.on('error').subscribe(error => console.error('Error with Push plugin' + error));
    }

    private createPushOptions() {
        return {
            android: {
                senderID: this.config.fcmAndroidSenderId, // '29567772872' - Digit
                forceShow: false,
                sound: true,
            },
            ios: {
                alert: 'true',
                sound: 'true',
                badge: 'true'
            },
            windows: {}
        };
    }

    private wasNotificationNotProcessed(notificationId: string) {
        return this.processedNotifIds.indexOf(notificationId) < 0;
    }

    private markNotificationAsProcessed(notificationId: string) {
        this.processedNotifIds.push(notificationId)
    }

    private markNotificationAsRead(notificationId: string) {
        this.notificationService.markAsReadAuto(notificationId);
    }

    openMyJournal() {
        // Get user info
        this.userService.getUserDetails().take(1)
            .subscribe(userDetails => {
                // Set userId param for MyJournal
                let params = {
                    userId: userDetails.userIdStr
                };
                this.goToPage('CommunityProfilePage', params);
            });
    }

    private goToPage(page, params?: any) {
        this.zone.run(() => {
            this.app.getRootNav().push(page, params);
        });
    }

    private notificationReceiveHandler(data: any) {
        if (data.additionalData.foreground) {
            /**
             * This block is reached when a push notification is received when the app is in foreground.
             * Depending on the design of your app, you might want to save the incoming data to the localstorage here.
             * That's not really what your question is about, but I thought mentioning it would give a better picture.
             */
           /* this.notificationService.getNotifications().subscribe(() => {}, () => {});
            this.notificationService.getUnreadCount().subscribe(() => {}, () => {});*/
        }
        else {
            if (data.additionalData.coldstart) {
                /**
                 * This block is reached when a push notification is tapped on *AND*
                 * the app is closed (ie. Not even in background).
                 */
                if(this.platform.is("ios")) {
                    this.navigateToPage(data.additionalData.notFrom, data.additionalData.notId);
                }
                //this.navigateToPage(data.additionalData.notFrom, data.additionalData.notId);


            }
            else {
                /**
                 * The following block is reached in the following two scenarios:
                 * 1. A push notification is tapped on *AND* the app is in background.
                 * 2. A push notification with "content-available=1" is received while the app is in background. (iOS only)
                 *
                 * Therefore, for iOS devices, both of the above two scenarios can occur for an individual push notification.
                 *
                 * For Android, it's always the first scenario as the other one is not applicable.
                 */

                // Here we check for the existence of the incoming data in the localstorage and, with that, we determine
                // which scenario of the two possible is happening.
                // this.navigateToPage(data.additionalData.notFrom, data.additionalData.notId);
                if (this.platform.is("ios")) {
                    this.navigateToPage(data.additionalData.notFrom, data.additionalData.notId);
                }
            }
        }
    }

    private navigateToPage(notificationFrom:string, notificationId?:string) {
        if('COMMUNITY' == notificationFrom) {
            if(!this.isCurrentPage(CommunityProfilePage)) {
                if (notificationId) {
                    this.markNotificationAsRead(notificationId);
                }
                this.openMyJournal();
            }
        } else {
            if(!this.isCurrentPage(NotificationPage)) {
                this.goToPage('NotificationPage');
            }
        }
    }

    private isCurrentPage(comp:any) : boolean {
        if(this.app.getActiveNav() &&
            this.app.getActiveNav().getActive() &&
            this.app.getActiveNav().getActive().instance instanceof comp) {
                    return true;
        }
        return false;
    }
}
