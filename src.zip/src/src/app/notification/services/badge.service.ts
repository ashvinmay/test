import {Injectable} from "@angular/core";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Badge} from "@ionic-native/badge";

@Injectable()
export class BadgeService {
    private logger: Logger;

    constructor(loggerFactory: LoggerFactory, private badge: Badge) {
        this.logger = loggerFactory.getLogger("BadgeService");
    }

    public setBadgeCount(count: number) : void {
        this.logger.debug("Received badge count :", count);
        this.badge.set(count);
    }
}
