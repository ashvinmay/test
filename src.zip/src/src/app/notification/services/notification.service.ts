import {DatePipe} from "@angular/common";
import { NgZone, Injectable} from "@angular/core";
import {TranslateService} from "@ngx-translate/core";
import "rxjs/add/operator/map";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import {Observable} from "rxjs/Observable";
import {EscHttp} from "../../core/http/esc-http";
import {EnvConfiguration} from "../../../env/env.configuration";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Notification} from "../notification.model";


@Injectable()
export class NotificationService {
    private logger: Logger;
    public notifications: Array<Notification> = [];
    private subjectNotificationsUpdates: BehaviorSubject<Array<Notification>>;
    private subjectUnreadCount= new BehaviorSubject<number>(0);
    public unReadCount: number = 0;
    public totalCount: number =0;
    private oldestNotificationTime: string;

    constructor(public escHttp: EscHttp, private config: EnvConfiguration,
                loggerFactory: LoggerFactory, private zone: NgZone,
                private translateService: TranslateService,) {
        this.logger = loggerFactory.getLogger("NotificationService");
        this.subjectNotificationsUpdates = new BehaviorSubject(this.notifications);
    }

    public subscribeToNotificationsUpdates(): Observable<Array<Notification>> {
        return this.subjectNotificationsUpdates.asObservable();
    }

    public subscribeToUnreadCountUpdates(): Observable<number> {
        return this.subjectUnreadCount.asObservable();
    }


    public getNotifications() : Observable<Array<Notification>> {
        this.logger.debug("getNotifications....");
        let url = this.config.notificationsUrl;
        return this.escHttp.getJson<NotificationsResponse>(url)
            .map(res => {
                this.logger.debug("getNotifications Result: ", res);
                this.notifications =  this.mapNotifications(res.notifications);
                this.unReadCount = res.unreadCount;
                this.totalCount = res.totalCount;
                this.updateNotifications();
                this.updateUnreadCount();
                return this.notifications;
            });
    }

    public getOldNotifications() : Observable<Array<Notification>> {
        this.logger.debug("getOldNotifications....");
        let url = this.config.notificationsUrl;
        return this.escHttp.getJson<NotificationsResponse>(url, {"timeSince": this.oldestNotificationTime})
            .map(res => {
                this.logger.debug("getOldNotifications Result: ", res);
                //this.logger.debug("getNotifications Result body: \n" + stringify(res));

                this.notifications =  this.notifications.concat(this.mapNotifications(res.notifications));
                this.unReadCount =  res.unreadCount;
                this.totalCount = res.totalCount;
                this.updateNotifications();
                this.updateUnreadCount();
                return this.notifications;
            })
    }

    private updateNotifications() {
        if(this.notifications.length > 0) {
            this.oldestNotificationTime = this.notifications[this.notifications.length - 1].date;
            this.zone.run(() => {
                this.updateTimeSince(this.notifications);
                this.subjectNotificationsUpdates.next([...this.notifications]);
            });
        }
    }

    public getUnreadCount() : Observable<number> {
        this.logger.debug("getNotifications....");
        let url = this.config.unreadnotificationscountUrl;
        return this.escHttp.getJson<string>(url)
            .map(res => {
                this.logger.debug("getUnreadNotifications count: " + res);
                this.unReadCount = Number(res);
                this.updateUnreadCount();
                return this.unReadCount;
            })
    }

    private updateUnreadCount() {
        this.zone.run(() => {
            this.subjectUnreadCount.next(this.unReadCount);
        });
    }

    public deleteNotification(notificationIdStr: String): Observable<any> {
        this.logger.debug("delete notification notificationId: " + notificationIdStr);
        let url = this.config.notificationsUrl + "/" +  notificationIdStr;
        return this.escHttp.delete(url)
            .map(() => {
                this.logger.debug("deleteNotification Result: success");
                this.updateListAfterDelete(notificationIdStr);
            });
    }

    private updateListAfterDelete(notificationIdStr: String) {
        let index = this.findIndex(notificationIdStr);
        this.logger.debug("deleteNotification index is : " + index);
        if (index >= 0) {
            if (this.notifications[index].read == false) {
                this.unReadCount = this.unReadCount - 1;
                this.subjectUnreadCount.next(this.unReadCount);
            }
            this.notifications.splice(index, 1);
            this.subjectNotificationsUpdates.next([...this.notifications]);
            this.fetchOldForDelete();
        }
    }

    private fetchOldForDelete() {
        if (this.notifications.length <= 10 && this.notifications.length < this.totalCount) {
            this.getOldNotifications().subscribe(() => {

            }, () => {

            })
        }
    }

    public markAsReadAuto(notificationIdStr: String): void {
        this.markAsRead(notificationIdStr).subscribe(() => {

        }, ()=> {

        });
    }


    public markAsRead(notificationIdStr: String): Observable<any> {
        this.logger.debug("Mark as read notification notificationId: " + notificationIdStr);
        let url = this.config.notificationsUrl + "/" + notificationIdStr + "/read";
        return this.escHttp.putJson(url)
            .map(() => {
                this.logger.debug("Mark as read notification Result: success");
                this.notifications
                    .filter(notif => {
                        return notif.notificationIdStr == notificationIdStr;
                    })
                    .map((findNotif: Notification) => {
                        findNotif.read = true;
                    });
                    this.subjectNotificationsUpdates.next([...this.notifications]);
                    this.unReadCount = this.unReadCount - 1;
                    this.subjectUnreadCount.next(this.unReadCount);
            });
    }


    public markAllAsRead(): Observable<any> {
      this.logger.debug("Mark all notification as read");
      let url = this.config.notificationsUrl + "markallread";
      return this.escHttp.putJson(url)
        .map(() => {
          this.logger.debug("Mark all notifications as read Result: success");
          this.notifications
            .map((findNotif: Notification) => {
              findNotif.read = true;
            });
          this.subjectNotificationsUpdates.next([...this.notifications]);
          this.unReadCount = 0;
          this.subjectUnreadCount.next(this.unReadCount);
        });
    }

    private findIndex(notificationIdStr): number {
        return this.notifications.findIndex(element => {
            return element.notificationIdStr == notificationIdStr;
        });
    }

    /**
     * Allows to not overwrite the Post entity
     */
    private mapNotifications(notifications: any): Array<Notification> {
        return notifications.map(
            (notification) => {
                return new Notification(notification);

            });
    }

    public updateTimeSince(notifications: Array<Notification>) {
        if (notifications && notifications.length > 0) {
            let now: Date = new Date();
            let datePipe = new DatePipe(this.translateService.currentLang);
            notifications.forEach((element: Notification) => {
                element.updateTimeSince(now, datePipe, this.translateService);
            });
        }
    }

}

export interface NotificationsResponse {
  "unreadCount" : number,
  "notifications" : Array<string>,
  "totalCount" : number
}
