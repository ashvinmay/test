import {DatePipe} from "@angular/common";
import {TranslateService} from "@ngx-translate/core";


export class Notification {
    notificationIdStr: string;
    userIdStr: string;
    message: string;
    link: string;
    date: any;
    title: string;
    read: boolean;
    type: string;
    timeSince: string;
    postIdStr: string;

    constructor(data?: any) {
        Object.assign(this, data);
    }

    public updateTimeSince(now: Date, datePipe: DatePipe, translate: TranslateService) {
        this.timeSince = Notification.calculateTimeSince(new Date(this.date), now, datePipe, translate);
    }

    private static calculateTimeSince(date: any, now: any, datePipe: DatePipe, translate: TranslateService): string {
        let seconds = Math.floor((now - date) / 1000);
        let interval = Math.floor(seconds / 86400);
        if (interval >= 1) {
            return datePipe.transform(date, 'dd MMM yyyy');
        }
        interval = Math.floor(seconds / 3600);
        if (interval > 12) {
            return datePipe.transform(date, 'dd MMM yyyy');
        }
        if (interval >= 1) {
            let parameters = {hour: interval};
            let key = (interval == 1 ? "HOUR_AGO" : "HOURS_AGO");
            return translate.instant(key, parameters);
        }
        interval = Math.floor(seconds / 60);
        if (interval >= 1) {
            let parameters = {min: interval};
            let key = (interval == 1 ? "MIN_AGO" : "MINS_AGO");
            return translate.instant(key, parameters);
        }
        return translate.instant("JUST_NOW");
    }

}
