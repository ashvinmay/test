import {Component} from '@angular/core';
import {IonicPage, NavController, NavParams} from 'ionic-angular';
import {Like} from "../../models/like.model";
import {AnalyticService} from "../../../core/analytics/analytic.service";
import {CommunityService} from "../../services/community.service";
import {AlertUtils} from "../../../core/alert-utils";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {Logger} from "../../../core/logger/logger";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-people-likes',
    templateUrl: 'people-likes.html',
})
export class PeopleLikesPage {

    private logger: Logger;

    pageTitle: string;

    private postId: any;
    private commentId: any;
    private lastLikeId: string = undefined;

    likes: Array<Like> = [];
    infinite: boolean = true;
    showLoadingSpinner: boolean = true;

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                loggerFactory: LoggerFactory,
                private alertUtils: AlertUtils,
                private statusBar: StatusBar,
                private communityService: CommunityService,
                private analyticService: AnalyticService) {
        this.logger = loggerFactory.getLogger("CommunityPage");

        this.postId = this.navParams.get("postId");
        this.commentId = this.navParams.get("commentId");
    }

    ionViewDidLoad() {
        this.subscribeToPostsUpdates();
        this.pageTitle = this.commentId ? "COMMENT_LIKES_TITLE" : "POST_LIKES_TITLE";
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#14ADE5');
        this.statusBar.styleLightContent();
    }

    ionViewWillUnload() {
        // Prevent memory leak when component destroyed
        this.logger.debug("IonViewWillUnload...");
    }

    private subscribeToPostsUpdates() {
        this.showLoading();
        // Load initial posts
        this.fetchOlderLikes();
    }

    goToCommProfile(userId: string) {
        this.navCtrl.push('CommunityProfilePage', {
            userId: userId
        }).then(data => {
            let pageDetails = {
                "userId": userId
            };
            this.analyticService.trackPageView('CommunityProfilePage', pageDetails);
        });
    }

    fetchOlderLikes(loader?: any) {
        this.logger.debug('Loading more...');
        if (this.commentId) {
            this.communityService.fetchCommentLikes(this.postId, this.lastLikeId, this.commentId)
                .finally(() => {
                    this.hideLoading();
                    if (loader) loader.complete();
                })
                .subscribe(
                    (likes: Array<Like>) => {
                        this.handleLikes(likes);
                    },
                    (err) => {
                        this.handleGetPostsError(err);
                    });
        } else if (this.postId) {
            this.communityService.fetchPostLikes(this.postId, this.lastLikeId)
                .finally(() => {
                    this.hideLoading();
                    if (loader) loader.complete();
                })
                .subscribe(
                    (likes: Array<Like>) => {
                        this.handleLikes(likes);
                    },
                    (err) => {
                        this.handleGetPostsError(err);
                    });
        }
    }

    private handleLikes(likes: Array<Like>) {
        if (likes.length == 0) {
            this.infinite = false;
        }
        this.likes = [...this.likes.concat(likes)];
        // Update last likeId, for next call
        if (likes && likes.length > 0) {
            this.lastLikeId = likes[likes.length - 1].likeIdStr;
        } else {
            this.lastLikeId = undefined;
        }
    }

    private handleGetPostsError(error: any) {
        this.alertUtils.handleGetPostsError(error);
    }

    private showLoading() {
        this.showLoadingSpinner = true;
    }

    private hideLoading() {
        this.showLoadingSpinner = false;
    }

}