import {NgModule} from '@angular/core';
import {IonicPageModule} from 'ionic-angular';
import {PeopleLikesPage} from './people-likes';
import {PersonLikeComponent} from "../../components/person-like/person-like";
import {PersonLikeListComponent} from "../../components/person-like-list/person-like-list";
import {TranslateModule} from "@ngx-translate/core";

@NgModule({
    declarations: [
        PersonLikeComponent,
        PersonLikeListComponent,
        PeopleLikesPage,
    ],
    imports: [
        IonicPageModule.forChild(PeopleLikesPage),
        TranslateModule.forChild()
    ],
})
export class PeopleLikesPageModule {
}
