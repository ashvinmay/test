import {ChangeDetectorRef, Component, ViewChild} from '@angular/core';
import {IonicPage, NavController, NavParams} from 'ionic-angular';
import {Post} from "../../models/post";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {ProjectType} from "../../models/project-type.model";
import {PostService} from "../../services/post.service";
import {AlertUtils} from "../../../core/alert-utils";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-edit-post',
    templateUrl: 'edit-post.html'
})
export class EditPostPage {

    // AutoFocus + show Keyboard
    // http://stackoverflow.com/questions/39612653/set-focus-on-an-input-with-ionic-2
    @ViewChild('focusInput') inputTitle;

    private logger: Logger;
    private post: Post;
    private title: string = "";
    private description: string = "";
    public projectTypes: Array<ProjectType>;
    public projectType: ProjectType;

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                loggerFactory: LoggerFactory,
                private postService: PostService,
                private alertUtils: AlertUtils,
                private statusBar: StatusBar,
                private cdRef: ChangeDetectorRef) {

        this.logger = loggerFactory.getLogger("EditPostPage");
        this.post = navParams.get('post');
        this.title = this.post.title || "";
        this.description = this.post.description || "";
        this.projectType = this.post.projectType;
        this.logger.info("Existing project type -----", this.projectType)
    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad EditPostPage');
        this.postService.getProjectTypes().subscribe(projectTypes => {
            this.projectTypes = projectTypes;
        });
        this.showKeyboard();
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#14ADE5');
        this.statusBar.styleLightContent();
    }

    /* =============
     * HANDLING PAGE
     * ============= */

    savePost() {
        this.postService.savePost(this.post, this.title, this.description, this.projectType).subscribe(
            (data) => {
                this.navCtrl.pop();
            },
            (err) => {
                this.alertUtils.handleGetPostsError(err);
            });
    }

    changeTitle(value: string) {
        this.cdRef.detectChanges();
        this.title = value.length > 140 ? value.substring(0, 140) : value;
    }

    changedDescription(value: string) {
        this.cdRef.detectChanges();
        this.description = value.length > 400 ? value.substring(0, 400) : value;
    }

    private showKeyboard() {
        setTimeout(() => {
            this.inputTitle.setFocus();
        }, 1000); //a least 150ms.
    }


    comparePT(pt1: ProjectType, pt2: ProjectType): boolean {
        return pt1 && pt2 ? pt1.id === pt2.id : pt1 === pt2;
    }

}