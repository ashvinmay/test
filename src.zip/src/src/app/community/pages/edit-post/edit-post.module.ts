import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {EditPostPage} from "./edit-post";
import {ElasticModule} from "angular2-elastic";

@NgModule({
    declarations : [
        EditPostPage
    ],
    imports : [
        ElasticModule,
        IonicPageModule.forChild(EditPostPage),
        TranslateModule.forChild()
    ]
})
export class EditPostPageModule {}