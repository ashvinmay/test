import {Injectable} from "@angular/core";
import {Logger} from "../../../core/logger/logger";
import {EscHttp} from "../../../core/http/esc-http";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {Observable, Subject} from "rxjs";
import {CommunityProfile, EscLink} from "./community-profile.model";
import {EscFiles} from "../../../core/http/esc-files";
import {Platform} from "ionic-angular";
import {File} from '@ionic-native/file';
import {UserService} from "../../../login/services/user.service";
import stringify from "fast-safe-stringify";
import {AlertUtils} from "../../../core/alert-utils";
import {EnvConfiguration} from "../../../../env/env.configuration";

@Injectable()
export class CommunityProfileService {

    private logger: Logger;
    private communityProfile: CommunityProfile;
    private subjectUpdateProfile = new Subject<CommunityProfile>();

    constructor(private escHttp: EscHttp,
                private escFiles: EscFiles,
                private file: File,
                private platform: Platform,
                private userService: UserService,
                private alertUtils: AlertUtils,
                private config: EnvConfiguration,
                loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("CommunityProfileService");
    }

    public getCommunityProfile(userId: string): Observable<CommunityProfile> {
        this.logger.debug("Get community profile for user: " + userId);
        let url = this.config.getCommunityProfileUrl + userId;
        //TODO : Cast to community profile object
        return this.escHttp.getJson<any>(url)
            .map(res => {
                this.logger.debug("getCommunityProfile Result: ", res);
                this.communityProfile = new CommunityProfile(res);
                return this.communityProfile;
            });
    }

    public subscribeToCommunityProfileUpdate(): Observable<CommunityProfile> {
        return this.subjectUpdateProfile.asObservable();
    }

    public saveCommunityProfile(city: string, country: string): Observable<CommunityProfile> {
        let communityProfileUpdate = {
          userId : this.communityProfile.userIdStr,
          missionCity: city,
          missionCountryCode: country
        };

        let url = this.config.saveCommunityProfileUrl;
        return this.escHttp.putJson<CommunityProfile>(url,communityProfileUpdate)
            .map(res => {
                this.logger.debug("saveCommunityProfile Result: ", res);
                // Update the internal Profile on success
                this.communityProfile.mission = res.mission
                this.subjectUpdateProfile.next(this.communityProfile);
                return this.communityProfile;
            });
    }

    /* ====== */
    /* AVATAR */
    /* ====== */

    public deleteAvatar(userId: string) {
        this.logger.debug("Delete avatar for userId: " + userId);
        let url = this.config.deleteAvatarUrl;
        return this.escHttp.delete(url)
            .map(res => {
                this.logger.debug("deleteAvatar: success");
                this.userService.getUserDetails().subscribe((userDetails) => {
                    userDetails.avatarId = undefined;
                    this.userService.updateUserDetails(userDetails).subscribe((data) => {
                        this.communityProfile.hasAvatar = false;
                        this.subjectUpdateProfile.next(this.communityProfile);
                    });
                });
            });
    }

    // https://github.com/dtaalbers/ionic-2-examples/blob/master/file-transfer-upload/app/pages/uploading/uploading.ts
    public uploadAvatar(fileUri: string): Promise<any> {
        this.logger.debug("avatarUpload");
        let url = this.config.addAvatarUrl;
        return this.escFiles.uploadJpeg(fileUri, url)
            .then((result: any) => {
                this.logger.debug("Upload success: " + stringify(result));
                this.userService.getUserDetails().subscribe((userDetails) => {
                    userDetails.avatarId = result.response;
                    this.userService.updateUserDetails(userDetails).subscribe((data) => {
                        this.communityProfile.hasAvatar = true;
                        this.subjectUpdateProfile.next(this.communityProfile);
                    });
                });
                // Delete cached file
                this.removeFile(fileUri);
            }).catch((error: any) => {
                this.logger.debug("Upload failed: " + stringify(error));
                this.alertUtils.handleGetPostsError(error);
                // Delete cached file
                this.removeFile(fileUri);
            });
    }

    private removeFile(fileName: string) {
        if (!fileName) return;

        // this.logger.debug("externalDataDirectory=" + this.file.externalDataDirectory);
        // this.logger.debug("externalCacheDirectory=" + this.file.externalCacheDirectory);
        // this.logger.debug("externalRootDirectory=" + this.file.externalRootDirectory);
        // this.logger.debug("externalApplicationStorageDirectory=" + this.file.externalApplicationStorageDirectory);
        // this.logger.debug("applicationStorageDirectory=" + this.file.applicationStorageDirectory);
        // this.logger.debug("applicationDirectory=" + this.file.applicationDirectory);
        // this.logger.debug("tempDirectory=" + this.file.tempDirectory);
        // this.logger.debug("dataDirectory=" + this.file.dataDirectory);
        // this.logger.debug("cacheDirectory=" + this.file.cacheDirectory);
        // this.logger.debug("syncedDataDirectory=" + this.file.syncedDataDirectory);
        // this.logger.debug("documentsDirectory=" + this.file.documentsDirectory);
        // this.logger.debug("sharedDirectory=" + this.file.sharedDirectory);
        // this.logger.debug("fileName=" + fileName);

        let directory;
        if (this.platform.is('android')) {
            directory = this.file.externalCacheDirectory;
        } else {
            directory = this.file.tempDirectory;
        }

        if (fileName.indexOf(directory) != -1) {
            let startIndex = directory.length;
            let endIndex = fileName.indexOf('?');
            if (endIndex != -1) {
                fileName = fileName.substr(startIndex, (endIndex - startIndex));
            } else {
                fileName = fileName.substr(startIndex);
            }
            this.logger.debug("fileName fixed=" + fileName);
        }

        this.file.removeFile(directory, fileName)
            .catch(() => {
            });
    }

  /* ================ */
  /* JOURNAL BG IMAGE */
  /* ================*/

  public deleteJournalBg(userId: string) {
    this.logger.debug("Delete journal bg image for userId: " + userId);
    let url = this.config.deleteJournalBgImageUrl;
    return this.escHttp.delete(url)
      .map(res => {
        this.logger.debug("delete Journal Background: success");
        this.userService.getUserDetails().subscribe((userDetails) => {
            this.communityProfile.hasJournalBgImg = false;
            // this.communityProfile._links.journalBgUrl.href = "";
            //TODO remove journal bg url
            this.subjectUpdateProfile.next(this.communityProfile);
          //});
        });
      });
  }

  // https://github.com/dtaalbers/ionic-2-examples/blob/master/file-transfer-upload/app/pages/uploading/uploading.ts
  public uploadJournalBg(fileUri: string): Promise<any> {
    this.logger.debug("journalBgImage Upload");
    let url = this.config.addJournalBackgroundImgUrl;
    return this.escFiles.uploadJpeg(fileUri, url)
      .then((result: any) => {
        this.logger.debug("Upload success: ", result);
        this.userService.getUserDetails().subscribe((userDetails) => {
            this.communityProfile.hasJournalBgImg = true;
            var journaBgImgLink = new EscLink(JSON.parse(result.response));
            this.communityProfile._links.journalBgUrl = journaBgImgLink;
            // result.headers["Location"] - only for ios
            this.subjectUpdateProfile.next(this.communityProfile);
        });
        // Delete cached file
        this.removeFile(fileUri);
      }).catch((error: any) => {
        this.logger.debug("Upload failed: " + stringify(error));
        this.alertUtils.handleGetPostsError(error);
        // Delete cached file
        this.removeFile(fileUri);
      });
  }

}
