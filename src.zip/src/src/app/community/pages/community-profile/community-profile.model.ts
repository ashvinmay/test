/**
 * Data transfer object (server model)
 */
export class CommunityProfileData {
  userIdStr: string;
  name: string;
  hasAvatar: boolean;
  hasJournalBgImg: boolean;
  journalBgImgDisapproved: boolean;
  mission : EscLocation;
  origin: EscLocation;
  postCount: number;
  _links : CommunityProfileLinksData
}

export interface EscLocation {
  "city" : string,
  "countryCode" : string
}

/**
 * For storing information for CommunityProfile
 */
export class CommunityProfile extends CommunityProfileData {
    //constructor(data: CommunityProfileData) {
    constructor(data: any) {
        super();
        Object.assign(this, data);
    }

}

export interface CommunityProfileLinksData {
  "journalBgUrl" : EscLink;
}

export class EscLink {
  "href" : string;

  constructor(data:any) {
    Object.assign(this, data);
  }
}
