import {Component, ViewChild} from "@angular/core";
import {TranslateService} from "@ngx-translate/core";
import {Content, IonicPage, Loading, NavController, NavParams} from 'ionic-angular';
import {Subscription} from "rxjs/Rx";
import {AnalyticService} from "../../../core/analytics/analytic.service";
import {UserDetails} from "../../../login/user.details";
import {UserService} from "../../../login/services/user.service";
import {AlertUtils} from "../../../core/alert-utils";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {Post} from "../../models/post";
import {ProjectType} from "../../models/project-type.model";
import {AvatarUiService} from "../../services/avatar-ui-service";
import {CommunityCommon} from "../../shared/community-common";
import {JournalBgImgUiService} from "../../services/journal-bg-img-ui-service";
import {PostService} from "../../services/post.service";
import {CommunityProfilePostsService} from "./community-profile-posts.service";
import {CommunityProfile} from "./community-profile.model";
import {CommunityProfileService} from "./community-profile.service";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-community-profile',
    templateUrl: 'community-profile.html'
})
export class CommunityProfilePage {

    @ViewChild(Content) content: Content;

    private logger: Logger;

    userDetails: UserDetails;
    posts: Array<Post> = [];
    loading: Loading;
    infinite: boolean = true;

    profileUserId: string;
    pageTitle: string;
    visibility: string;
    canPost: boolean = false;
    empty: boolean = false;
    communityProfile: CommunityProfile;

    progress: number;
    showProgressBar: boolean = false;
    showLoadingSpinner: boolean = false;
    public projectTypes: Array<ProjectType>;
    public selectedProjectTypeId : number = -1;
    private subscriptions: Array<Subscription> = [];

    constructor(public navCtrl: NavController, public navParams: NavParams,
                private communityProfilePostsService: CommunityProfilePostsService,
                private translateService: TranslateService,
                private userService: UserService,
                loggerFactory: LoggerFactory,
                private communityCommon: CommunityCommon,
                private alertUtils: AlertUtils,
                private communityProfileService: CommunityProfileService,
                private postService: PostService,
                private statusBar: StatusBar,
                private journalUiService: JournalBgImgUiService,
                private avatarUiService: AvatarUiService, private analyticService : AnalyticService) {

        this.logger = loggerFactory.getLogger("CommunityProfilePage");
        this.profileUserId = this.navParams.data.userId;
        this.pageTitle = "";
    }

    ionViewDidLoad() {
        this.logger.debug("ionViewDidLoad");
        this.logger.info("Initializing ImgCache...");
        this.subscribeToUserUpdates();
        this.getCommunityProfile();
        this.subscriptions.push(this.postService.subscribeToUploadProgress().subscribe((progress) => {
              this.progress = progress;
          }));
        this.subscriptions.push(this.postService.subscribeToShowUploadProgress().subscribe((showProgress) => {
              this.showProgressBar = showProgress;
              if (!showProgress) {
                  this.progress = 0;
              }
          }));
        this.subscriptions.push(this.postService.getProjectTypes().subscribe(projectTypes => {
          this.projectTypes = projectTypes;
        }));
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#0D7397');
        this.statusBar.styleLightContent();
    }

    ionViewWillUnload() {
        this.subscriptions.forEach(s => {
          if (s) s.unsubscribe();
        });
        this.subscriptions = [];
        this.communityProfilePostsService.unsubscribeFromPostsUpdates(this.profileUserId);
    }

    private getCommunityProfile() {
        this.logger.debug('Loading profile...');
        this.communityProfileService.getCommunityProfile(this.profileUserId).subscribe(
            communityProfile => {
                this.communityProfile = communityProfile;
                if (this.owner) {
                    this.pageTitle = this.translateService.instant("COMMUNITY_PROFILE_MY_JOURNAL");
                } else {
                    this.pageTitle = communityProfile.name;
                }
                // Load user posts
                this.subscribeToPostsUpdates();
            },
            (err) => {
                this.handleGetPostsError(err);
                this.navCtrl.pop();
            });
    }

    private subscribeToUserUpdates() {
      this.subscriptions.push(this.userService.getUserDetailsUpdates().subscribe(userDetails => {
            this.userDetails = userDetails;
            if (this.userDetails.userIdStr == this.profileUserId) {
                this.visibility = this.userDetails.visibility;
                this.canPost = this.userDetails.visibility == 'NORMAL';
            }
        }));
    }

    private subscribeToPostsUpdates() {
        //this.showLoading();
        this.showLoadingSpinner = true;
        this.communityProfilePostsService.subscribeToPostsUpdates(this.profileUserId).subscribe(
            (posts) => {
                this.posts = posts;
                this.empty = this.owner && this.posts.length == 0 && this.selectedProjectTypeId == -1;
            }
        );
        // Load initial user posts
        this.fetchNewerUserPosts();
    }

    public fetchNewerUserPosts() {
        this.logger.debug('Loading user posts...');
        this.communityProfilePostsService.fetchNewerUserPosts(this.profileUserId, this.selectedProjectTypeId)
            .finally(() => {
                this.showLoadingSpinner = false;
            }).subscribe(
            (data) => {
                this.infinite = true;
                this.empty = this.owner && this.posts.length == 0 && this.selectedProjectTypeId == -1;
            },
            (err) => {
                this.handleGetPostsError(err);
            });

    }

    public fetchOlderUserPosts(loader) {
        this.logger.debug('Loading more...');
        this.communityProfilePostsService.fetchOlderUserPosts(this.profileUserId, this.selectedProjectTypeId)
            .finally(() => {
                if (loader) loader.complete();
            }).subscribe(
            (data) => {
                if (!data) this.infinite = false;
            },
            (err) => {
                this.handleGetPostsError(err);
            });

    }

    get owner(): boolean {
        return this.userDetails.userIdStr == this.profileUserId;
    }

    get noAvatarForOwnerProfile(): boolean {
        return ((this.userDetails.userIdStr == this.profileUserId) && !this.communityProfile.hasAvatar);
    }

    get hasMissionLocation(): boolean {
        return this.hasMissionCityCountry();
    }

    get showMissionLocation(): boolean {
        if (this.owner && this.userDetails.acceptedOffer) {
            return true;
        } else if (this.hasMissionCityCountry()) {
            return true;
        }
        return false;
    }

    get hasOriginLocation(): boolean {
      return !!(this.communityProfile.origin.city || this.communityProfile.origin.countryCode);
    }


    private hasMissionCityCountry(): boolean {
        return !!(this.communityProfile.mission.city || this.communityProfile.mission.countryCode);
    }

    isUserBlocked(): boolean {
        return this.visibility == 'RESTRICTED';
    }

    isJournalBgImageDisapproved(): boolean {
        return this.communityProfile.journalBgImgDisapproved;
    }

    showBlockedUserMessage() {
        this.communityCommon.presentUserBlocked();
    }

    showDisapprovedJournalBgImageMessage() {
        this.communityCommon.presentJournalBgImageDisapproved();
    }

    showAddPostBottomSheet() {
        if (this.canPost) this.communityCommon.showAddPostBottomSheet(this.navCtrl);
    }

    public getAvatarUrl(): string {
        if (this.owner) {
            if (this.userDetails.avatarId) {
                return this.communityCommon.getAvatarUrl(this.profileUserId) + "?lastmodified=" + this.userDetails.avatarId;
            }
        }
        return this.communityCommon.getAvatarUrl(this.profileUserId);
    }

    public getBackgroundUrl(): string {
      return this.communityProfile._links.journalBgUrl.href;
    }

    openEditMissionLocation() {
        if (this.owner) {
            this.logger.debug("Edit mission location for userId: " + this.userDetails.userIdStr);
            this.navCtrl.push('EditLocationPage', {
                communityProfile: this.communityProfile
            }).then(data => {
              this.analyticService.trackPageView('EditLocationPage')
            });
        }
    }

    private handleGetPostsError(err: any) {
        this.alertUtils.handleGetPostsError(err);
    }

    showJournalBgImgBottomSheet() {
      if (this.userDetails.userIdStr != this.profileUserId) {
        return;
      }
      this.journalUiService.showBottomSheet(this.communityProfile, this.userDetails.userIdStr);
    }

    showBottomSheet() {
      if (this.userDetails.userIdStr != this.profileUserId) {
        return;
      }
      this.avatarUiService.showBottomSheet(this.communityProfile, this.userDetails.userIdStr);
    }

  filterByProjectType(): void {
    this.logger.debug("Selected project type id for filter is ", this.selectedProjectTypeId)
    this.showLoadingSpinner = true;
    this.fetchNewerUserPosts();
  }

}