import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {CommunityProfilePage} from "./community-profile";
import {CommunityToolBarModule} from "../../components/community-tool-bar/community-tool-bar.module";
import {PostListPageModule} from "../../components/post-list/post-list.module";
import {ProgressBarComponentModule} from "../../components/progress-bar/progress-bar.module";
import {PipesModule} from "../../../core/pipes/pipes.module";

@NgModule({
    declarations : [
        CommunityProfilePage
    ],
    imports : [
        IonicPageModule.forChild(CommunityProfilePage),
        TranslateModule.forChild(),
        CommunityToolBarModule,
        PostListPageModule,
        ProgressBarComponentModule,
        PipesModule.forRoot()
    ]
})
export class CommunityProfilePageModule {}
