import {Injectable, OnDestroy} from '@angular/core';
import {Post} from "../../models/post";
import {Observable} from "rxjs/Rx";
import {Subscription} from "rxjs/Subscription";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {CommunityCommon} from "../../shared/community-common";
import {PostService} from "../../services/post.service";
import {CommunityProfile} from "./community-profile.model";
import {CommunityProfileService} from "./community-profile.service";
import {Subject} from "rxjs/Subject";

@Injectable()
export class CommunityProfilePostsService implements OnDestroy {

    private logger: Logger;
    private selectedProjectTypeId: number = -1
    private mapPosts: Map<string, UserPosts> = new Map();
    private subscriptions: Array<Subscription>;

    constructor(loggerFactory: LoggerFactory,
                private communityCommon: CommunityCommon,
                private postService: PostService,
                private communityProfileService: CommunityProfileService) {

        this.logger = loggerFactory.getLogger("CommunityService");
        this.init();
    }

    private init() {
        this.subscriptions = [];

        let subscription = this.communityProfileService.subscribeToCommunityProfileUpdate()
            .subscribe((communityProfile: CommunityProfile) => {
                let userPosts = this.mapPosts.get(communityProfile.userIdStr);
                if (userPosts) {
                    userPosts.updateMissionLocation(communityProfile);
                }
            });
        this.subscriptions.push(subscription);

        subscription = this.postService.subscribeToDeletePost().subscribe(
            (post) => {
                let userPosts = this.mapPosts.get(post.userIdStr);
                if (userPosts) {
                    userPosts.deletePost(post);
                }
            });
        this.subscriptions.push(subscription);

        subscription = this.postService.subscribeToAddPost().subscribe(
            (post) => {
                // Reload user posts
                this.fetchNewerUserPosts(post.userIdStr, this.selectedProjectTypeId).subscribe();
            });
        this.subscriptions.push(subscription);

        subscription = this.postService.subscribeToUpdatePost().subscribe(
            (post) => {
                let userPosts = this.mapPosts.get(post.userIdStr);
                if (userPosts) {
                    userPosts.updatePost(post);
                }
            });
        this.subscriptions.push(subscription);
    }

    ngOnDestroy() {
        // Prevent memory leak when component destroyed
        for (let subscription of this.subscriptions) {
            subscription.unsubscribe();
        }
        this.subscriptions = [];
    }

    public subscribeToPostsUpdates(userId: string): Observable<Array<Post>> {
        this.logger.debug("subscribeToPostsUpdates for userId=" + userId);
        let userPosts = new UserPosts(this.communityCommon);
        this.mapPosts.set(userId, userPosts);
        return userPosts.asObservable();
    }

    public unsubscribeFromPostsUpdates(userId: string) {
        this.logger.debug("unsubscribeFromPostsUpdates for userId=" + userId);
        let userPosts = this.mapPosts.get(userId);
        if (userPosts) userPosts.clear();
        this.mapPosts.delete(userId);
    }

    public fetchNewerUserPosts(userId: string, projectTypeId: number) {
        this.logger.debug("Fetch newer posts for userId=" + userId);
        this.selectedProjectTypeId = projectTypeId;
        return this.postService.getUserPosts(userId, "-1", projectTypeId) // Reload the list
            .map(posts => {
                if (projectTypeId > -1 && posts && posts.length == 0) {
                  let userPosts = this.mapPosts.get(userId);
                  if (userPosts) {
                    userPosts.updateTimelineForNewerPosts([]);
                  }
                }
                if (posts && posts.length > 0) {
                    let userPosts = this.mapPosts.get(userId);
                    if (userPosts) {
                        userPosts.updateTimelineForNewerPosts(posts);
                    }
                }
            });
    }

    public fetchOlderUserPosts(userId: string, projectTypeId: number) {
        this.selectedProjectTypeId = projectTypeId;
        let userPosts = this.mapPosts.get(userId);
        let oldestTimelineId = userPosts.getTimelineForOlderPosts();
        this.logger.debug("Fetch older posts for userId=" + userId);
        return this.postService.getUserPosts(userId, oldestTimelineId, projectTypeId)
            .map(posts => {
                if (posts && posts.length > 0) {
                    let userPosts = this.mapPosts.get(userId);
                    if (userPosts) {
                        userPosts.updateTimelineForOlderPosts(posts);
                    }
                }
            });
    }

}

class UserPosts {
    public posts: Array<Post>;
    private oldestTimelineId: string;
    private subjectPostsUpdates: Subject<Array<Post>>;
    private communityCommon: CommunityCommon;

    constructor(communityCommon: CommunityCommon) {
        this.communityCommon = communityCommon;
        this.posts = [];
        this.oldestTimelineId = "-1";
        this.subjectPostsUpdates = new Subject();
    }

    asObservable(): Observable<Array<Post>> {
        return this.subjectPostsUpdates.asObservable();
    }

    clear() {
        this.posts = [];
        this.oldestTimelineId = "-1";
        this.subjectPostsUpdates.unsubscribe();
    }

    getTimelineForOlderPosts() {
        this.checkTimelineIds();
        return this.oldestTimelineId;
    }

    updateMissionLocation(communityProfile: CommunityProfile) {
        this.posts
            .map((post: Post) => {
                post.mission = communityProfile.mission;
            });
        this.notifyPostsUpdated();
    }

    updateTimelineForNewerPosts(posts: Array<Post>) {
        this.posts = posts;
        this.updateTimelineIds();
        this.notifyPostsUpdated();
    }

    updateTimelineForOlderPosts(posts: Array<Post>) {
        this.posts = this.posts.concat(posts);
        this.updateTimelineIds();
        this.notifyPostsUpdated();
    }

    updatePost(post: Post) {
        let index = this.findIndex(post.postIdStr);
        if (index >= 0) {
            this.posts[index] = post;
            this.notifyPostsUpdated();
        }
    }

    deletePost(post: Post) {
        let index = this.findIndex(post.postIdStr);
        if (index >= 0) {
            this.posts.splice(index, 1);
            this.notifyPostsUpdated();
        }
    }

    private notifyPostsUpdated() {
        this.communityCommon.updateTimeSince(this.posts);
        this.subjectPostsUpdates.next([...this.posts]);
    }

    private updateTimelineIds() {
        if (this.posts && this.posts.length > 0) {
            this.oldestTimelineId = this.posts[this.posts.length - 1].timelineIdStr;
        }
    }

    private checkTimelineIds() {
        if (!this.posts || this.posts.length == 0) {
            this.oldestTimelineId = "-1";
        }
    }

    private findIndex(postIdStr: string): number {
        return this.posts.findIndex(element => {
            return element.postIdStr == postIdStr;
        });
    }

}
