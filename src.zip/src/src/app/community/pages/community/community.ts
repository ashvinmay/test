import {Component, ElementRef, ViewChild} from '@angular/core';
import {Subscription} from "rxjs/Rx";
import {Content, IonicPage, NavController, NavParams} from 'ionic-angular';
import {Post} from "../../models/post";
import {UserService} from "../../../login/services/user.service";
import {UserDetails} from "../../../login/user.details";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {Logger} from "../../../core/logger/logger";
import {ProjectType} from "../../models/project-type.model";
import {CommunityService} from "../../services/community.service";
import {AlertUtils} from "../../../core/alert-utils";
import {PostService} from "../../services/post.service";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-community',
    templateUrl: 'community.html'
})
export class CommunityPage {

    private logger: Logger;

    @ViewChild(Content) content: Content;
    @ViewChild('popoverContent', {read: ElementRef}) popoverContent: ElementRef;
    @ViewChild('popoverText', {read: ElementRef}) text: ElementRef;

    userDetails: UserDetails;
    posts: Array<Post> = [];
    infinite: boolean = true;
    progress: number;
    showProgressBar: boolean = false;
    showLoadingSpinner: boolean = false;
    private subscriptions: Array<Subscription> = [];
    public projectTypes: Array<ProjectType>;
    public selectedProjectTypeId: number = -1;

    constructor(public navCtrl: NavController, public navParams: NavParams,
                private communityService: CommunityService,
                private userService: UserService,
                loggerFactory: LoggerFactory,
                private statusBar: StatusBar,
                private alertUtils: AlertUtils,
                private postService: PostService) {
        this.logger = loggerFactory.getLogger("CommunityPage");
    }

    ionViewDidLoad() {
        this.logger.debug("IonViewDidLoad...");
        // Get user info
        this.subscriptions.push(this.userService.getUserDetailsUpdates()
            .subscribe((userDetails) => {
                this.logger.debug("User details subscriptions...", userDetails.avatarId)
                this.userDetails = userDetails;
            }));

        this.subscribeToPostsUpdates();
        this.subscriptions.push(this.postService.subscribeToUploadProgress().subscribe(
            (progress) => {
                this.progress = progress;
            }));
        this.subscriptions.push(this.postService.subscribeToShowUploadProgress().subscribe(
            (showProgress) => {
                this.showProgressBar = showProgress;
                if (!showProgress) {
                    this.progress = 0;
                }
            }));
        this.subscriptions.push(this.postService.getProjectTypes().subscribe(projectTypes => {
            this.projectTypes = projectTypes;
        }));
    }


    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#14ADE5');
        this.statusBar.styleLightContent();

        this.logger.debug("Selected project type id for filter is ", this.selectedProjectTypeId)
        /* if (this.selectedProjectTypeId != -1) {
           this.selectedProjectTypeId = -1;
           this.fetchNewerPosts();
         }*/
    }

    ionViewWillUnload() {
        // Prevent memory leak when component destroyed
        this.logger.debug("IonViewWillUnload...");
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
        this.communityService.clear();
    }

    private subscribeToPostsUpdates() {
        this.showLoading();
        this.subscriptions.push(this.communityService.subscribeToPostsUpdates().subscribe(
            (posts) => {
                this.posts = posts;
            }
        ));
        // Load initial posts
        this.fetchNewerPosts();
    }

    public fetchNewerPosts(refresher?) {
        this.logger.debug('Refreshing...');
        this.communityService.fetchTopPosts(this.selectedProjectTypeId)
            .finally(() => {
                this.hideLoading();
                if (refresher) refresher.complete();
            })
            .subscribe(
                (data) => {
                    this.infinite = true;
                },
                (err) => {
                    this.handleGetPostsError(err);
                });
    }

    public fetchOlderPosts(loader) {
        this.logger.debug('Loading more...');
        this.communityService.fetchOlderTopPosts(this.selectedProjectTypeId)
            .finally(() => {
                this.hideLoading();
                if (loader) loader.complete();
            })
            .subscribe(
                (data) => {
                    if (!data) this.infinite = false;
                },
                (err) => {
                    this.handleGetPostsError(err);
                });
    }

    private handleGetPostsError(error: any) {
        this.alertUtils.handleGetPostsError(error);
    }

    private showLoading() {
        this.showLoadingSpinner = true;
    }

    private hideLoading() {
        this.showLoadingSpinner = false;
    }

    filterByProjectType(): void {
        this.logger.debug("Selected project type id for filter is ", this.selectedProjectTypeId)
        this.showLoading();
        this.fetchNewerPosts();
    }

}