import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {CommunityPage} from "./community";
import {CommunityToolBarModule} from "../../components/community-tool-bar/community-tool-bar.module";
import {PostListPageModule} from "../../components/post-list/post-list.module";
import {ProgressBarComponentModule} from "../../components/progress-bar/progress-bar.module";

@NgModule({
    declarations : [
        CommunityPage
    ],
    imports : [
        IonicPageModule.forChild(CommunityPage),
        TranslateModule.forChild(),
        CommunityToolBarModule,
        PostListPageModule,
        ProgressBarComponentModule
    ]
})
export class CommunityPageModule {}