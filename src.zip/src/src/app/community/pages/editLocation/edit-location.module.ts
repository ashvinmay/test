import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {EditLocationPage} from "./edit-location";
import {PipesModule} from "../../../core/pipes/pipes.module";

@NgModule({
    declarations : [
        EditLocationPage
    ],
    imports : [
        IonicPageModule.forChild(EditLocationPage),
        TranslateModule.forChild(),
        PipesModule

    ]
})
export class EditLocationPageModule {}
