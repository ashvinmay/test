import {Component} from "@angular/core";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {IonicPage, NavController, NavParams} from "ionic-angular";
import {Logger} from "../../../core/logger/logger";
import {CommunityProfile} from "../community-profile/community-profile.model";
import {CommunityProfileService} from "../community-profile/community-profile.service";
import {AlertUtils} from "../../../core/alert-utils";
import {CONUTRIES_WITH_CODE} from "../../../core/models/countries-code";
import {LoadingUiService} from "../../services/loading-ui-service";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-edit-location',
    templateUrl: 'edit-location.html'
})
export class EditLocationPage {
    private logger: Logger;
    city: string;
    countryCode: string;
    countries: Array<{ code: string, country:string, countrywithcode:string }>;
    countrySelectOption: any;
    communityProfile: CommunityProfile;

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                private loadingHelper: LoadingUiService,
                loggerFactory: LoggerFactory,
                private statusBar: StatusBar,
                private communityProfileService: CommunityProfileService,
                private alertUtils: AlertUtils) {

        this.logger = loggerFactory.getLogger("EditLocationPage");
        this.communityProfile = this.navParams.data.communityProfile;
        this.city = this.communityProfile.mission.city;
        this.countryCode = this.communityProfile.mission.countryCode;
        this.countries = CONUTRIES_WITH_CODE; // COUNTRIES; //
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#0D7397');
        this.statusBar.styleLightContent();
    }

    saveLocation() {
        this.logger.debug("Save profile for userId={}", this.communityProfile.userIdStr);
        this.loadingHelper.showLoading();

        let observable = this.communityProfileService.saveCommunityProfile(this.city, this.countryCode);
        if (observable) {
            observable.subscribe(
                (data) => {
                    this.loadingHelper.hideLoading();
                    this.navCtrl.pop();
                },
                (err) => {
                    this.loadingHelper.hideLoading();
                    return this.alertUtils.handleGetPostsError(err);
                });
        }
    }

}
