import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {ViewPostPage} from "./view-post";
import {ComponentsModule} from "../../shared/components.module";
import {ElasticModule} from "angular2-elastic";

@NgModule({
    declarations : [
        ViewPostPage
    ],
    imports : [
        ElasticModule,
        ComponentsModule,
        IonicPageModule.forChild(ViewPostPage),
        TranslateModule.forChild()
    ]
})
export class ViewPostPageModule {}