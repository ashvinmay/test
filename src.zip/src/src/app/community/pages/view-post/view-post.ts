import {Component, ViewChild, ChangeDetectorRef} from '@angular/core';
import {
    ActionSheetController, Content, IonicPage, NavController, NavParams,
    Refresher
} from 'ionic-angular';
import {AnalyticService} from "../../../core/analytics/analytic.service";
import {Post} from "../../models/post";
import {UserDetails} from "../../../login/user.details";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {CommunityCommon} from "../../shared/community-common";
import {Subscription} from "rxjs/Subscription";
import {PostService} from "../../services/post.service";
import {TranslateService} from "@ngx-translate/core";
import {AlertUtils} from "../../../core/alert-utils";
import {ViewPostService} from "../../services/viewpost.service";
import {Comment} from "../../models/comment";
import {EscError} from "../../../core/models/esc-error";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-view-post',
    templateUrl: 'view-post.html'
})
export class ViewPostPage {

    // AutoFocus + show Keyboard
    // http://stackoverflow.com/questions/39612653/set-focus-on-an-input-with-ionic-2
    @ViewChild('focusInput') inputComment;
    @ViewChild(Content) content: Content;
    @ViewChild(Refresher) refresher: Refresher;

    private logger: Logger;
    private post: Post;
    private newTextComment: string = "";
    private userDetails: UserDetails;
    sending: boolean;
    pageTitle: string;
    private subscriptions: Array<Subscription> = [];

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                private translateService: TranslateService,
                loggerFactory: LoggerFactory,
                private actionSheetCtrl: ActionSheetController,
                private postService: PostService,
                private statusBar: StatusBar,
                private viewPostService: ViewPostService,
                private communityCommon: CommunityCommon,
                private alertUtils: AlertUtils,
                private cdRef: ChangeDetectorRef, private analyticService : AnalyticService) {

        this.logger = loggerFactory.getLogger("ViewPostPage");
        this.post = navParams.get('post');
        this.userDetails = navParams.get('userDetails');
        let lastComment = this.navParams.get('lastComment');
        if (lastComment) {
            this.scrollToBottom();
        }
        let showKb = this.navParams.get('showKeyboard');
        if (showKb) {
            this.showKeyboard();
        }
    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad ViewPostPage');

        this.subscriptions.push(this.postService.subscribeToDeletePost().subscribe(
            () => {
                this.navCtrl.pop();
            }));
        this.subscriptions.push(this.viewPostService.subscribeToPostUpdates().subscribe(
            (post: Post) => {
                this.logger.debug("Got Post update!");
                this.post = post;
            }));

        this.pageTitle = this.translateService.instant("VIEW_POST");

        // Refresh the post in "background"
        this.refreshPost();
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#14ADE5');
        this.statusBar.styleLightContent();
    }

    ionViewWillUnload() {
        // Prevent memory leak when component destroyed
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
    }

    /* =============
     * HANDLING POST
     * ============= */

    // showSlider(post): boolean {
    //     return this.communityCommon.showSlider(post);
    // }
    //
    // showOneImage(post): boolean {
    //     return this.communityCommon.showOneImage(post);
    // }

    showBottomSheet(post: Post) {
        let buttons = this.communityCommon.createPostButtons(post, this);
        const bottomSheet = this.actionSheetCtrl.create({buttons});
        bottomSheet.present();
    }

    getImageUrl(imageId): string {
        return this.communityCommon.getImageUrl(imageId);
    }

    goToCommProfile(userId: string) {
        this.navCtrl.push('CommunityProfilePage', {
            userId: userId
        }).then(data => {
          let pageDetails = {
            "userId" : userId
          };
          this.analyticService.trackPageView('CommunityProfilePage', pageDetails);
        });
    }

    getAvatarUrl(userId): string {
        return this.communityCommon.getAvatarUrl(userId);
    }

    showSelected(current: string, images: string[]) {
        return this.communityCommon.showSelected(current, images);
    }

    likeOrDislike(post) {
        if (!this.isUserBlocked()) {
            this.communityCommon.likeOrDislike(post);
        }
    }

    editPost() {
        this.navCtrl.push("EditPostPage", {
            post: this.post
        }).then(data => {
          let pageDetails = {
            "postId" : this.post.postIdStr
          };
          this.analyticService.trackPageView('EditPostPage', pageDetails);
        });
    }

    showRestrictedPostMessage() {
        this.communityCommon.presentPostRestricted();
    }

    private isUserBlocked() {
        return this.userDetails.visibility == 'RESTRICTED';
    }

    /* ========
     * COMMENTS
     * ======== */

    /**
     * Discards all existing comments replacing them from latest list.
     */
    refreshPost(refresher?: Refresher) {
        this.logger.debug("Refreshing post...");
        this.viewPostService.getPost(this.post.postIdStr, this.post)
            .finally(() => {
                if (refresher) refresher.complete();
            })
            .subscribe(
                (post: Post) => {
                    //console.log("new post: ", post != this.post);
                    if (post && post != this.post) {
                        this.logger.debug("Post refreshed");
                        this.post = post;
                        this.cdRef.detectChanges();
                    }
                    this.logger.debug("Enabling infinite scroll");
                },
                (error: EscError) => {
                    if (error.status != 304) { // Not modified!
                        this.alertUtils.handleGetPostsError(error);
                    }
                }
            );
    }

    /**
     * Inserts at the top older comments to the existing ones.
     */
    fetchOlderComments() {
        this.logger.debug("Getting older comments...");
        this.viewPostService.getOlderComments(this.post)
            .finally(() => {

            })
            .subscribe(
                (comments: Array<Comment>) => {
                },
                (error) => {
                    this.alertUtils.handleGetPostsError(error);
                }
            );
    }

    changedText(value: string) {
        this.cdRef.detectChanges();
        this.newTextComment = value.length > 400 ? value.substring(0, 400) : value;
    }

    addComment() {
        this.newTextComment = this.newTextComment.trim();
        if (this.newTextComment && this.newTextComment.length > 0 && this.newTextComment.length <= 400) {
            this.logger.debug("Sending comment...");
            this.sending = true;
            this.viewPostService.addComment(this.post, this.newTextComment)
                .finally(() => {
                    this.sending = false;
                })
                .subscribe(
                    (comment: Comment) => {
                        this.newTextComment = "";
                        this.scrollToBottom();
                        this.logger.debug("Comment sent");
                    },
                    (error) => {
                        this.alertUtils.handleGetPostsError(error);
                    });
        }
    }

    likeOrDislikeComment(comment: Comment) {
        if (!this.isUserBlocked()) {
            this.communityCommon.likeOrDislikeComment(this.post, comment);
        }
    }

    showWhoLikedPost(post: Post) {
        if (!this.isUserBlocked()) {
            this.navCtrl.push('PeopleLikesPage', {
                postId: post.postIdStr
            });
        }
    }

    showWhoLikedComment(comment: Comment) {
        if (!this.isUserBlocked()) {
            this.navCtrl.push('PeopleLikesPage', {
                postId: this.post.postIdStr,
                commentId: comment.commentIdStr
            });
        }
    }

    deleteComment(comment: Comment) {
        this.communityCommon.deleteComment(this.post, comment);
    }

    reportComment(comment: Comment) {
        if (!this.isUserBlocked()) {
            let buttons = this.communityCommon.createCommentButtons(this.post, comment);
            const bottomSheet = this.actionSheetCtrl.create({buttons});
            bottomSheet.present();
        }
    }

    private scrollToBottom() {
        setTimeout(() => {
            this.content.scrollToBottom(400);
        }, 500);
    }

    showKeyboard(delay?: number) {
        if (!this.isUserBlocked()) {
            if (!delay) delay = 1000;
            setTimeout(() => {
                this.inputComment.setFocus();
            }, delay);
        }
    }
}
