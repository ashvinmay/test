import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {AddPostPage} from "./add-post";
import {AddPostToolBarModule} from "../../components/add-post-tool-bar/add-post-tool-bar.module";
import {ElasticModule} from "angular2-elastic";

@NgModule({
    declarations : [
        AddPostPage
    ],
    imports : [
        ElasticModule,
        IonicPageModule.forChild(AddPostPage),
        TranslateModule.forChild(),
        AddPostToolBarModule
    ]
})
export class AddPostPageModule {}