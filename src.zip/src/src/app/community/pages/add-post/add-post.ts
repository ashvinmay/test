import {ChangeDetectorRef, Component} from '@angular/core';
import {IonicPage, Loading, ModalController, NavController, NavParams} from 'ionic-angular';
import {Subscription} from "rxjs/Subscription";
import {UserService} from "../../../login/services/user.service";
import {AlertUtils} from "../../../core/alert-utils";
import {GalleryModal} from "../../shared/gallery-modal/gallery-modal";
import {Post} from "../../models/post";
import {ProjectType} from "../../models/project-type.model";
import {PostService} from "../../services/post.service";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-add-post',
    templateUrl: 'add-post.html'
})
export class AddPostPage {
    title: string = "";
    description: string = "";
    projectType: ProjectType;
    selectedPicture: string;
    selectedPicturesURI: Array<string> = [];
    userIdStr: string;
    uploading: boolean = false;

    private userDetailsSubscription: Subscription;
    private loading: Loading;
    public projectTypes: Array<ProjectType>;

    constructor(private navCtrl: NavController,
                private navParams: NavParams,
                private modalCtrl: ModalController,
                private userService: UserService,
                private postService: PostService,
                private alertUtils: AlertUtils,
                private statusBar: StatusBar,
                private cdRef: ChangeDetectorRef) {
        this.selectedPicturesURI = this.navParams.data.selectedPicturesURI;
    }

    ionViewDidLoad() {
        // Get user info
        this.userDetailsSubscription = this.userService.getUserDetails()
            .subscribe((userDetails) => {
                this.userIdStr = userDetails.userIdStr;
            });

        this.postService.getProjectTypes().subscribe(projectTypes => {
            this.projectTypes = projectTypes;
            this.projectType = projectTypes[0];
        });
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#14ADE5');
        this.statusBar.styleLightContent();
    }

    ionViewWillUnload() {
        this.userDetailsSubscription.unsubscribe();
    }

    showSelected(pic) {
        let photos: any[] = [];
        let index: number;
        for (let i = 0; i < this.selectedPicturesURI.length; i++) {
            if (pic === this.selectedPicturesURI[i]) {
                index = i;
            }
            photos.push({
                url: this.selectedPicturesURI[i],
            });
        }
        let modal = this.modalCtrl.create(GalleryModal, {
            photos: photos,
            initialSlide: index
        });
        modal.present();
    }

    public addPost() {
        /*this.loading = this.loadingCtrl.create({
            content: '<b>' + this.translate.instant('PLEASE_WAIT') + '</b>'
        });
        // Show loading
        this.loading.present().then(() => {
            this.uploading = true;
            // Prepare the post object
            let post = new Post();
            post.userIdStr = this.userIdStr;
            post.title = this.title;
            post.description = this.description;

            // Add Post and pictures
            this.postService.addPost(post, this.selectedPicturesURI)
                .subscribe(() => {

                }, (error) => {
                    this.handleGetPostsError(error);
                });
            this.navCtrl.pop();
        });*/

        let post = new Post();
        post.userIdStr = this.userIdStr;
        post.title = this.title;
        post.description = this.description;
        post.projectType = this.projectType;

        // Add Post and pictures
        this.postService.addPost(post, this.selectedPicturesURI)
            .subscribe(() => {

            }, (error) => {
                this.handleGetPostsError(error);
            });
        this.navCtrl.pop();
    }

    private handleGetPostsError(error: any) {
        this.hideLoading();
        return this.alertUtils.handleGetPostsError(error);
    }

    private hideLoading() {
        if (this.loading) {
            this.loading.dismiss();
            this.loading = null;
        }
    }

    changeTitle(value: string) {
        this.cdRef.detectChanges();
        this.title = value.length > 140 ? value.substring(0, 140) : value;
    }

    changedDescription(value: string) {
        this.cdRef.detectChanges();
        this.description = value.length > 400 ? value.substring(0, 400) : value;
    }

    comparePT(pt1: ProjectType, pt2: ProjectType): boolean {
        return pt1 && pt2 ? pt1.id === pt2.id : pt1 === pt2;
    }

}