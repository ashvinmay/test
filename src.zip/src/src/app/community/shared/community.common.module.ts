import {NgModule} from "@angular/core";
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {TranslateModule} from '@ngx-translate/core';
import {IonicModule} from "ionic-angular";
import {PostService} from "../services/post.service";
import {CommunityCommon} from "./community-common";
import {CommunityProfileService} from "../pages/community-profile/community-profile.service";
import {CommunityService} from "../services/community.service";
import {CommunityProfilePostsService} from "../pages/community-profile/community-profile-posts.service";
import {ViewPostService} from "../services/viewpost.service";
import {JournalBgImgUiService} from "../services/journal-bg-img-ui-service";
import {LoadingUiService} from "../services/loading-ui-service";
import {AvatarUiService} from "../services/avatar-ui-service";

@NgModule({
    declarations: [
    ],
    imports: [
        CommonModule, FormsModule,
        TranslateModule.forChild(),
        IonicModule],
    exports: [
    ],
    providers: [CommunityService, PostService, ViewPostService, CommunityCommon, CommunityProfileService, CommunityProfilePostsService, LoadingUiService, JournalBgImgUiService, AvatarUiService]
})
export class CommunityCommonModule {
}
