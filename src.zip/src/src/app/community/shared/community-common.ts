import {
    ModalController, AlertController, NavController, ActionSheetController, Refresher
} from "ionic-angular";
import {Injectable} from '@angular/core';
import {AnalyticService} from "../../core/analytics/analytic.service";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {PostService} from "../services/post.service";
import {DatePipe} from "@angular/common";
import {TranslateService} from "@ngx-translate/core";
import {Post} from "../models/post";
import {GalleryModal} from "./gallery-modal/gallery-modal";
import {PhotoService} from "../services/photo.service";
import {AlertUtils} from "../../core/alert-utils";
import {PlatformService} from "../../core/platform.service";
import {Comment} from "../models/comment";
import {SocialSharing} from "@ionic-native/social-sharing";

@Injectable()
export class CommunityCommon {

    private logger: Logger;

    selectedPicturesURI: Array<string> = [];

    constructor(loggerFactory: LoggerFactory,
                private modalCtrl: ModalController,
                private translate: TranslateService,
                private alertCtrl: AlertController,
                private actionSheetCtrl: ActionSheetController,
                private translateService: TranslateService,
                private postService: PostService,
                private alertUtils: AlertUtils,
                private photoService: PhotoService,
                private platformService: PlatformService,
                private socialSharing: SocialSharing,
                private analyticService : AnalyticService
                ) {

        this.logger = loggerFactory.getLogger("CommunityCommon");
    }

    // public showSlider(post: Post): boolean {
    //     return post.imagesStr && post.imagesStr.length > 1;
    // }
    //
    // public showOneImage(post: Post): boolean {
    //     return post.imagesStr && post.imagesStr.length == 1;
    // }

    public getImageUrl(imageId): string {
        return this.postService.getImageUrl(imageId);
    }

    public getAvatarUrl(userId): string {
        return this.postService.getAvatarUrl(userId);
    }

    public showSelected(current: string, images: string[]) {
        let photos: any[] = [];
        let index: number;
        for (let i = 0; i < images.length; i++) {
            if (current === images[i]) {
                index = i;
            }
            photos.push({
                url: this.getImageUrl(images[i]),
            });
        }
        let modal = this.modalCtrl.create(GalleryModal, {
            photos: photos,
            initialSlide: index
        });
        modal.present();
    }

    public startRefresher(refresher: Refresher) {
        refresher._top = this.platformService.isIOS() ? '44px' : '55px';
        refresher.state = 'refreshing';
        refresher._beginRefresh();
    }

    public updateTimeSince(posts: Array<Post>) {
        if (posts && posts.length > 0) {
            let now: Date = new Date();
            let datePipe = new DatePipe(this.translateService.currentLang);
            posts.forEach((element: Post) => {
                element.updateTimeSince(now, datePipe, this.translateService);
            });
        }
    }

    public likeOrDislike(post: Post) {
        if (post.liked) {
            this.postService.removeLike(post).subscribe(
                (likeCount: any) => {
                },
                (error) => {
                    this.alertUtils.handleGetPostsError(error);
                });
        } else {
            this.postService.addLike(post).subscribe(
                (likeCount: any) => {
                },
                (error) => {
                    this.alertUtils.handleGetPostsError(error);
                });
        }
    }

    public likeOrDislikeComment(post: Post, comment: Comment) {
        if (comment.liked) {
            this.postService.removeCommentLike(post, comment).subscribe(
                (likeCount: any) => {
                },
                (error) => {
                    this.alertUtils.handleGetPostsError(error);
                });
        } else {
            this.postService.addCommentLike(post, comment).subscribe(
                (likeCount: any) => {
                },
                (error) => {
                    this.alertUtils.handleGetPostsError(error);
                });
        }
    }

    public deleteComment(post: Post, comment: Comment) {
        this.postService.deleteComment(post, comment).subscribe(
            () => {
            },
            (error) => {
                this.alertUtils.handleGetPostsError(error);
            });
    }

    private reportComment(post: Post, comment: Comment) {
        this.postService.reportComment(post, comment).subscribe(
            () => {
                this.presentCommentReportPerformed();
            },
            (error) => {
                this.alertUtils.handleGetPostsError(error);
            });
    }

    public createPostButtons(post: Post, callback: any): Array<any> {
        let buttons: Array<any> = [];
        if (callback.userDetails.userIdStr == post.userIdStr) {
            buttons.push({
                text: this.translateService.instant('EDIT'),
                icon: 'ios-create-outline',
                handler: () => {
                    callback.editPost(post);
                }
            });
            buttons.push({
                text: this.translateService.instant('DELETE'),
                icon: 'ios-trash-outline',
                handler: () => {
                    this.presentConfirmDelete(post);
                }
            });
        } else {
            buttons.push({
                text: this.translateService.instant('REPORT'),
                icon: 'ios-alert-outline',
                handler: () => {
                    this.postService.reportPost(post).subscribe(
                        (data) => {
                            this.logger.debug(`Post ${post.postIdStr} successfully reported`);
                            this.presentPostReportPerformed();
                        },
                        (err) => {
                            this.alertUtils.handleGetPostsError(err);
                        }
                    );
                }
            });
        }
        buttons.push({
            text: this.translateService.instant('GLOBAL_CANCEL'),
            icon: 'md-close',
            role: 'cancel',
            handler: () => {
            }
        });
        return buttons;
    }

    private presentConfirmDelete(post: Post) {
        let alert = this.alertCtrl.create({
            title: this.translateService.instant('CONFIRM_DELETE'),
            message: this.translateService.instant('DELETE_QUESTION'),
            buttons: [
                {
                    text: this.translateService.instant('GLOBAL_CANCEL'),
                    role: 'cancel',
                    handler: () => {
                    }
                },
                {
                    text: this.translateService.instant('GLOBAL_OK'),
                    handler: () => {
                        this.postService.deletePost(post).subscribe(
                            (data) => {
                                this.logger.debug("Post deleted");
                            },
                            (err) => {
                                this.alertUtils.handleGetPostsError(err);
                            }
                        );
                    }
                }
            ]
        });
        alert.present();
    }

    public createCommentButtons(post: Post, comment: Comment): Array<any> {
        let buttons: Array<any> = [];
        buttons.push({
            text: this.translateService.instant('REPORT_COMMENT'),
            icon: 'ios-alert-outline',
            handler: () => {
                this.reportComment(post, comment);
            }
        });
        buttons.push({
            text: this.translateService.instant('GLOBAL_CANCEL'),
            icon: 'md-close',
            role: 'cancel',
            handler: () => {
            }
        });
        return buttons;
    }

    public presentUserBlocked() {
        this.translateAndPresentAlert('BLOCKED_USER_MESSAGE');
    }

    public presentJournalBgImageDisapproved() {
        this.translateAndPresentAlert('DISAPPROVED_JOURNAL_BG_IMAGE');
    }

    public presentPostRestricted() {
        this.translateAndPresentAlert('RESTRICTED_POST_MESSAGE');
    }

    private presentPostReportPerformed() {
        this.translateAndPresentToast('REPORT_EXECUTED');
    }

    private presentCommentReportPerformed() {
        this.translateAndPresentToast('REPORT_COMMENT_EXECUTED');
    }

    public presentCameraError() {
        this.translateAndPresentToast('CAMERA_CANCEL');
    }

    public translateAndPresentToast(key: string, params?: any) {
        this.alertUtils.showToastAlert(this.translateService.instant(key, params), 'esc-toast-info');
    }

    public translateAndPresentAlert(key: string) {
        this.alertUtils.showAlert(this.translateService.instant(key));
    }

    /* ADD POST */

    public canAddMorePictures(): boolean {
        // Maximum 3 pictures can be added to a post
        return this.selectedPicturesURI.length < 3;
    }

    showAddPostBottomSheet(navCtrl: NavController) {
        if (!this.platformService.isCordova()) {
            navCtrl.push('AddPostPage', {
                selectedPicturesURI: this.selectedPicturesURI
            }).then(data => {
              this.analyticService.trackPageView('AddPostPage')
            });
        }
        this.selectedPicturesURI = [];

        let bottomSheetAdd = this.actionSheetCtrl.create({
            title: this.translate.instant('ADD_POST'),
            buttons: [
                {
                    text: this.translate.instant('OPEN_GALLERY'),
                    icon: 'ios-images-outline',
                    handler: () => {
                        let navTransition = bottomSheetAdd.dismiss();
                        this.photoService.checkGalleryPermission().then(result => {
                            if (result && this.canAddMorePictures()) {
                                navTransition.then(() => {
                                    this.accessGallery(navCtrl);
                                });
                            }
                        });
                        // MUST return false to inform the action sheet that our code is handling the dismiss
                        return false;
                    }
                },
                {
                    text: this.translate.instant('TAKE_PHOTO'),
                    icon: 'ios-camera-outline',
                    handler: () => {
                        let navTransition = bottomSheetAdd.dismiss();
                        this.photoService.checkCameraPermission().then(result => {
                            if (result && this.canAddMorePictures()) {
                                navTransition.then(() => {
                                    this.openCamera(navCtrl);
                                });
                            }
                        });
                        // MUST return false to inform the action sheet that our code is handling the dismiss
                        return false;
                    }
                },
                {
                    text: this.translate.instant('GLOBAL_CANCEL'),
                    icon: 'md-close',
                    role: 'cancel',
                    handler: () => {
                        return true;
                    }
                }
            ]
        });
        bottomSheetAdd.present();
    }

    accessGallery(navCtrl: NavController) {
        this.photoService.openGallery().then(results => {
                for (let i = 0; i < results.length; i++) {
                    this.logger.debug('Image URI: ' + results[i]);
                    if (this.selectedPicturesURI.length < 3) {
                        this.selectedPicturesURI.push(results[i]);
                    }
                }
                if (this.selectedPicturesURI.length > 0) {
                    navCtrl.push('AddPostPage', {
                        selectedPicturesURI: this.selectedPicturesURI
                    }).then(data => {
                      this.analyticService.trackPageView('AddPostPage')
                    });
                }
            }, error => {
                this.logger.error('Error accessing gallery' + error);
            }
        );
    }

    openCamera(navCtrl: NavController) {
        this.photoService.openCamera().then((imageData) => {
            this.selectedPicturesURI.push(imageData);
            if (this.selectedPicturesURI.length > 0) {
                navCtrl.push('AddPostPage', {
                    selectedPicturesURI: this.selectedPicturesURI
                }).then(data => {
                  this.analyticService.trackPageView('AddPostPage')
                });
            }
        }, (err) => {
            this.logger.error("Error accessing camera: " + err);
            this.presentCameraError();
        });
    }

    sharePost(post: Post) {
        let bottomSheetShare = this.actionSheetCtrl.create({
            title: this.translate.instant('SHARE_POST_TITLE'),
            buttons: [
                {
                    text: this.translate.instant('SHARE_POST_VIA_FACEBOOK'),
                    icon: 'logo-facebook',
                    handler: () => {
                      this.shareViaFacebook(post);
                        // MUST return false to inform the action sheet that our code is handling the dismiss
                        return true;
                    }
                },
                {
                    text: this.translate.instant('SHARE_POST_VIA_INSTAGRAM'),
                    icon: 'logo-instagram',
                    handler: () => {
                      this.shareViaInstagram(post);
                        // MUST return false to inform the action sheet that our code is handling the dismiss
                        return true;
                    }
                },
                {
                  text: this.translate.instant('SHARE_POST_VIA_TWITTER'),
                  icon: 'logo-twitter',
                  handler: () => {
                    this.shareViaTwitter(post);
                    // MUST return false to inform the action sheet that our code is handling the dismiss
                    return true;
                  }
                },
                {
                    text: this.translate.instant('GLOBAL_CANCEL'),
                    icon: 'md-close',
                    role: 'cancel',
                    handler: () => {
                        return true;
                    }
                }
            ]
        });
        bottomSheetShare.present();
    }

    private shareViaFacebook(post: Post):void{
        this.postService.getSharePost(post.postIdStr, 1).subscribe((sharePost) => {
                let publicShareUrl = this.postService.getPublicShareUrl(sharePost);
                let shareViaApp: string = this.getShareViaAppName('facebook');
                let startTime = new Date().getTime();
                this.socialSharing.canShareVia(shareViaApp, null, null, publicShareUrl).then(()=>{
                    this.socialSharing.shareViaFacebook(null, null, publicShareUrl)
                        .then((data) => {
                            this.logger.debug('Post shared');
                        }).catch((error) => {
                        //Fix for iOS
                        let isTimeLessThanASec : boolean = ((new Date().getTime() - startTime)/1000) < 1;
                        if(this.platformService.isIOS() && isTimeLessThanASec) {
                            this.alertUtils.showAlert(this.translate.instant('FACEBOOK_NOT_INSTALLED_MSG'));
                        }
                    });
                }).catch((error) => {
                    this.alertUtils.showAlert(this.translate.instant('FACEBOOK_NOT_INSTALLED_MSG'));
                });
            },
            (error) => {
                this.alertUtils.handleGetPostsError(error);
            });
    }

    private shareViaInstagram(post:Post): void {
        this.postService.getSharePost(post.postIdStr, 2).subscribe((sharePost) => {
                let imageUrl=this.getImageUrl(post.images[0]);
                let startTime = new Date().getTime();
                  this.socialSharing.canShareVia("instagram", null, null, imageUrl).then(()=>{
                    this.socialSharing.shareViaInstagram(null, imageUrl)
                      .then((data) => {
                        this.logger.debug('Post shared');
                      }).catch((error) => {
                      //Fix for iOS
                      let isTimeLessThanASec : boolean = ((new Date().getTime() - startTime)/1000) < 1;
                      if(this.platformService.isIOS() && isTimeLessThanASec) {
                        this.alertUtils.showAlert(this.translate.instant('INSTAGRAM_NOT_INSTALLED_MSG'));
                      }
                    });
                  }).catch((error) => {
                    this.alertUtils.showAlert(this.translate.instant('INSTAGRAM_NOT_INSTALLED_MSG'));
                  });
            },
            (error) => {
                this.alertUtils.handleGetPostsError(error);
            });

    }

  private shareViaTwitter(post:Post): void {
    this.postService.getSharePost(post.postIdStr, 3).subscribe((sharePost) => {
        let publicShareUrl = this.postService.getPublicShareUrl(sharePost);
        let shareViaApp: string = this.getShareViaAppName('twitter');
        let startTime = new Date().getTime();
        if (this.platformService.isIOS()) {
          this.socialSharing.shareViaTwitter(null, null, publicShareUrl)
            .then((data) => {
              this.logger.debug('Post shared');
            }).catch((error) => {
            //Fix for iOS
            let isTimeLessThanASec : boolean = ((new Date().getTime() - startTime)/1000) < 1;
            if(isTimeLessThanASec) {
              this.alertUtils.showAlert(this.translate.instant('TWITTER_NOT_INSTALLED_MSG'));
            }
          });
        } else {
          this.socialSharing.canShareVia(shareViaApp, null, null, null,publicShareUrl).then(()=>{
            this.socialSharing.shareViaTwitter(null, null, publicShareUrl)
              .then((data) => {
                this.logger.debug('Post shared');
              }).catch((error) => {
                //do nothing
            });
          }).catch((error) => {
            this.alertUtils.showAlert(this.translate.instant('TWITTER_NOT_INSTALLED_MSG'));
          });
        }
      },
      (error) => {
        this.alertUtils.handleGetPostsError(error);
      });

  }

  private getShareViaAppName(app: string): string {
        if(this.platformService.isAndroid()) {
           if ('facebook' == app) {
             return 'com.facebook.katana';
           }
           if ('twitter' === app) {
             return 'twitter'
           }
        }
        if(this.platformService.isIOS()) {
            return 'com.apple.social.'+app;
        }
    }

}
