import {NgModule} from "@angular/core";
import {IonicModule} from "ionic-angular";
import {LazyLoadDirective} from "./img-cache/lazy-load.directive";
import {PostComponent} from "../components/post/post";
import {CommentComponent} from "../components/comment/comment";
import {TranslateModule} from "@ngx-translate/core";
import {PipesModule} from "../../core/pipes/pipes.module";

@NgModule({
    declarations: [
        LazyLoadDirective,
        PostComponent,
        CommentComponent
    ],
    imports: [
        IonicModule,
        TranslateModule.forChild(),
        PipesModule
    ],
    exports: [
        LazyLoadDirective,
        PostComponent,
        CommentComponent
    ],
    providers: []
})
export class ComponentsModule {
}
