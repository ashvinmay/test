// Photo interface
export interface Photo {
    url: string;
}
