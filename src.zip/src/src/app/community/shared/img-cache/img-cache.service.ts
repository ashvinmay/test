import {Injectable} from '@angular/core';
import {Platform} from 'ionic-angular';
import ImgCache from '@chrisben/imgcache.js';
import {File} from '@ionic-native/file';

/**
 * This service is charged of provide the methods to cache the images
 *
 * https://medium.com/ninjadevs/caching-images-ionic-ccf2f4ca8d1f
 * https://github.com/chrisben/imgcache.js/blob/master/CORDOVA.md
 */
@Injectable()
export class ImgCacheService {
    private prefsSet: boolean = false;

    constructor(private platform: Platform, private file: File) {
    }

    /**
     * Init imgCache library
     * @return {Promise}
     */
    public initImgCache(): Promise<any> {
        return new Promise((resolve, reject) => {
            if (!this.prefsSet) {
                this.setPrefs();
                this.prefsSet = true;
            }
            if (ImgCache.ready) {
                resolve();
            } else {
                ImgCache.init(() => resolve(), (err) => reject(err));
            }
        });
    }

    /**
     * Cache images
     * @param src {string} - img source
     */
    public cacheImg(src: string): Promise<any> {
        return new Promise((resolve, reject) => {
            ImgCache.isCached(src, (path: string, success: boolean) => {
                // If not, it will be cached
                if (success) {
                    ImgCache.getCachedFileURL(src,
                        (originalUrl, cacheUrl) => {
                            console.log("Get URL from cache " + cacheUrl);
                            resolve(this.normalizeUrlWKWview(cacheUrl));

                        },
                        (e) => {
                            reject(e)
                        });
                } else {
                    console.log("Set URL in cache");
                    // Cache img
                    ImgCache.cacheFile(src);
                    // Return original img URL
                    resolve(src);
                }
            });
        });
    }

    /**
     * WKWebview doesn't accept urls with file:// or cvdfile:// protocols.
     * The url is formatted and fix to find the img
     * @param url
     * @return {string} - url formatted
     */
    private normalizeUrlWKWview(url: string) {
        if (this.platform.is('ios')) {
            let urlIos = `${this.normalizeUrlIos(this.file.applicationStorageDirectory)}Library/files/${this.normalizeUrlIos(url)}`;
            urlIos = urlIos.replace('/localhost/persistent', '');
            console.log("Normalized URL " + urlIos);
            return urlIos;
        }
        return url;
    }

    private normalizeUrlIos(url: string): string {
        return (url).replace(/(cdvfile|file):\/\//g, '');
    }

    private setPrefs() {
        ImgCache.options.debug = true;
        ImgCache.options.cacheClearSize = 50; //Clear at 50MB
        if (this.platform.is('android') && this.platform.is('cordova')) {
            let index = this.file.externalRootDirectory.length;
            ImgCache.options.localCacheFolder = this.file.externalCacheDirectory.substr(index);
        }
        // for iOS is "Library/files/" + default (./imgcache)
    }

    logDirectories() {
        // let index = this.file.externalRootDirectory.length;
        // console.log("IMG_CACHE:" + this.file.externalCacheDirectory.substr(index));
        // console.log("externalDataDirectory=" + this.file.externalDataDirectory);
        // console.log("externalCacheDirectory=" + this.file.externalCacheDirectory);
        // console.log("externalRootDirectory=" + this.file.externalRootDirectory);
        // console.log("externalApplicationStorageDirectory=" + this.file.externalApplicationStorageDirectory);
        // console.log("applicationStorageDirectory=" + this.file.applicationStorageDirectory);
        // console.log("applicationDirectory=" + this.file.applicationDirectory);
        // console.log("tempDirectory=" + this.file.tempDirectory);
        // console.log("dataDirectory=" + this.file.dataDirectory);
        // console.log("cacheDirectory=" + this.file.cacheDirectory);
        // console.log("syncedDataDirectory=" + this.file.syncedDataDirectory);
        // console.log("documentsDirectory=" + this.file.documentsDirectory);
        // console.log("sharedDirectory=" + this.file.sharedDirectory);
    }

}
