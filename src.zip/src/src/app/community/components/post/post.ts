import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Post} from "../../models/post";
import {CommunityCommon} from "../../shared/community-common";
import {UserDetails} from "../../../login/user.details";

@Component({
    selector: 'post',
    templateUrl: 'post.html'
})
export class PostComponent {

    @Input() post: Post;
    @Input() userDetails: UserDetails;
    @Input() isPostDetailPage: boolean;

    @Output() openComponent: EventEmitter<{post: Post, showKeyboard: boolean}> = new EventEmitter();
    @Output() openProfile: EventEmitter<{userId: string}> = new EventEmitter();
    @Output() showBottomSheet: EventEmitter<Post> = new EventEmitter();
    @Output() whoLiked: EventEmitter<Post> = new EventEmitter();

    constructor(private communityCommon: CommunityCommon) {
    }

    viewPostDetail(keyboard: boolean) {
        this.openComponent.emit({
            post: this.post,
            showKeyboard: keyboard
        });
    }

    displayBottomSheet() {
        this.showBottomSheet.emit(this.post);
    }

    goToCommProfile(userId: string) {
        this.openProfile.emit({userId: userId});
    }

    getAvatarUrl(userId): string {
        if (userId == this.userDetails.userIdStr) {
            if (this.userDetails.avatarId) {
                return this.communityCommon.getAvatarUrl(this.userDetails.userIdStr) + "?lastmodified=" + this.userDetails.avatarId;
            }
        }
        return this.communityCommon.getAvatarUrl(userId);
    }

    getImageUrl(image): string {
        return this.communityCommon.getImageUrl(image);
    }

    showSelectedImage(current: string, images: string[]) {
        this.communityCommon.showSelected(current, images);
    }

    likeOrDislike() {
        if (!this.isUserBlocked()) {
            this.communityCommon.likeOrDislike(this.post);
        }
    }

    isUserBlocked() {
        return this.userDetails.visibility == 'RESTRICTED';
    }

    showRestrictedPostMessage() {
        this.communityCommon.presentPostRestricted();
    }

    isShareAllowed() {
        return this.post.userIdStr == this.userDetails.userIdStr && !this.isUserBlocked();
    }

    sharePost() {
        this.communityCommon.sharePost(this.post);
    }

    showWhoLiked() {
        if (this.post.likeCount > 0) {
            this.whoLiked.emit(this.post);
        }
    }

}