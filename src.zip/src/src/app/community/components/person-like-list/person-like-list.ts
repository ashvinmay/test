import {Component, EventEmitter, Input, Output} from '@angular/core';
import {NavController} from "ionic-angular";
import {Like} from "../../models/like.model";

@Component({
    selector: 'person-like-list',
    templateUrl: 'person-like-list.html'
})
export class PersonLikeListComponent {

    @Input() postId: string;
    @Input() commentId: string;
    @Input() likes: Array<Like>;

    @Output() openUserProfile: EventEmitter<string> = new EventEmitter<string>();

    constructor(public navCtrl: NavController) {
    }

    goToCommProfile(userId: string) {
        this.openUserProfile.emit(userId);
    }

}