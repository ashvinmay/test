import {Type} from "@angular/compiler/src/core";
import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Content, NavController, NavParams} from 'ionic-angular';
import {AnalyticService} from "../../../core/analytics/analytic.service";
import {UserDetails} from "../../../login/user.details";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {SearchPage} from "../../search/search-page/search";
import {CommunityCommon} from "../../shared/community-common";
import {CommunityPage} from "../../pages/community/community";
import {CommunityProfilePage} from "../../pages/community-profile/community-profile";

@Component({
    selector: 'page-community-tool-bar',
    templateUrl: 'community-tool-bar.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class CommunityToolBarPage implements OnInit, OnDestroy {

    private logger: Logger;

    @Input()
    content: Content;
    @Input()
    isUserProfilePage: boolean = false;
    @Input()
    isOwnerUserProfilePage: boolean = false;
    @Input()
    isSearchPage: boolean = false;
    @Input()
    showUploadProgress: boolean = false;

    @Input()
    userDetails: UserDetails;

    constructor(public navCtrl: NavController, public navParams: NavParams,
                loggerFactory: LoggerFactory,
                private communityCommon: CommunityCommon, private analyticService : AnalyticService) {

        this.logger = loggerFactory.getLogger("CommunityToolBarPage");

    }

    ngOnInit() {
        // Get user info
        this.logger.debug("Get User info")
        this.logger.info("nav stack size: ", this.navCtrl.length());
    }

    ngOnDestroy() {
        // prevent memory leak when component destroyed
        this.logger.debug("ngOnDestroy unsubscribe");
        // this.userDetailsSubscription.unsubscribe();
    }

    goToCommunity() {
        if (this.isUserProfilePage) {
            // If user navigate from home page to community then to my journal
            if (this.navCtrl.getPrevious().instance instanceof CommunityPage) {
                this.navCtrl.popTo('CommunityPage');
                return;
            }
            // If user navigates from home page to either community or my journal
            // and then goes to others profile pages then to my journal
            else if (this.navCtrl.getPrevious().instance instanceof CommunityProfilePage) {
                let stackLen = this.navCtrl.length();
                for (let i = 0; i < stackLen; i++) {
                  var view = this.navCtrl.getByIndex(i);
                  if (view.instance instanceof CommunityPage) {
                        this.navCtrl.popTo(view);
                        return;
                  }
                }
            } // else
            this.navCtrl.push('CommunityPage').then(data => {
              this.analyticService.trackPageView('CommunityPage')
            });;

        } else if(this.isSearchPage) {
          // If user navigate from home page to community then to my journal
          if (this.navCtrl.getPrevious().instance instanceof CommunityPage) {
            this.navCtrl.popTo('CommunityPage');
            return;
          } // else log invalid navigation */
        } else {
            // XXX Disable this feature for Android. This sometimes triggers an exception liked to timstamp field
            // which blocks the scroll to load more feature
            // try {
            //     this.content.scrollToTop(200);
            // } catch(e) {
            //     this.logger.warn("Could not scroll to Community top: " + e, e);
            // }
        }
        // this.logger.debug("Invalid navigation from: ", this.navCtrl.getActiveChildNav(), "to Community page!" );
    }

    goToMyJournal() {
        // If user is already his own profile page, scroll to top only
        if (!this.isOwnerUserProfilePage) {
            this.navCtrl.push('CommunityProfilePage', {
                userId: this.userDetails.userIdStr
            }).then(data => {
              let pageDetails = {
                "userId" : this.userDetails.userIdStr
              }
              this.analyticService.trackPageView('CommunityProfilePage', pageDetails);
            });
        } else {
            // XXX Disable this feature for Android. This sometimes triggers an exception liked to timstamp field
            // which blocks the scroll to load more feature
            // try {
            //     this.content.scrollToTop(200);
            // } catch(e) {
            //     this.logger.warn("Could not scroll to MyJournal top: " + e, e);
            // }
        }
    }

    showAddPostBottomSheet() {
        this.communityCommon.showAddPostBottomSheet(this.navCtrl);
    }

    showBottomSheet2() { /*showBottomSheet has multiple implementations..*/
        // this.communityCommon.showBottomSheet(this.navCtrl);
    }

    goToSearch() {
      if(this.navCtrl.getActive().instance instanceof SearchPage) { // or this.isSearchPage
        return;
      }
      if(this.hasPreviousPage(this.navCtrl, SearchPage)) {      //this.navCtrl.push('SearchPage');
        this.navCtrl.popTo('SearchPage'); // weird behaviour if navigation is already on 'SearchPage'
      } else {
        this.navCtrl.push('SearchPage');
      }
    }

     get canPost(): boolean {
        if (this.userDetails) {
           return this.userDetails.visibility == 'NORMAL'
        }
        return false;
     }

  private hasPreviousPage(navController: NavController, pageType: Type) {
    let previousPageCount = navController.getViews().filter(x => {
      return x.instance instanceof pageType
    }).length;
    //console.log("navigation views: ", this.navCtrl.getViews(), " no ", previousPageCount);
    return previousPageCount === 1;
  }

  getAvatarUrl() {
      if (this.userDetails.avatarId) {
        return this.communityCommon.getAvatarUrl(this.userDetails.userIdStr) + "?lastmodified=" + this.userDetails.avatarId;
      } // else

      this.logger.debug("could not find userDetails with avatarId !!", this.userDetails.avatarId);
    var defaultImageUrl = this.communityCommon.getAvatarUrl(this.userDetails.userIdStr);
    // this.logger.debug("defaultImageUrl:", defaultImageUrl);
    return defaultImageUrl;
    }

}
