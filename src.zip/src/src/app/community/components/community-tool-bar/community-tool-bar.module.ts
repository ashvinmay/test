import {NgModule} from "@angular/core";
import {TranslateModule} from "@ngx-translate/core";
import { IonicPageModule} from "ionic-angular";
import {CommunityToolBarPage} from "./community-tool-bar";

@NgModule({
    imports :[
        IonicPageModule.forChild(CommunityToolBarPage),
        TranslateModule.forChild()
    ],
    declarations : [
        CommunityToolBarPage
    ],
    exports : [
        CommunityToolBarPage
    ]
})
export class CommunityToolBarModule {}