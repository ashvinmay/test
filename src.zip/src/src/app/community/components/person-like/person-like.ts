import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Like} from "../../models/like.model";

@Component({
    selector: 'person-like',
    templateUrl: 'person-like.html'
})
export class PersonLikeComponent {

    @Input() like: Like;
    @Output() openPerson: EventEmitter<string> = new EventEmitter<string>();

    constructor() {
    }

    get avatarUrl(): string {
        return this.like.avatarId;
    }

    get isUserBlocked(): boolean {
        return this.like.visibilityCode == "RESTRICTED";
    }

    get timeElapsed() {
        return this.like.likeDate;
    }

    onClick() {
        this.openPerson.emit(this.like.userIdStr);
    }
}