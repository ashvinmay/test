import {NgModule} from "@angular/core";
import {TranslateModule} from "@ngx-translate/core";
import { IonicPageModule} from "ionic-angular";
import {AddPostToolBarPage} from "./add-post-tool-bar";

@NgModule({
    imports :[
        IonicPageModule.forChild(AddPostToolBarPage),
        TranslateModule.forChild()
    ],
    declarations : [
        AddPostToolBarPage
    ],
    exports : [
        AddPostToolBarPage
    ]
})
export class AddPostToolBarModule {}