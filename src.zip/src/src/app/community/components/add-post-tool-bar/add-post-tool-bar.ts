import {Component, Input} from "@angular/core";
import {NavController, NavParams} from "ionic-angular";
import {CommunityCommon} from "../../shared/community-common";
import {PhotoService} from "../../services/photo.service";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {Logger} from "../../../core/logger/logger";

@Component({
    selector: 'page-add-post-tool-bar',
    templateUrl: 'add-post-tool-bar.html'
})
export class AddPostToolBarPage {

    @Input()
    selectedPicturesURI: Array<string>;

    @Input()
    selectedPicture: string;

    private logger: Logger;

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                private photoService: PhotoService,
                private communityCommon: CommunityCommon,
                loggerFactory : LoggerFactory) {
        this.logger = loggerFactory.getLogger("AddPostToolBarPage");
    }

    canAddMorePictures(): boolean {
        return this.communityCommon.canAddMorePictures();
    }

    accessGallery() {
        this.photoService.checkGalleryPermission().then(result => {
            if (result && this.canAddMorePictures()) {
                this.photoService.openGallery().then(results => {
                        for (let i = 0; i < results.length; i++) {
                            this.logger.debug('Image URI: ' + results[i]);
                            this.selectedPicture = results[i];
                            if (this.selectedPicturesURI.length < 3) {
                                this.selectedPicturesURI.push(results[i]);
                            }
                        }
                    }, error => {
                        this.logger.error('Error while accessing gallery: ' + error);
                    }
                );
            }
        });
    }

    openCamera() {
        this.photoService.checkCameraPermission().then(result => {
            if (result && this.canAddMorePictures()) {
                this.photoService.openCamera().then((imageData) => {
                    this.selectedPicturesURI.push(imageData);
                    this.selectedPicture = imageData;
                }, (err) => {
                    this.logger.error("Error accessing camera: " + err);
                    this.communityCommon.presentCameraError();
                });
            }
        });
    }

}
