import {Component, Input, ChangeDetectionStrategy} from '@angular/core';
import {
    NavController, NavParams, ActionSheetController
} from 'ionic-angular';
import {AnalyticService} from "../../../core/analytics/analytic.service";
import {CommunityCommon} from "../../shared/community-common";
import {Post} from "../../models/post";
import {UserDetails} from "../../../login/user.details";
import {Comment} from "../../models/comment";

@Component({
    selector: 'page-post-list',
    templateUrl: 'post-list.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PostListPage {

    @Input() posts: Array<Post>;
    @Input() userDetails: UserDetails;
    @Input() isUserProfilePage: boolean = false;
    @Input() profileUserId: string = "";

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                private actionSheetCtrl: ActionSheetController,
                private communityCommon: CommunityCommon,
                private analyticService: AnalyticService) {
        this.posts = [];
    }

    viewPostDetail(post: Post, lastComment: boolean, keyboard: boolean) {
        this.navCtrl.push('ViewPostPage', {
            post: post,
            userDetails: this.userDetails,
            lastComment: lastComment,
            showKeyboard: keyboard
        }).then(data => {
            let pageDetails = {
                "postId": post.postIdStr
            };
            this.analyticService.trackPageView('ViewPostPage', pageDetails);
        });
    }

    goToCommProfile(userId: string) {
        if (!this.isUserProfilePage || this.profileUserId != userId) {
            this.navCtrl.push('CommunityProfilePage', {
                userId: userId
            }).then(data => {
                let pageDetails = {
                    "userId": userId
                };
                this.analyticService.trackPageView('CommunityProfilePage', pageDetails);
            });
        }
    }

    showBottomSheet(post: Post) {
        if (!this.isUserBlocked() || (this.isUserBlocked() && post.userIdStr == this.userDetails.userIdStr)) {
            let buttons = this.communityCommon.createPostButtons(post, this);
            const bottomSheet = this.actionSheetCtrl.create({buttons});
            bottomSheet.present();
        }
    }

    editPost(post: Post) {
        this.navCtrl.push('EditPostPage', {
            post: post
        }).then(data => {
            let pageDetails = {
                "postId": post.postIdStr
            };
            this.analyticService.trackPageView('EditPostPage', pageDetails);
        });
    }

    isUserBlocked() {
        return this.userDetails.visibility == 'RESTRICTED';
    }

    likeOrDislikeComment(post: Post, comment: Comment) {
        if (!this.isUserBlocked()) {
            this.communityCommon.likeOrDislikeComment(post, comment);
        }
    }

    deleteComment(post: Post, comment: Comment) {
        this.communityCommon.deleteComment(post, comment);
    }

    reportComment(post: Post, comment: Comment) {
        if (!this.isUserBlocked()) {
            let buttons = this.communityCommon.createCommentButtons(post, comment);
            const bottomSheet = this.actionSheetCtrl.create({buttons});
            bottomSheet.present();
        }
    }

    showWhoLikedPost(post: Post) {
        if (!this.isUserBlocked()) {
            this.navCtrl.push('PeopleLikesPage', {
                postId: post.postIdStr
            });
        }
    }

    showWhoLikedComment(post: Post, comment: Comment) {
        if (!this.isUserBlocked()) {
            this.navCtrl.push('PeopleLikesPage', {
                postId: post.postIdStr,
                commentId: comment.commentIdStr
            });
        }
    }

    trackPostByFn(index, post: Post) {
        return post.postIdStr;
    }

    trackCommentByFn(index, comment: Comment) {
        return comment.commentIdStr;
    }

}