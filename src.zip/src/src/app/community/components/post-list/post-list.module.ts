import {NgModule} from "@angular/core";
import {TranslateModule} from "@ngx-translate/core";
import {IonicPageModule} from "ionic-angular";
import {PostListPage} from "./post-list";
import {ComponentsModule} from "../../shared/components.module";

@NgModule({
    imports :[
        ComponentsModule,
        IonicPageModule.forChild(PostListPage),
        TranslateModule.forChild()
    ],
    declarations : [
        PostListPage
    ],
    exports : [
        PostListPage
    ]
})
export class PostListPageModule {}