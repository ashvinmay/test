import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Comment} from "../../models/comment";
import {ItemSliding} from "ionic-angular";
import {UserDetails} from "../../../login/user.details";
import {CommunityCommon} from "../../shared/community-common";

@Component({
    selector: 'comment',
    templateUrl: 'comment.html'
})
export class CommentComponent {

    @Input() comment: Comment;
    @Input() userDetails: UserDetails;
    @Input() isPostDetailPage: boolean;
    @Input() isUserBlocked: boolean;
    @Input() isPostRestricted: boolean;

    @Output() openComponent: EventEmitter<Comment> = new EventEmitter();
    @Output() openProfile: EventEmitter<Comment> = new EventEmitter();
    @Output() deleteComment: EventEmitter<Comment> = new EventEmitter();
    @Output() reportComment: EventEmitter<Comment> = new EventEmitter();
    @Output() likeOrDislike: EventEmitter<Comment> = new EventEmitter();
    @Output() whoLiked: EventEmitter<Comment> = new EventEmitter();

    constructor(private communityCommon: CommunityCommon) {
    }

    showProfile() {
        this.openProfile.emit(this.comment);
    }

    onOpen() {
        this.openComponent.emit(this.comment);
    }

    onLikeOrDislike() {
        if (!this.comment.moderated) {
            this.likeOrDislike.emit(this.comment);
        }
    }

    onDelete(swipingItem?: ItemSliding) {
        swipingItem.close();
        this.deleteComment.emit(this.comment);
    }

    onReport(swipingItem?: ItemSliding) {
        swipingItem.close();
        this.reportComment.emit(this.comment);
    }

    getAvatarUrl(userId): string {
        if (userId == this.userDetails.userIdStr) {
            if (this.userDetails.avatarId) {
                return this.communityCommon.getAvatarUrl(this.userDetails.userIdStr) + "?lastmodified=" + this.userDetails.avatarId;
            }
        }
        return this.communityCommon.getAvatarUrl(userId);
    }

    showWhoLiked() {
        if (this.comment.likeCount > 0) {
            this.whoLiked.emit(this.comment);
        }
    }
}