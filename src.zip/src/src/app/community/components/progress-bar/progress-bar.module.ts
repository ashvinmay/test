import {NgModule} from "@angular/core";
import { IonicPageModule} from "ionic-angular";
import {ProgressBarComponent} from "./progress-bar";

@NgModule({
    imports :[
        IonicPageModule.forChild(ProgressBarComponent)
    ],
    declarations : [
        ProgressBarComponent
    ],
    exports : [
        ProgressBarComponent
    ]
})
export class ProgressBarComponentModule {}