import {Injectable} from '@angular/core';
import {Camera, CameraOptions} from "@ionic-native/camera";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {ImagePicker, ImagePickerOptions} from "@ionic-native/image-picker";
import {Platform} from "ionic-angular";
import {PermissionsService} from "../../core/permissions.service";
import stringify from "fast-safe-stringify";

declare var plugins: any;

/*
 Take pictures using the camera of the device and also provide access to the image gallery of the device.
 */
@Injectable()
export class PhotoService {

    private logger: Logger;

    private cameraOptions: CameraOptions = {
        sourceType: this.camera.PictureSourceType.CAMERA,
        destinationType: this.camera.DestinationType.FILE_URI,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE,
        correctOrientation: true,
        allowEdit: false,
        quality: 90,
        saveToPhotoAlbum: true,
        targetWidth: 1920,
        targetHeight: 1920
    };

    private imagePickerOptions: ImagePickerOptions = {
        maximumImagesCount: 3,
        width: 1920,
        height: 1920,
        quality: 90
    };

    constructor(private permissionService: PermissionsService,
                private platform: Platform,
                private imagePicker: ImagePicker,
                private camera: Camera,
                loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("PhotoService");
    }

    public checkGalleryPermission(): Promise<boolean> {
        this.logger.debug("Checking Gallery Permission...");
        return this.permissionService.checkGalleryPermission().then(result => {
            this.logger.debug("Gallery Permission: " + result);
            return result;
        });
    }

    public checkCameraPermission(): Promise<boolean> {
        this.logger.debug("Checking Camera Permission...");
        return this.permissionService.checkCameraPermission().then(result => {
            this.logger.debug("Camera Permission: " + result);
            return result;
        });
    }

    /**
     * Take picture using device camera an return a URI to the image.
     * @param options {EscCameraOptions} specific options to be used for overriding default ones
     * @returns {Promise<string>} The Promise with an URI to the image.
     */
    public openCamera(options?: EscCameraOptions): Promise<string> {
        let optionsToUse = this.computeOptions(this.cameraOptions, options);
        this.logger.debug("Opening camera using options: " + stringify(optionsToUse));
        return this.camera.getPicture(optionsToUse)
            .then(image => this.normalizeUrlIos(image));
    }

    /**
     * Open the camera an get a picture to be used as user's avatar.
     * @returns {Promise<string>} Returns a promise that resolves with the new image path for the avatar, or rejects if failed to crop.
     */
    public openCameraAndCropImage(options?: EscCameraOptions, cropOptions?: EscCropOptions): Promise<string> {
        return this.openCamera(options)
            .then(imageURI => {
                return this.cropImage(imageURI, cropOptions);
            });
    }

    /**
     * Let the user select from the photos on the device a maximum number of 3 (three) photos.
     * @param options {EscImagePickerOptions} specific options to be used for overriding default ones
     * @returns {Promise<Array<string>>}
     */
    public openGallery(options?: EscImagePickerOptions): Promise<Array<string>> {
        let optionsToUse = this.computeOptions(this.imagePickerOptions, options);
        this.logger.debug("Opening gallery using options: " + stringify(optionsToUse));
        return this.imagePicker.getPictures(optionsToUse)
            .then(images => {
                if (images && images.length > 3) {
                    return images.splice(0, 3);
                }
                return this.normalizeUrlsIos(images);
            });
    }

    private normalizeUrlsIos(urls: Array<string>): string[] {
        return urls.map(url => this.normalizeUrlIos(url));
    }

    private normalizeUrlIos(url: string): string {
        return (url).replace(/(cdvfile|file):\/\//g, '');
    }

    /**
     * Open the gallery an get a picture to be used as user's avatar.
     * @returns {Promise<string>} Returns a promise that resolves with the new image path for the avatar, or rejects if failed to crop.
     */
    public openGalleryAndCropImage(options?: EscImagePickerOptions, cropOptions?: EscCropOptions): Promise<string> {
        return this.openGallery(options)
            .then(imageURIs => {
                return this.cropImage(imageURIs[0], cropOptions);
            });
    }

    private computeOptions<T>(defaultOptions: T, specificOptions?: T): T {
        if (specificOptions) {
            return Object.assign({}, defaultOptions, specificOptions);
        }
        return defaultOptions;
    }

    /**
     * @param croppedFile
     * @returns {Promise<string>} Returns a promise that resolves with the new image path, or rejects if failed to crop.
     */
    private cropImage(croppedFile, cropOptions?: EscCropOptions): Promise<string> {
        // Crop Image, on android this returns something like, '/storage/emulated/0/Android/...'
        this.logger.debug('Original image URI: ', croppedFile, " crop options: ", cropOptions);
        if (this.platform.is('android')) {
            croppedFile = 'file://' + croppedFile;
            this.logger.debug('Android URI: ' + croppedFile);
        }

        return this.platform.ready().then(() => {
            return plugins.crop.promise(croppedFile, cropOptions)
                .then(function success(newPath) {
                    return newPath;
                })
                .catch(function fail(err) {
                    this.logger.debug(stringify(err))
                });
        });
    }

}

export interface EscCameraOptions extends CameraOptions {

}

export interface EscImagePickerOptions extends ImagePickerOptions {

}

export class EscCropOptions {
    widthRatio: number = 16;
    heightRatio: number = 9;
    quality: number = 100;
}
