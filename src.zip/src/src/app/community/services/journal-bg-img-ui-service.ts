import {LoggerFactory} from "../../core/logger/logger-factory";
import {TranslateService} from "@ngx-translate/core";
import {ActionSheetController, AlertController} from "ionic-angular";
import {
  EscCameraOptions, EscCropOptions, EscImagePickerOptions, PhotoService
} from "./photo.service";
import {AlertUtils} from "../../core/alert-utils";
import {CommunityProfileService} from "../pages/community-profile/community-profile.service";
import stringify from "fast-safe-stringify";
import {Logger} from "../../core/logger/logger";
import {CommunityProfile} from "../pages/community-profile/community-profile.model";
import {LoadingUiService} from "./loading-ui-service";
import {CommunityCommon} from "../shared/community-common";
import {Injectable} from "@angular/core";

/**
 * Helper class for manipulation Journal background images
 */
@Injectable()
export class JournalBgImgUiService {

  private logger: Logger;
  private imageOptions: EscImagePickerOptions = {
    maximumImagesCount: 1,
  };

  private cameraOptions: EscCameraOptions = {
    allowEdit: true,
    targetWidth: 1200, // 16:9 ratios
    targetHeight: 675,
    quality: 90
  };

  private cropOptions: EscCropOptions = {
    widthRatio: 16,
    heightRatio: 9,
    quality: 100
  };

  constructor(private loadingHelper: LoadingUiService,
              private alertCtrl: AlertController,
              private translateService: TranslateService,
              loggerFactory: LoggerFactory,
              private communityCommon: CommunityCommon,
              private alertUtils: AlertUtils,
              private actionSheetCtrl: ActionSheetController,
              private photoService: PhotoService,
              private communityProfileService: CommunityProfileService
  ) {
    this.logger = loggerFactory.getLogger("JournalBgImgUiService");
  }

  showBottomSheet(communityProfile: CommunityProfile, userIdStr: string) {
    let bottomSheetJournalBg;
    let buttons: Array<any> = [];
    buttons.push({
      text: this.translateService.instant('OPEN_GALLERY'),
      icon: 'ios-images-outline',
      handler: () => {
        let navTransition = bottomSheetJournalBg.dismiss();
        this.photoService.checkGalleryPermission().then(result => {
          if (result) {
            navTransition.then(() => {
              this.accessGallery();
            });
          }
        });
        // MUST return false to inform the action sheet that our code is handling the dismiss
        return false;
      }
    });
    buttons.push({
      text: this.translateService.instant('TAKE_PHOTO'),
      icon: 'ios-camera-outline',
      handler: () => {
        let navTransition = bottomSheetJournalBg.dismiss();
        this.photoService.checkCameraPermission().then(result => {
          if (result) {
            navTransition.then(() => {
              this.openCamera();
            });
          }
        });
        // MUST return false to inform the action sheet that our code is handling the dismiss
        return false;
      }
    });
    if (communityProfile.hasJournalBgImg) {
      buttons.push({
        text: this.translateService.instant('COMMUNITY_PROFILE_DELETE_AVATAR'),
        icon: 'ios-trash-outline',
        role: 'destructive',
        handler: () => {
          bottomSheetJournalBg.dismiss().then(() => {
            this.presentConfirmDelete(userIdStr);
          });
          // MUST return false to inform the action sheet that our code is handling the dismiss
          return false;
        }
      });
    }
    buttons.push({
      text: this.translateService.instant('GLOBAL_CANCEL'),
      icon: 'md-close',
      role: 'cancel',
      handler: () => {
      }
    });
    bottomSheetJournalBg = this.actionSheetCtrl.create({buttons});
    bottomSheetJournalBg.present();
  }

  private presentConfirmDelete(userIdStr: string) {
    let alert = this.alertCtrl.create({
      title: this.translateService.instant('CONFIRM_DELETE'),
      message: this.translateService.instant('DELETE_JOURNAL_BG_IMG_CONFIRMATION'),
      buttons: [
        {
          text: this.translateService.instant('GLOBAL_CANCEL'),
          role: 'cancel',
          handler: () => {
          }
        },
        {
          text: this.translateService.instant('GLOBAL_OK'),
          handler: () => {
            this.communityProfileService.deleteJournalBg(userIdStr).subscribe(
              () => {
              },
              (err) => {
                this.handleGetPostsError(err);
              }
            );
          }
        }
      ]
    });
    alert.present();
  }

  private handleGetPostsError(err: any) {
    this.alertUtils.handleGetPostsError(err);
  }

  private accessGallery() {
    this.photoService.openGalleryAndCropImage(this.imageOptions, this.cropOptions)
      .then((fileUri) => {
        return this.uploadJournalBgImage(fileUri);// ImagePicker returns an array
      }, error => {
        this.logger.error('Error browsing gallery: ' + stringify(error));
      });
  }

  openCamera() {
    this.photoService.openCameraAndCropImage(this.cameraOptions, this.cropOptions)
      .then((croppedFile) => {
        this.uploadJournalBgImage(croppedFile);
      }, (error) => {
        this.logger.error("Error accessing camera: " + stringify(error));
        this.communityCommon.presentCameraError();
      });
  }

  private uploadJournalBgImage(imageURI: string): Promise<boolean> {
    this.loadingHelper.showLoading();
    return this.communityProfileService.uploadJournalBg(imageURI).then((result) => {
      this.loadingHelper.hideLoading();
      return true;
    }, (error) => {
      this.loadingHelper.hideLoading();
      this.handleGetPostsError(error);
      return false;
    });
  }
}
