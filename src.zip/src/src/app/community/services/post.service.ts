import {Injectable, NgZone} from "@angular/core";
import "rxjs/add/operator/map";
import {Post} from "../models/post";
import {Observable, Observer} from "rxjs/Rx";
import {Subject} from "rxjs/Subject";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {EscHttp} from "../../core/http/esc-http";
import {EscFiles} from "../../core/http/esc-files";
import stringify from "fast-safe-stringify";
import {EnvConfiguration} from "../../../env/env.configuration";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import {Comment} from "../models/comment";
import {TranslateService} from "@ngx-translate/core";
import {ProjectType} from "../models/project-type.model";
import {SharePost} from "../models/sharePost.model";
import {map, tap} from "rxjs/operators";
import {DatePipe} from "@angular/common";
import {Like} from "../models/like.model";

@Injectable()
export class PostService {

    private logger: Logger;
    private subjectDeleted = new Subject<Post>();
    private subjectAddPost = new Subject<Post>();
    private subjectUpdatePost = new Subject<Post>();
    private subjectUploadProgress = new BehaviorSubject<number>(0);
    private subjectShowUploadProgress = new BehaviorSubject<boolean>(false);
    private picsToBeUpload: number = 1;
    private computedUploadProgress: number = 0;
    public pageSize = 10;
    private moderatedText: string;

    constructor(private escHttp: EscHttp,
                private escFiles: EscFiles,
                private config: EnvConfiguration,
                private translateService: TranslateService,
                loggerFactory: LoggerFactory, private ng_zone: NgZone) {
        this.logger = loggerFactory.getLogger("PostService");
        translateService.get("ADMIN_HIDDEN_COMMENT").subscribe(
            (text) => {
                this.moderatedText = text;
            });
    }

    public getCommunityTopPosts(projectTypeId: number): Observable<Array<Post>> {
        this.logger.debug("getCommunityTopPosts projectTypeId: ", projectTypeId);
        this.logger.debug("getCommunityTopPosts pageSize: ", this.pageSize);
        let url = this.getTopCommunityPostsUrl();
        let params = this.buildCommunityParams(undefined, this.pageSize, projectTypeId);
        return this.escHttp.getJson<any>(url, params)
            .pipe(
                tap(res => {
                    this.logger.debug("getCommunityTopPosts Result: ", res);
                }),
                this.toMapPosts()
            );
    }

    private toMapPosts() {
        return map(res => {
            return this.mapPosts(res);
        });
    }

    public getOlderCommunityTopPosts(topTimelineIdStr: string, projectTypeId: number): Observable<Array<Post>> {
        this.logger.debug("getOlderTopCommunityPosts topTimelineId: " + topTimelineIdStr + ", pageSize: " + this.pageSize);
        let url = this.getTopCommunityPostsUrl();
        let params = this.buildCommunityParams(topTimelineIdStr, this.pageSize, projectTypeId);
        return this.escHttp.getJson<any>(url, params)
            .pipe(
                tap(res => {
                    this.logger.debug("getOlderTopCommunityPosts Result: ", res);
                    this.logger.debug("getOlderTopCommunityPosts Body:\n", stringify(res));

                }),
                this.toMapPosts()
            );
    }

    /**
     * Allows to not overwrite the Post entity
     */
    private mapPosts(posts: any): Array<Post> {
        return posts.map(
            (post) => {
                post = new Post(post);
                post.comments = this.mapComments(post.safeComments);
                return post
            });
    }

    private getTopCommunityPostsUrl() {
        return this.config.postUrl + "/topposts";
    }

    public getPost(postId: string, etag: string, defaultPost: Post): Observable<Post> {
        this.logger.debug("getPost postId: ", postId, " with eTag: ", etag);
        let url = this.config.postUrl + "/" + postId;
        return this.escHttp.getConditionally<any>(url, this.getETagHeaders(etag), null, defaultPost).pipe(
            map(res => {
                this.logger.debug("getPost Result: ", res);
                //this.logger.debug("getPost Body:\n" + stringify(res));
                let post = new Post(res);
                post.comments = this.mapComments(post.safeComments);
                this.subjectUpdatePost.next(post);
                return post;
            })
        );
    }


    public getPostForNotification(postId: string): Observable<Post> {
        this.logger.debug("getPost postId: ", postId);
        let url = this.config.postUrl + "/" + postId;
        return this.escHttp.getJson(url).pipe(
            map(res => {
                this.logger.debug("getPost Result: ", res);
                //this.logger.debug("getPost Body:\n" + stringify(res));
                let post = new Post(res);
                post.comments = this.mapComments(post.safeComments);
                post.updateTimeSince(new Date(), new DatePipe(this.translateService.currentLang), this.translateService)
                return post;
            })
        );

    }

    public getUserPosts(userId: string, timelineIdStr: string, projectTypeId: number): Observable<Array<Post>> {
        this.logger.debug("getUserPosts for userId: " + userId + ", timelineId: " + timelineIdStr);
        let url = this.config.getCommunityProfileUrl + userId + this.config.getPostSuffix;
        let params = this.buildUserPostParams(timelineIdStr, this.pageSize, projectTypeId);
        return this.escHttp.getJson(url, params)
            .map(res => {
                this.logger.debug("getUserPosts Result: ", res);
                return this.mapPosts(res);
            });
    }

    public savePost(post: Post, title: string, description: string, projectType: ProjectType): Observable<any> {
        this.logger.debug("savePost postId: " + post.postIdStr);

        // New instance for Post to update
        let postToSave = new Post(post);
        postToSave.title = title;
        postToSave.description = description;
        postToSave.projectType = projectType;

        let url = this.config.postUrl;
        return this.escHttp.putJson(url, postToSave)
            .map(() => {
                this.logger.debug("editPost Result: success");
                post.title = title;
                post.description = description;
                if (projectType && projectType.id >= 0) {
                    post.projectType = projectType;
                } else {
                    post.projectType = undefined;
                }
                this.subjectUpdatePost.next(post);
            });
    }

    public deletePost(post: Post): Observable<any> {
        this.logger.debug("deletePost postId: " + post.postIdStr);
        let url = this.config.postUrl + "/" + post.postIdStr;
        return this.escHttp.delete(url)
            .map(() => {
                this.logger.debug("deletePost Result: success");
                this.subjectDeleted.next(post);
            });
    }

    public reportPost(post: Post): Observable<any> {
        this.logger.debug("reportPost postId: " + post.postIdStr);
        let url = this.config.postUrl + "/" + post.postIdStr + "/report";
        return this.escHttp.postJson(url)
            .map(() => {
                this.logger.debug("reportPost Result: success");
            });
    }

    public subscribeToAddPost(): Observable<Post> {
        this.logger.debug("subscribeToAddPost");
        return this.subjectAddPost.asObservable();
    }

    public subscribeToDeletePost(): Observable<Post> {
        this.logger.debug("subscribeToDeletePost");
        return this.subjectDeleted.asObservable();
    }

    public subscribeToUpdatePost(): Observable<Post> {
        this.logger.debug("subscribeToUpdatePost");
        return this.subjectUpdatePost.asObservable();
    }

    public getImageUrl(imageId): string {
        return this.config.imageUrl + "/" + imageId;
    }

    public getSharePost(postIdStr: string, appId: number): Observable<SharePost> {
        this.logger.debug("share postId=" + postIdStr);
        let url = this.getSharePostUrl(postIdStr, appId);
        return this.escHttp.postJson<SharePost>(url)
            .map(res => {
                //return new SharePost(res);
                this.logger.debug("share post url: ", res.shareUrl);
                return res;
            });
    }

    public getSharePostUrl(postIdStr: string, appId: number) {
        return this.config.postUrl + "/" + postIdStr + "/" + appId + "/share";
    }

    public getPublicShareUrl(sharePost: SharePost) {
        return this.config.apiBaseUrl + sharePost.shareUrl;
    }

    public addLike(post: Post): Observable<number> {
        this.logger.debug("addLike postId=" + post.postIdStr);
        let url = this.getLikeUrl(post.postIdStr);
        return this.escHttp.postJson<number>(url)
            .map(res => {
                this.logger.debug("addLike Result: ", res);
                post.likeCount = res;
                post.liked = true;
                this.subjectUpdatePost.next(post);
                return res;
            });
    }

    private getLikeUrl(postId: string) {
        return this.config.postUrl + "/" + postId + "/like";
    }

    private getPostLikesUrl(postId: string) {
        return this.config.postUrl + "/" + postId + "/likes";
    }

    public removeLike(post: Post): Observable<string> {
        this.logger.debug("removeLike postId: " + post.postIdStr);
        let url = this.getLikeUrl(post.postIdStr);
        return this.escHttp.delete(url)
            .map(res => {
                this.logger.debug("removeLike Result:\n" + stringify(res));
                post.likeCount = res;
                post.liked = false;
                this.subjectUpdatePost.next(post);
                return res;
            });
    }

    private buildCommunityParams(topTimelineIdStr: string, pageSize: number, projectTypeId: number): any {
        let params = {"pageSize": pageSize};
        if (topTimelineIdStr) {
            params["topTimelineId"] = topTimelineIdStr;
        }

        params["projectTypeId"] = projectTypeId;

        return params;
    }

    private buildUserPostParams(timelineIdStr: string, pageSize: number, projectTypeId: number): any {
        let params = {"pageSize": pageSize};
        if (timelineIdStr) {
            params["timelineId"] = timelineIdStr;
        }
        params["projectTypeId"] = projectTypeId;
        return params;
    }

    private getETagHeaders(etag: string) {
        return {"If-None-Match": '"' + etag + '"'};
    }

    /* ========
     * ADD POST
     * ======== */

    private buildJsonPost(post: Post) {
        return {
            "title": post.title,
            "description": post.description,
            "projectType": post.projectType
        }
    }

    public addPost(post: Post, selectedPicturesURI: Array<string>): Observable<any> {
        return new Observable<any>((observer) => {
            let json = this.buildJsonPost(post);
            this.logger.debug("addPost body: ", json);
            this.subjectShowUploadProgress.next(true);
            this.subjectUploadProgress.next(1);
            this.escHttp.postJson<string>(
                this.config.postUrl,
                json,
            )
                .subscribe(
                    response => {
                        //if (response.ok) {
                        //this.logger.debug(`addPost response: OK, status: ${response.status}`);
                        this.logger.debug('addPost response ', response);
                        post.postIdStr = response;
                        this.uploadPictures(0, post, selectedPicturesURI, observer);
                        // }
                    },
                    error => {
                        this.logger.error("addPost error: ", error.error);
                        this.subjectShowUploadProgress.next(false);
                        observer.error(error);
                    });
        });
    }

    public uploadPictures(current: number, post: Post, selectedPicturesURI: Array<string>, observer: Observer<any>) {
        if (current < selectedPicturesURI.length) {
            this.picsToBeUpload = selectedPicturesURI.length;
            current++;

            this.uploadPicture(post.postIdStr, selectedPicturesURI[current - 1])
                .then((result: any) => {
                    this.logger.debug("Upload success: " + stringify(result));
                    this.uploadPictures(current, post, selectedPicturesURI, observer);
                })
                .catch((error: any) => {
                    this.logger.error("Upload failed: " + stringify(error));
                    this.subjectShowUploadProgress.next(false);
                    observer.error(error);
                });
        } else {
            observer.next(post);
            observer.complete();
            this.subjectAddPost.next(post);
            this.subjectShowUploadProgress.next(false)
        }
    };

    public uploadPicture(postIdStr: string, localImageUrl: string): Promise<any> {
        let url = this.config.postUrl + "/" + postIdStr + "/image";
        return this.escFiles.uploadJpeg(localImageUrl, url, this.on_progress);
    }

    /**
     * The on upload progress callback event
     * @param progressEvent The progress event of the image upload
     */
    private on_progress = (progressEvent: ProgressEvent): void => {
        this.ng_zone.run(() => {
            if (progressEvent.lengthComputable) {
                let progress = Math.round((progressEvent.loaded / progressEvent.total) * 100);
                if (progress > 98) {
                    progress = 100;
                }
                if (progress < 0) progress = 0;
                let uploadProgress: number = this.computedUploadProgress + Math.round(progress / this.picsToBeUpload);
                this.subjectUploadProgress.next(uploadProgress);
                if (progress == 100) {
                    this.computedUploadProgress = uploadProgress;
                }
                if (this.computedUploadProgress > 98) {
                    this.subjectShowUploadProgress.next(false);
                    this.computedUploadProgress = 0;
                }
            }
        });
    };

    public subscribeToUploadProgress(): Observable<number> {
        this.logger.debug("subscribeToUploadProgress");
        return this.subjectUploadProgress.asObservable();
    }

    public subscribeToShowUploadProgress(): Observable<boolean> {
        this.logger.debug("subscribeToUploadProgress");
        return this.subjectShowUploadProgress.asObservable();
    }

    /* ========
     * COMMENTS
     * ======== */

    public addComment(post: Post, comment: string): Observable<Comment> {
        let jsonComment = this.buildJsonComment(comment);
        this.logger.debug("addComment for postId=", post.postIdStr);
        //this.logger.debug("addComment body: ", stringify(jsonComment));
        let url = this.getCommentsUrl(post.postIdStr);
        return this.escHttp.postJson<Comment>(
            url, jsonComment)
            .pipe(
                map((comment: Comment) => {
                    this.setAvatarUrl(comment);
                    this.logger.debug('addComment result:', comment);
                    post.addComment(comment);
                    this.subjectUpdatePost.next(post);
                    return comment;
                })
            );
    }

    private buildJsonComment(comment: string) {
        return {
            "text": comment,
        }
    }

    public addCommentLike(post: Post, comment: Comment): Observable<number> {
        this.logger.debug("addCommentLike postId=" + comment.postIdStr + ", commentId=" + comment.commentIdStr);
        let url = this.getCommentUrl(comment.postIdStr, comment.commentIdStr) + "/like";
        return this.escHttp.postJson<number>(url)
            .map(res => {
                this.logger.debug("addLike Result: ", res);
                comment.likeCount = res; // Number(res);
                comment.liked = true;
                this.subjectUpdatePost.next(post);
                return res;
            });
    }

    public removeCommentLike(post: Post, comment: Comment): Observable<string> {
        this.logger.debug("removeCommentLike postId=" + comment.postIdStr + ", commentId=" + comment.commentIdStr);
        let url = this.getCommentUrl(comment.postIdStr, comment.commentIdStr) + "/like";
        return this.escHttp.delete(url)
            .map(res => {
                this.logger.debug("removeCommentLike Result: " + stringify(res));
                comment.likeCount = res;
                comment.liked = false;
                this.subjectUpdatePost.next(post);
                return res;
            });
    }

    public deleteComment(post: Post, comment: Comment): Observable<any> {
        this.logger.debug("deleteComment postId=" + comment.postIdStr + ", commentId=" + comment.commentIdStr);
        let url = this.getCommentUrl(comment.postIdStr, comment.commentIdStr);
        return this.escHttp.delete(url)
            .map(() => {
                this.logger.debug("deleteComment Result: success");
                post.removeComment(comment.commentIdStr);
                this.subjectUpdatePost.next(post);
            });
    }

    public reportComment(post: Post, comment: Comment): Observable<any> {
        this.logger.debug("reportComment postId=" + comment.postIdStr + ", commentId=" + comment.commentIdStr);
        let url = this.getCommentUrl(comment.postIdStr, comment.commentIdStr) + "/report";
        return this.escHttp.postJson(url)
            .map(() => {
                this.logger.debug("reportComment Result: success");
            });
    }

    private getCommentUrl(postId: string, commentId: string): string {
        return this.getCommentsUrl(postId) + "/" + commentId;
    }

    private getCommentsUrl(postId: string): string {
        return this.config.postUrl + "/" + postId + this.config.commentsSuffix;
    }

    private getCommentLikesUrl(postId: string, commentId: string) {
        return this.getCommentUrl(postId, commentId) + "/likes";
    }

    /* ==============
     * FETCH COMMENTS
     * ============== */

    public getOlderComments(post: Post): Observable<Array<Comment>> {
        this.logger.debug("getOlderComments postId=" + post.postIdStr + ", olderCommentId=" + post.olderCommentId);
        let url = this.getCommentsUrl(post.postIdStr) + "/older";
        let params = this.buildCommentsParams(post.olderCommentId);
        return this.escHttp.getJson<Array<Comment>>(url, params)
            .map(res => {
                this.logger.debug("getOlderComments Result: ", res);
                //this.logger.debug("getOlderComments Body:\n" + stringify(res));
                let comments = this.mapComments(res);
                if (comments.length > 0) {
                    post.insertComments(comments);
                    this.subjectUpdatePost.next(post);
                }
                return comments;
            });
    }

    private buildCommentsParams(commentId: string): {} {
        let params = {};
        if (commentId) {
            params["commentId"] = commentId;
        }
        return params;
    }

    /**
     * Allows to not overwrite the Post entity
     */
    private mapComments(comments: Array<Comment>): Array<Comment> {
        comments = comments.map(comment => {
            this.setAvatarUrl(comment);
            if (comment.moderated) {
                comment.text = this.moderatedText;
            }
            return new Comment(comment);
        });
        return comments;
    }

    private setAvatarUrl(comment: Comment) {
        comment.userAvatar = this.getAvatarUrl(comment.userIdStr);
    }

    public getAvatarUrl(userId): string {
        return this.config.getAvatarUrl + userId;
    }

    //Get Project Types
    public getProjectTypes(): Observable<Array<ProjectType>> {
        this.logger.debug("Get project type to categories the post ");
        let url = this.config.postUrl + "/projectTypes";
        return this.escHttp.getJson<Array<ProjectType>>(url).map(res => {
            return res;
        });
    }

    // LIKES

    getPostLikes(postId: string, likeId: string): Observable<Array<Like>> {
        this.logger.debug("getPostLikes postId=" + postId + " likeId=" + likeId);
        let url = this.getPostLikesUrl(postId);
        let params = this.buildLikeParam(likeId);
        return this.escHttp.getJson<Array<Like>>(url, params)
            .pipe(
                tap((likes: Array<Like>) => {
                    this.logger.debug("getPostLikes Result: ", likes);
                    this.logger.debug("getPostLikes Body:\n", stringify(likes));
                    return this.mapLikesForUI(likes);
                })
            );
    }

    getCommentLikes(postId: string, likeId: string, commentId: string): Observable<Array<Like>> {
        this.logger.debug("getCommentLikes commentId=" + commentId + " likeId=" + likeId);
        let url = this.getCommentLikesUrl(postId, commentId);
        let params = this.buildLikeParam(likeId);
        return this.escHttp.getJson<Array<Like>>(url, params)
            .pipe(
                map((likes: Array<Like>) => {
                    this.logger.debug("getCommentLikes Result: ", likes);
                    this.logger.debug("getCommentLikes Body:\n", stringify(likes));
                    return this.mapLikesForUI(likes);
                })
            );
    }

    private buildLikeParam(likeId: string) {
        let params = {};
        if (likeId) {
            params["likeId"] = likeId;
        }
        return params;
    }

    private mapLikesForUI(likes: Array<Like>): Array<Like> {
        let now: Date = new Date();
        let datePipe = new DatePipe(this.translateService.currentLang);

        return likes.map(like => {
            // Avatar
            like.avatarId = this.getAvatarUrl(like.userIdStr);
            // TimeSince
            like.timeSince = Post.calculateTimeSince(like.likeDate, now, datePipe, this.translateService);
            return like;
        });
    }

}