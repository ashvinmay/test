import {Injectable, OnDestroy} from '@angular/core';
import 'rxjs/add/operator/map';
import {Observable} from "rxjs/Rx";
import {Subject} from "rxjs/Subject";
import {Subscription} from "rxjs/Subscription";
import {Comment} from "../models/comment";
import {Post} from "../models/post";
import {PostService} from "./post.service";

@Injectable()
export class ViewPostService implements OnDestroy {

    private subscriptions: Array<Subscription>;
    private subjectPostUpdates: Subject<Post> = new Subject();

    constructor(private postService: PostService) {
        this.init();
    }

    private init() {
        this.subscriptions = [];
        this.subscriptions.push(this.postService.subscribeToUpdatePost().subscribe(
            (post) => {
                this.subjectPostUpdates.next(post);
            }));
    }

    ngOnDestroy() {
        // Prevent memory leak when component destroyed
        for (let subscription of this.subscriptions) {
            subscription.unsubscribe();
        }
        this.subscriptions = [];
    }

    /* ========
     * COMMENTS
     * ======== */

    public subscribeToPostUpdates(): Observable<Post> {
        return this.subjectPostUpdates.asObservable();
    }

    getPost(postId: string, existingETagPost: Post): Observable<Post> {
        return this.postService.getPost(postId, existingETagPost.etag, existingETagPost);
    }

    addComment(post: Post, newTextComment: string): Observable<Comment> {
        return this.postService.addComment(post, newTextComment);
    }

    getOlderComments(post: Post): Observable<Array<Comment>> {
        return this.postService.getOlderComments(post);
    }

}
