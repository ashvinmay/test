import {Injectable, OnDestroy} from '@angular/core';
import {Observable} from "rxjs/Rx";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import {Subscription} from "rxjs/Subscription";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {CommunityCommon} from "../shared/community-common";
import {PostService} from "./post.service";
import {CommunityProfile} from "../pages/community-profile/community-profile.model";
import {CommunityProfileService} from "../pages/community-profile/community-profile.service";
import {Post} from "../models/post";
import {Like} from "../models/like.model";

@Injectable()
export class CommunityService implements OnDestroy {

    private logger: Logger;
    private maxPostsLimit: number = 200;
    private selectedProjectTypeId: number = -1;
    public posts: Array<Post> = [];
    private subjectPostsUpdates: BehaviorSubject<Array<Post>>;
    private subscriptions: Array<Subscription>;

    private oldestTopTimelineId: string;

    constructor(loggerFactory: LoggerFactory,
                private communityCommon: CommunityCommon,
                private postService: PostService,
                private communityProfileService: CommunityProfileService) {

        this.logger = loggerFactory.getLogger("CommunityService");
        this.init();
    }

    private init() {
        this.subscriptions = [];
        this.subjectPostsUpdates = new BehaviorSubject(this.posts);

        this.subscriptions.push(this.communityProfileService.subscribeToCommunityProfileUpdate()
            .subscribe((communityProfile: CommunityProfile) => {
                this.posts
                    .filter(post => {
                        return post.userIdStr == communityProfile.userIdStr;
                    })
                    .map((post: Post) => {
                      this.logger.debug("init posts mission !!! ", communityProfile.mission);
                        post.mission = Object.assign({}, communityProfile.mission);
                    });
                this.notifyPostsUpdated();
            }));
        this.subscriptions.push(this.postService.subscribeToDeletePost().subscribe(
            (post) => {
                let index = this.findIndex(post.postIdStr);
                if (index >= 0) {
                    this.posts.splice(index, 1);
                    this.notifyPostsUpdated();
                }
            }));
        this.subscriptions.push(this.postService.subscribeToAddPost().subscribe(
            (post) => {
                // Reload most recent posts
                this.fetchTopPosts(this.selectedProjectTypeId).subscribe();
                //this.fetchNewerPosts().subscribe();
            }));
        this.subscriptions.push(this.postService.subscribeToUpdatePost().subscribe(
            (post) => {
                // Find and replace the modified post
                let index = this.findIndex(post.postIdStr);
                if (index >= 0) {
                    this.posts[index] = post;
                    this.notifyPostsUpdated();
                }
            }));
    }

    ngOnDestroy() {
        // Prevent memory leak when component destroyed
        for (let subscription of this.subscriptions) {
            subscription.unsubscribe();
        }
        this.subscriptions = [];
        this.clear();
    }

    public clear() {
        this.posts = [];
    }

    public subscribeToPostsUpdates(): Observable<Array<Post>> {
        return this.subjectPostsUpdates.asObservable();
    }

    public fetchTopPosts(projectTypeId: number): Observable<boolean> {
        this.logger.debug('fetchTopPosts');
        this.logger.debug('Selected project type id for filtering :', projectTypeId);
        this.selectedProjectTypeId = projectTypeId;
        return this.postService.getCommunityTopPosts(projectTypeId)
            .map(posts => {
                if (projectTypeId > -1 && posts && posts.length == 0) {
                  this.posts = [];
                  this.subjectPostsUpdates.next([...this.posts]);
                  return true;
                }
                if (posts && posts.length > 0) {
                    this.updateTimelineForTopPosts(posts);
                    this.notifyPostsUpdated();
                    return true;
                }
                return false;
            });
    }

    public fetchOlderTopPosts(projectTypeId: number): Observable<boolean> {
        if (this.posts.length >= this.maxPostsLimit) {
            this.logger.warn("Max posts reached (" + this.maxPostsLimit + ")");
            let params = {max: this.maxPostsLimit};
            this.communityCommon.translateAndPresentToast("MAX_POSTS", params);
            return Observable.of(false); // Stop loading more
        }
        this.logger.debug("fetchOlderTopPosts");
        this.selectedProjectTypeId = projectTypeId;
        this.checkTimelineIds();
        return this.postService.getOlderCommunityTopPosts(this.oldestTopTimelineId, projectTypeId)
            .map(posts => {
                if (posts && posts.length > 0) {
                    this.updateTimelineForOlderPosts(posts);
                    this.notifyPostsUpdated();
                    return true;
                }
                return false; // Stop loading more
            });
    }

    private notifyPostsUpdated() {
        this.communityCommon.updateTimeSince(this.posts);
        this.subjectPostsUpdates.next([...this.posts]);
    }

    private findIndex(postIdStr): number {
        return this.posts.findIndex(element => {
            return element.postIdStr == postIdStr;
        });
    }

    private updateTimelineForTopPosts(posts: Array<Post>) {
        this.posts = posts;
        this.logger.debug("Current posts in list " + this.posts.length);
        this.updateTimelineIds();
    }

    private updateTimelineForOlderPosts(posts: Array<Post>) {
        this.posts = this.posts.concat(posts);
        this.logger.debug("Current posts in list " + this.posts.length);
        this.updateTimelineIds();
    }

    private updateTimelineIds() {
        if (this.posts && this.posts.length > 0) {
            this.oldestTopTimelineId = this.posts[this.posts.length - 1].topTimelineIdStr;
        }
    }

    private checkTimelineIds() {
        if (!this.posts || this.posts.length == 0) {
            this.logger.debug('No posts in cache. Resetting timelineIds!');
        }
    }

    fetchPostLikes(postId: string, likeId: string): Observable<Array<Like>> {
        this.logger.debug("fetchPostLikes");
        return this.postService.getPostLikes(postId, likeId);
    }

    fetchCommentLikes(postId: string, likeId: string, commentId: string): Observable<Array<Like>> {
        this.logger.debug("fetchCommentLikes");
        return this.postService.getCommentLikes(postId, likeId, commentId);
    }

}