import {Loading, LoadingController} from "ionic-angular";
import {TranslateService} from "@ngx-translate/core";
import {Injectable} from "@angular/core";

@Injectable()
export class LoadingUiService {

  loading: Loading;

  constructor(private loadingCtrl: LoadingController,
              private translateService: TranslateService) {
  }

  public showLoading() {
    this.loading = this.loadingCtrl.create({
      content: '<b>' + this.translateService.instant('LOADING') + '</b>'
    });
    this.loading.present();
  }

  public hideLoading(): void {
    // Dismiss loading
    this.loading.dismiss();
  }
}
