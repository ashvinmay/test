export class Comment {
    commentIdStr: string;
    postIdStr: string;
    userIdStr: string;
    moderated: boolean;
    userAvatar: string;
    userName: string;
    text: string;
    liked: boolean;
    likeCount: number;
    timeSince: string;
    date: Date;

    constructor(data?: any) {
        Object.assign(this, data);
    }
}