import {Comment} from "./comment";
import {DatePipe} from "@angular/common";
import {TranslateService} from "@ngx-translate/core";
import {ProjectType} from "./project-type.model";
import {EscLocation} from "../pages/community-profile/community-profile.model";

/**
 * @author morujca
 * @since 28/02/2017
 */
export class Post {
    postIdStr: string;
    userIdStr: string;
    timelineIdStr: string;
    topTimelineIdStr: string;
    visibility: string;
    name: string;
    title: string;
    description: string;
    mission: EscLocation;
    images: Array<string>;
    imagesStr: Array<string>;
    liked: boolean;
    likeCount: number;
    commentCount: number;
    comments?: Array<Comment>;
    date: any;
    timeSince: string;
    communityEvent: string;
    etag: string;
    projectType? : ProjectType;
    status?: string;

    constructor(data?: any) {
        Object.assign(this, data);
    }

    public get olderCommentId(): string {
        if (this.comments && this.comments.length > 0) {
            return this.comments[0].commentIdStr;
        }
        return "-1";
    }

    public get newerCommentId(): string {
        if (this.comments && this.comments.length > 0) {
            return this.comments[this.comments.length - 1].commentIdStr;
        }
        return "-1";
    }

    public get safeComments(): Array<Comment> {
        if (this.comments && this.comments.length > 0) {
            return this.comments;
        }
        return [];
    }

    public get latestComments(): Array<Comment> {
        if (this.safeComments.length > 0) {
            for (let i = this.safeComments.length - 1; i >= 0; i--) {
                if (!this.comments[i].moderated) {
                    return [this.comments[i]];
                }
            }
        }
        return [];
    }

    public get isRestricted() : boolean {
        return this.visibility == 'RESTRICTED'
    }

    public removeComment(commentId: string) {
        let index = this.findCommentIndex(commentId);
        if (index >= 0) {
            this.communityEvent = "COMMENT_DELETED";
            this.comments.splice(index, 1);
            this.commentCount--;
        }
    }

    public addComment(comment: Comment) {
        this.comments = [...this.safeComments, comment];
        this.commentCount++;
    }

    public addComments(comments: Array<Comment>) {
        this.comments = this.safeComments.concat(comments);
        this.commentCount += comments.length;
    }

    public insertComments(comments: Array<Comment>) {
        this.comments = comments.concat(this.safeComments);
    }

    public updateTimeSince(now: Date, datePipe: DatePipe, translate: TranslateService) {
        this.timeSince = Post.calculateTimeSince(new Date(this.date), now, datePipe, translate);
        this.safeComments.forEach(comment => {
            // TODO: avatarUrl from Server?
            comment.timeSince = Post.calculateTimeSince(new Date(comment.date), now, datePipe, translate);
        })
    }

    public static calculateTimeSince(date: any, now: any, datePipe: DatePipe, translate: TranslateService): string {
        let seconds = Math.floor((now - date) / 1000);
        let interval = Math.floor(seconds / 86400);
        if (interval >= 1) {
            return datePipe.transform(date, 'dd MMM yyyy');
        }
        interval = Math.floor(seconds / 3600);
        if (interval > 12) {
            return datePipe.transform(date, 'dd MMM yyyy');
        }
        if (interval >= 1) {
            let parameters = {hour: interval};
            let key = (interval == 1 ? "HOUR_AGO" : "HOURS_AGO");
            return translate.instant(key, parameters);
        }
        interval = Math.floor(seconds / 60);
        if (interval >= 1) {
            let parameters = {min: interval};
            let key = (interval == 1 ? "MIN_AGO" : "MINS_AGO");
            return translate.instant(key, parameters);
        }
        return translate.instant("JUST_NOW");
    }

    private findCommentIndex(commentId): number {
        return this.safeComments.findIndex(element => {
            return element.commentIdStr == commentId;
        });
    }

}
