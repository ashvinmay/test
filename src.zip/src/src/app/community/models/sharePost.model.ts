export class SharePost {
    shareUrl: string;
    shareId: string;

    constructor(data?: any) {
        Object.assign(this, data);
    }
}