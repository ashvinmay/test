export class Like {
    userIdStr: string;
    likeIdStr: string;
    name: string;
    likeDate: Date;
    visibilityCode: string;
    avatarId: string;
    timeSince: string;

    constructor(data?: any) {
        Object.assign(this, data);
    }
}