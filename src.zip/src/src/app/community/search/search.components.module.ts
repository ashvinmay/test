import {NgModule} from '@angular/core';
import {SearchResultComponent} from './search-result/search-result';
import {SearchResultListComponent} from "./search-result-list/search-result-list";
import {IonicModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {PipesModule} from "../../core/pipes/pipes.module";

@NgModule({
  imports: [
    IonicModule,
    TranslateModule.forChild(),
    PipesModule.forRoot()
  ],
  declarations: [SearchResultComponent, SearchResultListComponent],
	exports: [SearchResultListComponent, SearchResultComponent]
})
export class SearchComponentsModule {}
