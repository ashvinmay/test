import {Injectable} from "@angular/core";
import {SearchResult} from "./search.result.model";
import {EnvConfiguration} from "../../../env/env.configuration";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {EscHttp} from "../../core/http/esc-http";
import {Observable} from "rxjs/Rx";

interface UserSearchResult {
  results: Array<SearchResult>;
}

@Injectable()
export class SearchService {
  private logger: Logger;
  private pageSize = 10;

  constructor(private config: EnvConfiguration, loggerFactory: LoggerFactory,
              private escHttp: EscHttp) {
    this.logger = loggerFactory.getLogger("SearchService");


  }

  search(keyword:string): Observable<Array<SearchResult>> {
    this.logger.debug("search by keyword: ", keyword);
    this.escHttp.getJson(this.config.usersSearchUrl)
    let params = this.buildUserSearchParams(keyword, this.pageSize);
    return this.escHttp.getJson<UserSearchResult>(this.config.usersSearchUrl, params)
      .map(res => {
        this.logger.debug("search users Results: ", res);
        return this.mapPosts(res.results);
      });
  }


  /**
   * Allows to not overwrite the Post entity
   */
  private mapPosts(posts: any /*Array<SearchResultData>*/): Array<SearchResult> {
    return posts.map(
      (post) => {
        return new SearchResult(post, this.config);
      });
  }

  private buildUserSearchParams(keyword: string, pageSize: number) {
    let params = {"pageSize": pageSize };
    if (keyword) {
      params["key"] = keyword;
    }
    return params;
  }
}
