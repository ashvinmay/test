// import {inject, TestBed} from "@angular/core/testing";
// import {EnvConfiguration} from "../../env/env.configuration";
// import {MockSearchService} from "./mock-search.service";
//
// describe('SearchService tests', () => {
//
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [],
//       providers: [MockSearchService, EnvConfiguration]
//     });
//   })
//
//   it("loads mock data", inject([MockSearchService],(service: MockSearchService) => {
//     expect(service).toBeTruthy();
//     expect(service.items.length).toBeGreaterThan(0);
//   }));
//
//   it("finds keyword in userName", inject([MockSearchService],(service: MockSearchService) => {
//     expect(service).toBeTruthy();
//     //expect(service.items.length).toBeGreaterThan(0);
//
//     let keyword = "Je";
//     service.search(keyword).map(result =>{
//       expect(result.userName).toContain(keyword);
//     })
//   }));
//
// });
//
//
