import {Component} from "@angular/core";
import {IonicPage} from "ionic-angular";
import {SearchService} from "../search.service";
import {SearchResult} from "../search.result.model";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {Logger} from "../../../core/logger/logger";


@IonicPage()
@Component({
  selector:'page-search',
  templateUrl: 'search.html'
})
export class SearchPage {

  searchInput: string;
  results: Array<SearchResult>;
  logger: Logger;

  constructor(private searchService: SearchService, loggerFactory: LoggerFactory) {
      this.logger = loggerFactory.getLogger("SearchPage");
      this.results = [];
  }

  onInput(ev: any) {
    if(this.searchInput && this.searchInput.trim() !== '' && this.searchInput.trim().length > 1) {
      this.searchService.search(this.searchInput.trim()).subscribe( data => {
        this.logger.debug("results : ", data);
        this.results = data;
      });

    } else {
      this.results = new Array<SearchResult>();
    }
  }
}
