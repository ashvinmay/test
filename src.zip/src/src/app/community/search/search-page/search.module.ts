import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {SearchPage} from "./search";
import {TranslateModule} from "@ngx-translate/core";
import {SearchService} from "../search.service";
import {SearchComponentsModule} from "../search.components.module";
import {CommunityToolBarModule} from "../../components/community-tool-bar/community-tool-bar.module";


@NgModule({
    imports : [
        SearchComponentsModule,
        CommunityToolBarModule,
        IonicPageModule.forChild(SearchPage),
        TranslateModule.forChild()
    ],
    declarations :[
      SearchPage
    ],
    providers: [SearchService]

})
export class SearchPageModule {

}
