import {Component, Input} from '@angular/core';
import {SearchResult} from "../search.result.model";
import {NavController} from "ionic-angular";

@Component({
    selector: 'search-result-list',
    templateUrl: 'search-result-list.html'
})
export class SearchResultListComponent {

    @Input() list: Array<SearchResult>;

    constructor(public navCtrl: NavController) {
        this.list = [];
    }

    goToCommProfile(userId: string) {
        //if (!this.isUserProfilePage || this.profileUserId != userId) {
        this.navCtrl.push('CommunityProfilePage', {
            userId: userId
        });
        //}
    }

    public fetchOlderNotifications(loader) {
        console.log('Loading more search results...');
        //   this.notificationService.getOldNotifications()
        //     .finally(() => {
        //       if (loader) loader.complete();
        //     })
        //     .subscribe(
        //       (data) => {
        //         if (!data) {
        //           this.infinite = false;
        //         } else {
        //           this.infinite = true;
        //         }
        //       },
        //       (err) => {
        //         this.alertUtils.handleGetPostsError(err);
        //       });
    }
}