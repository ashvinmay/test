// import {SearchService} from "./search.service";
// import {Injectable} from "@angular/core";
// import {LoggerFactory} from "../../logger/logger-factory";
// import {Logger} from "../../logger/logger";
// import {SearchResult, SearchResultData} from "./search.result.model";
// import {EnvConfiguration} from "../../env/env.configuration";
// import {EscHttp} from "../../auth/esc-http";
//
// @Injectable()
// export class MockSearchService extends SearchService {
//
//   items: Array<SearchResult>; // mock data
//   private LOG: Logger;
//
//   constructor(config: EnvConfiguration, loggerFactory: LoggerFactory, escHttp: EscHttp) {
//     super(null, loggerFactory, escHttp);
//     this.LOG = loggerFactory.getLogger("MockSearchService");
//     this.items = [
//       {
//         userIdStr: "10600",
//         userName: "Jean GABIN",
//         originLocation: "Bruxelles, Belgium",
//         origin : {
//           city: "Brussels",
//           countrycode: "BE",
//         },
//         mission : {
//           city: "Paris",
//           countrycode: "FR",
//         },
//         postsNo: 30
//       },
//       {
//         userIdStr: "10800",
//         userName: "Jean GABIN-e",
//         originLocation: "Namur, Belgium",
//         missionLocation: "Athens, Greece",
//         postsNo: 20
//       },
//       {
//         userIdStr: "10602",
//         userName: "Jean no posts",
//         originLocation: "Namur, Belgium",
//         missionLocation: "Athens, Greece"
//       },
//       {
//         userIdStr: "10603",
//         userName: "Jean no origin",
//         //originLocation: "Namur, Belgium",
//         missionLocation: "Athens, Greece",
//         postsNo: 1
//       },
//       {
//         userIdStr: "10604",
//         userName: "Jean no mission",
//         originLocation: "Namur, Belgium",
//         //missionLocation: "Athens, Greece",
//         postsNo: 1
//       },
//       {
//         userIdStr: "10605",
//         userName: "Jean no mission, origin or posts"
//         //originLocation: "Namur, Belgium",
//         //missionLocation: "Athens, Greece",
//         //postsNo: 1
//       },
//       {
//         userIdStr: "10605",
//         userName: "Gabin no mission or posts",
//         originLocation: "Joué-lès-Tours, France"
//         //missionLocation: "Athens, Greece",
//         //postsNo: 1
//       }
//       /*,
//       {}*/
//     ].map(item => {
//       return new SearchResult(item as SearchResultData, config);
//     })
//   }
//
//   search(keyword: string): Array<SearchResult> {
//     return this.items.filter( item => {
//       let lcKeyword = keyword.toLowerCase();
//       return (item.userName && item.userName.toLowerCase().startsWith(lcKeyword))
//         || (item.originLocation &&  item.originLocation.toLowerCase().startsWith(lcKeyword))
//         || (item.missionLocation && item.missionLocation.toLowerCase().startsWith(lcKeyword))
//     });
//   }
// }
