/**
 * SearchResult is a Data transfer object (server model) that holds an individual
 * record from a members search
 */
import {EnvConfiguration} from "../../../env/env.configuration";

interface EscLocation {
  "city" : string,
  "countryCode" : string
}

export class SearchResultData {
  userId : number;
  userIdStr: string;
  firstName: string;
  lastName: string;
  //originLocation: string;
  //missionLocation: string;
  mission : EscLocation;
  origin: EscLocation;

  postCount: number;
}
/*

  "origin" : { },
  "userId" : 10600,
  "userIdStr" : "10600",
  "postCount" : 0,
  "mission" : {
  "city" : "Berlin",
  "countryCode" : "Germany"
},
"firstName" : "Martin",
  "lastName" : "PARASCHIV"
*/


export class SearchResult extends SearchResultData {
  userIdStr: string;
  firstName: string;
  lastName: string;
  mission : EscLocation;
  origin: EscLocation;

  postCount: number;
  avatarUrl: string;
  profileUrl: string;

  constructor(data: SearchResultData, config: EnvConfiguration) {
    super();
    Object.assign(this, data);
    this.avatarUrl = config.getAvatarUrl + this.userIdStr;
  }

  get userName(): string {
    return this.firstName + " " + this.lastName;
  }

  get originLocation(): string {
    if(!this.origin || !this.origin.city || !this.origin.countryCode) {
      return null;
    }
    return this.origin.city + ", " + this.origin.countryCode;
  }

  get missionLocation(): string {
    if(!this.mission || !this.mission.city || !this.mission.countryCode) {
      return null;
    }
    return this.mission.city + ", " + this.mission.countryCode;
  }
}
