import {Component, EventEmitter, Input, Output} from '@angular/core';
import {SearchResult} from "../search.result.model";

@Component({
    selector: 'search-result',
    templateUrl: 'search-result.html'
})
export class SearchResultComponent {

    @Input() result: SearchResult;
    @Output() openProfile: EventEmitter<{ userId: string }> = new EventEmitter();

    constructor() {
    }

    goToCommProfile(userId: string) {
        console.log("Go to User community profile... for user: ", userId);
        this.openProfile.emit({userId: userId});
    }

}