import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from "@angular/common/http";
import {Injectable} from "@angular/core";
import {Storage} from "@ionic/storage";
import {Observable} from "rxjs/Observable";
import {switchMap, tap} from "rxjs/operators";
import {Logger} from "../core/logger/logger";
import {LoggerFactory} from "../core/logger/logger-factory";

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  private logger: Logger;

    constructor(public storage: Storage, loggerFactory: LoggerFactory) {
      this.logger = loggerFactory.getLogger("TokenInterceptor");
    }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.logger.debug("intercept()", request);
        return Observable.fromPromise(this.storage.get("token")).pipe(
            tap(token => {
              this.logger.debug("Got token:", token);
            }),
            switchMap(token => {
                if (token) {
                    this.logger.debug("Got not null token:", token);
                    const newRequest = request.clone({
                        headers: request.headers.set("Authorization", `Bearer ${token}`)
                    });
                    return next.handle(newRequest);
                }
                this.logger.debug("Got NULL token");
                return next.handle(request);
            }
        )/*,
            catchError(error => {
                this.logger.error(stringify(error));
                //return next.handle(request);
              return this.httpErrorHandler.handleError(error);
            })*/
        );
    }
}
