import {Component, OnDestroy} from '@angular/core';
import {IonicPage, NavParams, ViewController} from 'ionic-angular';
import {Observable} from "rxjs/Observable";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";

@IonicPage()
@Component({
    selector: 'page-login-progress',
    templateUrl: 'login-progress.html',
})
export class LoginProgressPage implements OnDestroy {

    private content: string;
    private contentSubscription;
    private logger: Logger;

    constructor(private viewCtrl: ViewController,
                private navParams: NavParams,
                loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("LoginProgressPage");

        let provider: Observable<string> = this.navParams.get('contentProvider');
        this.contentSubscription = provider.subscribe((text) => {
            this.logger.debug("Received new content: " + text);
            this.content = text;
        });
    }

    ngOnDestroy() {
        if (this.contentSubscription) {
            this.contentSubscription.unsubscribe();
            this.contentSubscription = null;
        }
    }

    ionViewWillEnter() {
        this.logger.debug("Entering the modal ...");

    }

    ionViewDidLeave() {
        this.logger.debug("Leaving the modal ...");
    }

    closeModal() {
        this.viewCtrl.dismiss({}, 'cancel');
    }

    hasContent(): boolean {
        return this.content && this.content.trim().length > 0;
    }
}