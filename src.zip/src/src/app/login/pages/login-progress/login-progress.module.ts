import {NgModule} from '@angular/core';
import {TranslateModule} from "@ngx-translate/core";
import {IonicPageModule} from 'ionic-angular';
import {LoginProgressPage} from './login-progress';

@NgModule({
  declarations: [
    LoginProgressPage,
  ],
  imports: [
    IonicPageModule.forChild(LoginProgressPage),
    TranslateModule.forChild()
  ],
})
export class LoginProgressPageModule {}
