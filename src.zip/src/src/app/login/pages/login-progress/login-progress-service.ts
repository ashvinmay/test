import {Injectable} from "@angular/core";
import {Modal, ModalController} from "ionic-angular";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import {Subject} from "rxjs/Subject";

@Injectable()
export class LoginProgressService {

  constructor(private modalCtrl: ModalController) {
  }

  create() : LoginProgressModal {
    let contentProvider = new BehaviorSubject<String>(null);
    let dlg = this.modalCtrl.create('LoginProgressPage',
      {
        'contentProvider':contentProvider
      },
      {
      enableBackdropDismiss: false
    });
    return new LoginProgressModal(dlg, contentProvider);
  }
}

export class LoginProgressModal {
  constructor(private modal:Modal, private contentProvider : Subject<String>) {
  }

  present() : Promise<any> {
    return this.modal.present();
  }

  setContent(text : string) {
    this.contentProvider.next(text);
  }

  onDidDismiss(callback: (data: any, role: string) => void) {
    this.modal.onDidDismiss(callback);
  }

  dismiss(data? : any, role?: any) : Promise<any> {
    return this.modal.dismiss(data, role);
  }
}
