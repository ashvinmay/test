
import {NgModule} from "@angular/core";
import {EcasWebCallbackPage} from "./ecas-web-callback";
import {IonicPageModule} from "ionic-angular";

@NgModule({
    declarations : [
        EcasWebCallbackPage
    ],
    imports :[
        IonicPageModule.forChild(EcasWebCallbackPage)
    ],
    providers : [

    ]
})
export class EcasWebCallbackPageModule{

}