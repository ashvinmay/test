import {Component} from "@angular/core";
import {IonicPage, NavController, NavParams, ToastController} from "ionic-angular";
import {AuthService} from "../../services/auth.service";
import {Subscription} from "rxjs/Rx";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {Logger} from "../../../core/logger/logger";
import {HomePage} from "../../../pages/home/home";
import stringify from "fast-safe-stringify";
import {EnvConfiguration} from "../../../../env/env.configuration";

/**
 * Used when performing authentication via a desktop browser (during app development). Upon a successful ECAS authentication via the browser,
 * the user who has an ESC profile is to be redirected to this page by the server, while also receiving the generated token.
 * This component will retrieve the token from the URL and pass it to the app.
 */
@IonicPage({
    name: 'EcasWebCallback',
    segment: 'ecas-web-callback/:token'
})
@Component({
  selector: 'page-ecas-web-callback',
  templateUrl: 'ecas-web-callback.html'
})
export class EcasWebCallbackPage {

  private subscription : Subscription;
  private logger : Logger;

  constructor(public navCtrl: NavController, public navParams: NavParams,
              private toastCtrl: ToastController,
              private authService: AuthService,
              loggerFactory: LoggerFactory,
              private config: EnvConfiguration) {
    this.logger = loggerFactory.getLogger("EcasWebCallbackPage");
  }

  ionViewDidLoad() {
    let token = this.navParams.get("token");
    if (token) {
      this.logger.debug("got token: " + token.substr(0, 8) + "...");
      this.subscription = this.authService.authenticateWithToken(token, this.config.apiBaseUrl + "/api/v1/user")
        .subscribe(
          (userDetails) => {
            this.logger.debug("user successfully logged on! User details: " + stringify(userDetails));
            if (userDetails.termsAccepted) {
              this.navCtrl.setRoot(HomePage);
            } else {
              this.navCtrl.setRoot('TermsConditionsPage');
            }
          },
          (err) => {
            // need to handle any communication error that can occur while the AuthServices retrieves extra user data from server
            this.showAuthError(err);
          }
        );
    }
  }

  ionViewWillUnload() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  private showAuthError(err) {
    if (err.status || err.status === 403) {
      // when status is 403 it means user has NO ESC profile
      this.navCtrl.setRoot('JoinTheCorpsPage');
      return;
    }

    let toast = this.toastCtrl.create({
      message: "Could not login! Details:\n" + stringify(err),
      duration: 7000,
      position: 'middle',
      showCloseButton: true
    });
    toast.present();
  }
}
