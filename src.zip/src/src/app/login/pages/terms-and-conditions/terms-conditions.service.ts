import {Injectable} from "@angular/core";
import {Observable} from "rxjs/Rx";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {Logger} from "../../../core/logger/logger";
import {EscHttp} from "../../../core/http/esc-http";
import {UserService} from "../../services/user.service";
import {UserDetails} from "../../user.details";
import {EnvConfiguration} from "../../../../env/env.configuration";

@Injectable()
export class TermsConditionsService {
    private logger: Logger;

    private _userDetails: UserDetails;

    constructor(loggerFactory: LoggerFactory,
                private escHttp: EscHttp,
                private config: EnvConfiguration,
                private userService: UserService) {

        this.logger = loggerFactory.getLogger("TermsConditionService");
    }

    storeTermsAndConditionsFlag(): Observable<boolean> {
        return this.storeFlag();
    }

    public loadTermsAndConditions(): Observable<any> {
        this.logger.debug("Loading TermsAndCondition");
        let url = this.config.termsConditionUrl;
        return this.escHttp.getJson(url);
    }

    private storeFlag(): Observable<boolean> {
        this.logger.debug("Storing termsAccepted flag ...");
        let url = this.config.termsAcceptedUrl;
        return this.escHttp.postJson(url)
            .flatMap(() => this.userService.getUserDetails())
            .map((userDetails) => {
                this._userDetails = userDetails;
                this._userDetails.termsAccepted = true;
                return this._userDetails
            })
            .flatMap((userDetails) => {
                return this.userService.updateUserDetails(this._userDetails);
            })
            .do(() => this.logger.debug("Flag was successfully stored..."))
            .map(() => true);
    }
}

export enum TermsConditionsStatus {
    CHECKED,
    NOT_CHECKED
}
