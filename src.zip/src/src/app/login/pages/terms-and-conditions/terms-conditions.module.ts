import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {TermsConditionsPage} from "./terms-conditions";

@NgModule({
    declarations : [
        TermsConditionsPage
    ],
    imports : [
        IonicPageModule.forChild(TermsConditionsPage),
        TranslateModule.forChild()
    ]
})
export class TermsConditionsPageModule {}