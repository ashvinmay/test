import {Component, ElementRef} from "@angular/core";
import {IonicPage, NavController, NavParams} from "ionic-angular";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {Logger} from "../../../core/logger/logger";
import {TermsConditionsService} from "./terms-conditions.service";
import {HomePage} from "../../../pages/home/home";
import {UserService} from "../../services/user.service";
import {Subscription} from "rxjs/Subscription";
import {stringify} from "querystring";
import {BrowserService} from "../../../core/browser-service";
import {HttpClient} from "@angular/common/http";

@IonicPage()
@Component({
    selector: 'page-terms-conditions',
    templateUrl: 'terms-conditions.html'
})
export class TermsConditionsPage {

    private logger: Logger;
    public termsAndConditions: any;
    private currentLanguage: string;
    private userSubscription: Subscription;

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                private http: HttpClient,
                loggerFactory: LoggerFactory,
                private userService: UserService,
                private termsConditionsService: TermsConditionsService,
                private elRef:ElementRef, private browserService: BrowserService
                ) {

        this.logger = loggerFactory.getLogger("TermsConditionsPage");
    }

    ionViewWillEnter() {
        this.userSubscription = this.userService.getUserDetails().subscribe(userDetails => {
            if (this.currentLanguage != userDetails.locale) {
                this.termsConditionsService.loadTermsAndConditions().subscribe(
                    (terms) => {
                        // As Html
                        this.termsAndConditions = terms._body;
                        this.fixLinks();
                    },
                    (error) => {
                        this.logger.error("Error loading TermsAndConditions in " + userDetails.locale + "! Error: " + stringify(error));
                        this.loadTermsLocally();
                    });
            } else if (!this.currentLanguage) {
                this.loadTermsLocally();
            } // else, it is already loaded in the correct language
        });
    }

    ionViewWillLeave() {
        if (this.userSubscription) this.userSubscription.unsubscribe();
    }

    termsAccepted(): void {
        this.termsConditionsService.storeTermsAndConditionsFlag().subscribe(flag => {
            this.navCtrl.setRoot(HomePage);
        });
    }



    private loadTermsLocally(): void {
        this.http.get('assets/termsConditions.html')
            .subscribe((res: Response) => {
                this.termsAndConditions = res.text();
                this.fixLinks();
            });
    }

    private fixLinks() {
      setTimeout(()=> {
        this.browserService.fixLinks(this.elRef.nativeElement);
      }, 100);
    }
}
