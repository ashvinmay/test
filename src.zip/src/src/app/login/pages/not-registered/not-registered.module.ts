import {NgModule} from "@angular/core";
import {TranslateModule} from "@ngx-translate/core";
import {IonicPageModule} from "ionic-angular";
import {LoginProgressService} from "../login-progress/login-progress-service";
import {NotRegisteredPage} from "./not-registered";

@NgModule({
    declarations :[
        NotRegisteredPage
    ],
    imports : [
        IonicPageModule.forChild(NotRegisteredPage),
        TranslateModule.forChild()
    ],
    providers: [
      LoginProgressService
    ]
})
export class NotRegisteredPageModule{}
