import {Component} from "@angular/core";
import {TranslateService} from "@ngx-translate/core";
import stringify from "fast-safe-stringify";
import {
    IonicPage, MenuController, NavController, NavParams, Platform, ToastController
} from "ionic-angular";
import {Subscription} from "rxjs/Rx";
import {ErrorReporterService} from "../../../core/error-reporter/error-reporter.service";
import {BrowserService} from "../../../core/browser-service";
import {EnvConfiguration} from "../../../../env/env.configuration";
import {HomePage} from "../../../pages/home/home";
import {Logger} from "../../../core/logger/logger";
import {LoggerFactory} from "../../../core/logger/logger-factory";
import {AuthEvent, AuthEventType, UserWebViewLoginSession} from "../../auth.models";
import {AuthService} from "../../services/auth.service";
import {LoginProgressModal, LoginProgressService} from "../login-progress/login-progress-service";
import {UserDetails} from "../../user.details";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-not-registered',
    templateUrl: 'not-registered.html'
})
export class NotRegisteredPage {

    private logger: Logger;

    private subscriptions: Array<Subscription> = [];
    logo_image: string = "assets/logo/esc-logo-en.png";

    constructor(public navCtrl: NavController, public navParams: NavParams,
                private platform: Platform,
                private auth: AuthService,
                private toastCtrl: ToastController,
                private statusBar: StatusBar,
                private loginProgressService: LoginProgressService,
                private config: EnvConfiguration,
                private browserService: BrowserService,
                private translate: TranslateService,
                private menu: MenuController,
                private errorReporterService: ErrorReporterService,
                loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("NotRegisteredPage");
    }

    ionViewDidLoad() {
        // The menu should be disabled on the pages
        this.menu.enable(true);
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.overlaysWebView(false); // For Ios
        this.statusBar.backgroundColorByHexString('#154194');
        this.statusBar.styleLightContent();
        // Logo changes on language change
        this.logo_image = "assets/logo/esc-logo-" + this.translate.currentLang + ".png";
    }

    ionViewWillUnload() {
        // Free any allocated resources
        this.unsubscribeAll();
    }

    gotToESCSite() {
        // Redirect user to ESC Site
        this.browserService.openUrl("https://europa.eu/youth/solidarity");
    }

    signInWithEULogin() {
        //this.testLoginProgress();
        let subscription = this.auth.isEcasPluginAvailable().subscribe(
            () => {
                this.authenticateViaWebView(this.config);
            },
            () => {
                if (this.platform.is('cordova')) {
                    this.showEcasPluginNotAvailableError();
                } else {
                    this.triggerWebAuthentication(this.config);
                }
            }
        );
        this.subscriptions.push(subscription);
    }

    /* private testLoginProgress() {
       let loading = this.loginProgressService.create();
       loading.present();

       let counter = 0;
       setInterval(() => {
         counter++;
         loading.setContent("Updated to " + counter);
       }, 2000);
     }
   */
    private unsubscribeAll() {
        for (let subscription of this.subscriptions) {
            subscription.unsubscribe();
        }
        this.subscriptions = [];
    }

    private showEcasPluginNotAvailableError() {
        this.displayToastForError("ECAS plugin is not installed so login cannot be performed!");
    }

    private triggerWebAuthentication(config: EnvConfiguration) {
        let redirectURL = config.authRedirectPath;
        let serverBaseUrl = config.authRemoteServerUrl;
        this.auth.triggerWebAuthentication(serverBaseUrl, redirectURL, config.healthUrl)
            .subscribe(() => {
                    // ok
                },
                (err) => this.showAuthError(err));
    }

    private authenticateViaWebView(config: EnvConfiguration) {
        let loginSession = this.auth.authenticateViaWebView(config.authGetToken4TicketUrl, config.healthUrl);

        if (this.config.fakeLogin) {
            loginSession = this.auth.fakeLoginAuthentication(config.fakeAuthGetToken4TicketUrl, config.healthUrl);
        } else {
            loginSession = this.auth.authenticateViaWebView(config.authGetToken4TicketUrl, config.healthUrl);
        }

        this.registerForLoginProgress(loginSession);
        let subscription = loginSession.getUserDetails()
            .subscribe((result: UserDetails) => {
                this.logger.debug("[" + loginSession.id + "] Got user data: " + stringify(result))
                if (result.termsAccepted) {
                    this.navCtrl.setRoot(HomePage);
                } else {
                    this.navCtrl.setRoot('TermsConditionsPage');
                }
            }, (err) => {
                this.logger.debug("[" + loginSession.id + "] Received error during authentication: " + stringify(err));

                if (!err.code ||
                    !(err.code == AuthService.AUTHENTICATION_CANCELLED_CODE ||
                        err.code == AuthService.NO_ESC_USER_PROFILE_CODE)) {
                    this.reportLoginError(err);
                }


                if (!err.code || err.code !== AuthService.AUTHENTICATION_CANCELLED_CODE) {
                    this.showAuthError(err);
                    return;
                }
                // NOTE: user has canceled the authentication so there is nothing to do
            });
        this.subscriptions.push(subscription);
    }

    private reportLoginError(error: any) {
        try {
            this.errorReporterService.reportError('User could not login', stringify(error));
        } catch (exception) {
            this.logger.warn("Could not report login error: " + error + "! Details:" + stringify(exception));
        }
    }

    private registerForLoginProgress(loginSession: UserWebViewLoginSession) {
        var loading: LoginProgressModal;

        function dismissLoading() {
            if (loading != null) {
                loading.dismiss();
                loading = null;
            }
        }

        let logPrefix = "[" + loginSession.id + "] ";

        // NOTE: Need to ensure that registration for these event is not done twice, in order to avoid receiving the same event
        // multiple times (alternatively could use distinctUntilChanged)
        let subscription = loginSession.getAuthEvents()
            .finally(() => {
                dismissLoading();
            })
            .do((authEvent) => {
                this.logger.debug(logPrefix + "Received AuthEvent: " + stringify(authEvent));
            })
            .subscribe((event: AuthEvent) => {
                if (event.eventType == AuthEventType.LOGIN_IN_PROGRESS) {
                    this.logger.debug(logPrefix + "Received LoginInProgress with eventData: " + stringify(event.eventData));
                    let msg = this.buildMsgForProgress(event);
                    if (loading) {
                        loading.setContent(msg);
                    } else {
                        loading = this.loginProgressService.create();
                        loading.setContent(msg);
                        loading.onDidDismiss((data, role) => {
                            loading = null;
                            if (role && role === 'cancel') {
                                this.logger.info(logPrefix + "User has canceled the login progress dialog!");
                                this.unsubscribeAll();
                            }
                        });
                        loading.present();
                    }
                } else {
                    dismissLoading();
                }
            }, (err) => {
                dismissLoading();
            });
        this.subscriptions.push(subscription);
    }

    private buildMsgForProgress(event: AuthEvent) {
        let waitMsg = this.translate.instant('PLEASE_WAIT');
        return `${event.eventData && event.eventData.progress ? event.eventData.progress + ' ' : ''}${waitMsg}`;
    }

    private showAuthError(err) {
        if (err.status && err.status === 403) {
            // When status is 403 it means user has NO ESC profile
            this.navCtrl.setRoot('JoinTheCorpsPage');
            return;
        }
        this.displayToastForError(err.message);
    }

    private displayToastForError(message: string) {
        let toast = this.toastCtrl.create({
            message: message,
            duration: 7000,
            showCloseButton: true,
            position: 'bottom',
            cssClass: 'esc-toast-error'
        });
        toast.present();
    }

}