import {Component} from "@angular/core";
import {BrowserService} from "../../../core/browser-service";
import {IonicPage, Platform} from "ionic-angular";
import {StatusBar} from "@ionic-native/status-bar";

/**
 * Used when performing authentication via a desktop browser (during app development).
 * Upon a successful ECAS authentication via the browser, the user, who DOES NOT have an ESC profile,
 * is to be redirected to this page by the server.
 * This component is to allow the user to join the CORPs via a provided link.
 */
@IonicPage()
@Component({
    selector: 'page-join-the-corps',
    templateUrl: 'join-the-corps.html'
})
export class JoinTheCorpsPage {

    constructor(private browserService: BrowserService,
                private statusBar: StatusBar,
                public platform: Platform) {
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.overlaysWebView(false); // For Ios
        this.statusBar.styleDefault();
        if (this.platform.is("ios")) {
            this.statusBar.backgroundColorByHexString('#f8f8f8');
        } else if (this.platform.versions().num < 6) {
            this.statusBar.backgroundColorByHexString('#b0b0b0');
        } else {
            this.statusBar.backgroundColorByHexString('#f8f8f8');
        }
    }

    gotToESCSite() {
        // Redirect user to ESC Site
        this.browserService.openUrl("https://europa.eu/youth/solidarity");
    }

}