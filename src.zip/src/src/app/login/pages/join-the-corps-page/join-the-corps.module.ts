import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {NgModule} from "@angular/core";
import {JoinTheCorpsPage} from "./join-the-corps";

@NgModule({
    declarations :[
        JoinTheCorpsPage
    ],
    imports : [
        IonicPageModule.forChild(JoinTheCorpsPage),
        TranslateModule.forChild(),
    ]
})
export class JoinTheCorpsPageModule{}