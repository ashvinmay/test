import {Component} from "@angular/core";
import {IonicPage, NavController, NavParams} from "ionic-angular";
import stringify from "fast-safe-stringify";
import {Logger} from "../../../core/logger/logger";
import {AuthService} from "../../services/auth.service";
import {LoggerFactory} from "../../../core/logger/logger-factory";

@IonicPage()
@Component({
    selector: 'page-logout',
    templateUrl: 'logout.html'
})
export class LogoutPage {

    error: string;
    private logger: Logger;

    constructor(public navCtrl: NavController, public navParams: NavParams, private auth: AuthService, loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("LogoutPage");
    }

    ionViewDidLoad() {
        this.logger.debug('ionViewDidLoad');
        this.auth.logout().subscribe(() => {
                this.navCtrl.setRoot('NotRegisteredPage');
            },
            (err) => {
                this.logger.error("Could not perform logout! Details: " + stringify(err));
                this.error = "Error while trying to logout ...";
            });
    }

}