import {NgModule} from "@angular/core";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";
import {LogoutPage} from "./logout";

@NgModule({
    declarations : [
        LogoutPage
    ],
    imports : [
        IonicPageModule.forChild(LogoutPage),
        TranslateModule.forChild()
    ]
})
export class LogoutPageModule {}