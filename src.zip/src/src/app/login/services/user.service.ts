import {Injectable} from "@angular/core";
import {Storage} from "@ionic/storage";
import {Observable, ReplaySubject} from "rxjs/Rx";
import "rxjs/add/operator/map";
import {UserDetails} from "../user.details";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";


@Injectable()
export class UserService {

    private logger: Logger;

    /**
     * Keys for the UserDetailed object stored locally.
     */
    private static USER_DETAILS_KEY: string = "user";

    private userDetailsStream: ReplaySubject<UserDetails> = new ReplaySubject<UserDetails>(1);

    constructor(private storage: Storage, private loggerFactory: LoggerFactory) {
        this.logger = this.loggerFactory.getLogger("UserService");

        let getUserDetailsInt = (): Promise<UserDetails> => {
            return this.storage.get(UserService.USER_DETAILS_KEY);
        };

        this.storage.ready().then(() => {
            return getUserDetailsInt();
        }).then((userDetails) => {
            if (userDetails) {
                this.logger.debug("Loaded initial value for UserDetails");
                this.userDetailsStream.next(userDetails);
            } else {
                this.logger.debug("No initial value for UserDetails");
            }
        });
    }

    setUserDetails(userDetails: UserDetails): Promise<any> {
        return this.storage.set(UserService.USER_DETAILS_KEY, userDetails)
            .then(() => {
                this.logger.debug("User details successfully persisted");
                this.userDetailsStream.next(userDetails);
                return {
                    result: true
                };
            });
    }

    clearUserDetails() {
        return this.storage.remove(UserService.USER_DETAILS_KEY);
    }

    getUserDetails(): Observable<UserDetails> {
        return this.userDetailsStream.take(1);
    }

    getUserDetailsUpdates(): Observable<UserDetails> {
      return this.userDetailsStream;
    }

    updateUserDetails(userDetails: UserDetails): Observable<UserDetails> {
        let newUserDetails = Object.assign({}, userDetails);
        return Observable.fromPromise(this.setUserDetails(newUserDetails))
    }

}
