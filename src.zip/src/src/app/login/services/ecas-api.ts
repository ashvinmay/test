import {Injectable} from "@angular/core";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {Observable} from "rxjs/Rx";
import stringify from "fast-safe-stringify";

const defaultConfig:EcasApiConfig = {
  timeoutWhenGettingDPT: 10000, // timeout interval in millis
  retryDelayWhenGettingDPT: 200, // time in millis to wait between retries,
  maxRetryCount : 4 // 10sec * 4 = max 40sec to wait
};

/**
 * Wrapper on top of ECAS plugin that provides 'Observable' on top of existing API. Also, when retrieving the DPT it supports a configurable retry functionality.
 */
@Injectable()
export class EcasApi {

  private logger: Logger;

  private config:EcasApiConfig;

  /**
   * Code returned in EcasError instance when user cancels the authentication process via the ECAS plugin.
   * @type {string}
   */
  public static AUTHENTICATION_CANCELLED_CODE:string = 'AUTHENTICATION_CANCELLED';

  /**
   * Code returned in EcasError when plugin is not installed.
   * @type {string}
   */
  public static ECAS_PLUGIN_NOT_INSTALLED_CODE:string = 'ECAS_PLUGIN_NOT_INSTALLED';

  /**
   * Code returned in EcasError when a generic error occurs while calling plugin functions.
   * @type {string}
   */
  public static GENERIC_ERROR_CODE:string = 'GENERIC_ERROR';

  constructor(config:EcasApiConfig, loggerFactory: LoggerFactory) {
    this.logger = loggerFactory.getLogger("EcasApi");
    if (!config) {
      config = {};
    }
    this.config = {...defaultConfig, ...config};
  }

  /**
   * Check if ECAS plugin is installed.
   * @returns {Observable<boolean>} An Observable with 'true' if the plugin exists, or an EcasError if not installed.
   */
  isEcasPluginAvailable(): Observable<boolean> {
    if (this.ecasPlugin() !== undefined && this.ecasPlugin() !== null) {
      //this.logger.debug("ECAS plugin available ...");
      return Observable.of(true);
    }

    this.logger.warn("ECAS plugin is NOT available ...");
    return Observable.throw(new EcasError("ECAS plugin is NOT available ...", EcasApi.ECAS_PLUGIN_NOT_INSTALLED_CODE));
  }

  /**
   * Request authentication using the web view.
   * @param {string} sessionId Optionally specify a sessionId to be used for logging purposes.
   *
   * @returns {Observable<EULoginWithDPGT>} An observable with an instance of 'EULoginWithDPGT'
   *  when authentication succeeds, otherwise an 'EcasError' instance.
   */
  requestAuthenticationViaWebView(sessionId?:string) : Observable<EULoginWithDPGT> {
    let logPrefix = this.createLogPrefix(sessionId);
    this.logger.info("Performing web view authentication ...")

    return new Observable<EULoginWithDPGT>(observer => {

      this.ecasPlugin().requestECASAuthentication(($json) => {
        this.logger.info(logPrefix + "ECAS web authentication has succeeded! Details: " + stringify($json));
        observer.next(new EULoginWithDPGT($json.data));
        observer.complete();
      }, ($err) => {
        let msg = "ECAS Plugin web view authentication failed! Details: " + stringify($err);
        this.logger.warn(logPrefix + msg);
        if ($err.error && $err.error === EcasApi.AUTHENTICATION_CANCELLED_CODE) {
          observer.error(new EcasError("User has cancelled the authentication", EcasApi.AUTHENTICATION_CANCELLED_CODE, stringify($err)));
        } else {
          observer.error(new EcasError(msg, EcasApi.GENERIC_ERROR_CODE, stringify($err)));
        }
      });

    });
  }

  /**
   * Request a DPT after having obtained a DGPT for a user.
   *
   * @param {string} dgpt The previously obtained DGPT.
   * @param {string} sessionId Optionally specify a sessionId to be used for logging purposes.
   *
   * @returns {Observable<string>} An observable
   */
  requestDesktopProxyTicket(dgpt: string, sessionId?:string): Observable<string> {
    let logPrefix = this.createLogPrefix(sessionId);

    return this.createDynamicLogPrefixObservable(sessionId)
      .flatMap(dynamicLogPrefix => this.createGetDesktopTicketObservable(dgpt, dynamicLogPrefix))
      .timeout(this.config.timeoutWhenGettingDPT)
      .retryWhen(error => {
        return error
          .scan((errorCount, err) => {
            if (errorCount >= this.config.maxRetryCount) {
              this.logger.warn(logPrefix + "Max error count " + this.config.maxRetryCount + " was reached!. Giving up ...");
              const newErr = new EcasError(logPrefix + "Could not get DPT after " + this.config.maxRetryCount + " retries! Giving up ...",
                EcasApi.GENERIC_ERROR_CODE, stringify(err));
              throw newErr;
            }
            this.logger.info(logPrefix + "Error count is: " + errorCount +
              ". Scheduling retry in " + this.config.retryDelayWhenGettingDPT + "ms");
            return errorCount + 1;
          }, 0)
          .delay(this.config.retryDelayWhenGettingDPT);
      });
  }

  private createDynamicLogPrefixObservable(sessionId?:string) : Observable<string>{
    let counter = 1;
    return new Observable<string>(observer => {
      let logPrefix = this.createComposedLogPrefix('' + counter, sessionId);
      counter++;
      observer.next(logPrefix);
      observer.complete();
    });
  }

  private createLogPrefix(sessionId?: string) {
    return `${sessionId ? '[' + sessionId + '] ' : ''}`;
  }

  private createComposedLogPrefix(fixedId:string, optionalId?: string) {
    return `${optionalId ? '[' + optionalId + '#' + fixedId + '] ' : '#' + fixedId}`;
  }

  private createGetDesktopTicketObservable(dgpt:String, logPrefix:string) {
    return new Observable<string>(observer => {
      this.logger.debug(logPrefix + "Getting user desktop ticket for DGPT: " + dgpt);
      this.ecasPlugin().requestDesktopProxyTicket(dgpt, "http://escmobile/services",
        ($json) => {
          this.logger.info(logPrefix + "Got desktop ticket! Details: " + stringify($json));
          let dpt = $json.data['cas:proxyTicket'];
          observer.next(dpt);
          observer.complete();
        },
        ($json) => {
          let msg = "Could not get desktop ticket! Details: " + stringify($json);
          this.logger.warn(logPrefix + msg);
          observer.error(new EcasError(msg, EcasApi.GENERIC_ERROR_CODE));
        }
      );
    });
  }

  private ecasPlugin() {
    return window['ECASMobile'];
  }
}

/**
 * Object to keep the user data returned by the ECAS plugin.
 */
export class EULoginUser {
  firstName: string;
  lastName: string;
  locale: string;

  constructor(ecasData: any) {
    this.firstName = ecasData['cas:firstName'];
    this.lastName = ecasData['cas:lastName'];
    this.locale = ecasData['cas:locale'];
  }
}

/**
 * Object to keep the main user data returned by the ECAS plugin and the DGPT (desktop granting proxy ticket).
 */
export class EULoginWithDPGT {
  user: EULoginUser;
  dpgt: string;

  constructor(ecasData: any) {
    this.user = new EULoginUser(ecasData);
    this.dpgt = ecasData['cas:proxyGrantingTicket'];
  }
}


/**
 * Class of errors throw by the returned Observable to signal error conditions.
 */
export class EcasError {
  constructor(public message: string, public code: string, details?:string) {
  }
}

/**
 * Configuration class for ECAS API.
 */
export class EcasApiConfig {
  timeoutWhenGettingDPT?:number;
  retryDelayWhenGettingDPT?:number;
  maxRetryCount?: number;
}
