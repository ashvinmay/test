import {Injectable} from "@angular/core";
import stringify from "fast-safe-stringify";
import {Observable} from "rxjs/Observable";
import {catchError, mergeMap} from "rxjs/operators";
import {EnvConfiguration} from "../../../env/env.configuration";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {EscHttp} from "../../core/http/esc-http";
import {DefaultUserDetails, UserDetails} from "../user.details";
import {UserService} from "./user.service";

@Injectable()
export class UserUpdateService {

    private logger: Logger;
    private _userDetails: UserDetails;

    constructor(loggerFactory : LoggerFactory, private authHttp: EscHttp,
                private config: EnvConfiguration, private userService: UserService) {
        this.logger = loggerFactory.getLogger("User update service");
    }

    updateUserLanguage(code : string): Observable<boolean> {
        return this.updateLanguage(code);
    }

  refreshUser(): Observable<boolean> {
    this.logger.debug("Refresh user details ...");
    let url =this.config.apiBaseUrl + "/api/v1/user";
    return this.authHttp.getJson<DefaultUserDetails>(url)
      .pipe(
        // map(data => new DefaultUserDetails(data)),
        mergeMap(userDetails => {
           this.logger.debug("refresh user details ", userDetails)
           return this.userService.setUserDetails(new DefaultUserDetails(userDetails));

        }) ,
    catchError((err) => this.updateUserFailed(err))
  );
  }

    private updateLanguage(code:string): Observable<boolean> {
        this.logger.debug("Updating language ...");
        let url = this.config.updateLangUrl + code;
        return this.authHttp.postJson(url)
            .flatMap(() => this.userService.getUserDetails())
            .map((userDetails) => {
                this._userDetails = userDetails;
                this._userDetails.locale = code;
                return this._userDetails
            })
            .flatMap((userDetails) => {
              // change ui language
              return this.userService.updateUserDetails(this._userDetails);
            })
            .do(() => this.logger.debug("Language is successfully updated..."))
            .map(() => true);
    }

    private updateUserFailed(err: any): Observable<any> {
        this.logger.debug("updateUserFailed(" + stringify(err) + ")");
        return Observable.throw(err);
    }
}
