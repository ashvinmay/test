import {HttpClient, HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import {Injectable, NgZone} from "@angular/core";
import {Storage} from "@ionic/storage";
import {TranslateService} from "@ngx-translate/core";
import stringify from "fast-safe-stringify";
import {catchError, map, mergeMap} from "rxjs/operators";
import {BehaviorSubject, Observable, Subject} from "rxjs/Rx";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {
  AuthenticationStatus, AuthError, AuthEvent, AuthEventType, UserWebViewLoginSession
} from "../auth.models";
import {EcasApi, EcasError, EULoginUser, EULoginWithDPGT} from "./ecas-api";
import {DefaultUserDetails, UserDetails} from "../user.details";
import {UserService} from "./user.service";

// default timeout for HTTP connections performed by AuthService, expressed in milliseconds
const DEFAULT_HTTP_TIMEOUT : number = 20 * 1000; // 20 seconds

// XXX morujca - delay to allow progress dialog to be visible before moving to next step
const EXTRA_DELAY_AUTH_VIA_WEB_VIEW : number = 500; // in milliseconds

@Injectable()
export class AuthService {

  private logger: Logger;

  /**
   * Keys for the JWT token stored locally.
   */
  private static TOKEN_KEY: string = "token";

  /**
   * Code returned in AuthError instance when  user has no ESC profile.
   * @type {string}
   */
  public static NO_ESC_USER_PROFILE_CODE:string = 'NO_ESC_USER_PROFILE';

  /**
   * Code returned in AuthError instance when user cancels the authentication process via the ECAS plugin.
   * @type {string}
   */
  public static AUTHENTICATION_CANCELLED_CODE:string = 'AUTHENTICATION_CANCELLED';

  /**
   * Code returned in AuthError when a more specific error code cannot be provided.
   */
  public static GENERIC_ERROR_CODE:string = 'AUTHENTICATION_GENERIC_ERROR';

  /**
   * Code returned in AuthError when one of the HTTP calls times out during the authentication .
   */
  public static HTTP_TIMEOUT_CODE:string = 'AUTHENTICATION_HTTP_TIMEOUT_ERROR';

  /**
   * Stream that will emit an event everytime the authentication status changes.
   */
  private statusStream: BehaviorSubject<AuthenticationStatus>;

  private httpTimeoutInMs : number = DEFAULT_HTTP_TIMEOUT;

  constructor(private storage: Storage, private http: HttpClient, private userService : UserService, loggerFactory: LoggerFactory,
              private translateService : TranslateService, private ecasApi:EcasApi, private ngZone : NgZone) {
    this.logger = loggerFactory.getLogger("AuthService");
    this.statusStream = new BehaviorSubject(null);
  }

  /**
   * Set timeout for HTTP connections performed by current service to check if remote server is app and
   * for downloading user profile.
   */
  set httpTimeout(httpTimeoutInMs : number) {
    this.httpTimeoutInMs = httpTimeoutInMs;
  }

  /**
   * This is called by APP_INITIALIZER Token
   * @returns {Promise<any>}
   */
  onAppInit(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.isAuthenticated()
        .subscribe((result) => {
            let status:AuthenticationStatus = result ? AuthenticationStatus.AUTHENTICATED : AuthenticationStatus.NOT_AUTHENTICATED;
            this.logger.info("Initialized ...", status.toLocaleString())
            this.runInsideAngularZone(() => {
              this.statusStream.next(status);
              resolve(true);
            });
          },
          (err) => {
            this.logger.error("Could not initialize service: " + this.stringifySafe(err));
            this.runInsideAngularZone(() => {
              reject(err);
            });
          }
        );
    });
  }

  /**
   * @return {AuthenticationStatus}
   */
  getAuthenticationStatus(): Observable<AuthenticationStatus> {
    return this.statusStream.distinctUntilChanged();
  }

  /**
   * Check whether the user is logged in or not.
   *
   * @return {Observable<boolean>}
   */
  isAuthenticated(): Observable<boolean> {
    return this.getToken()
      .map((value) => {
        if (null != value) {
          return true;
        }
        return false;
      });
  }

  /**
   * Get the raw auth token of the active user if logged on. The token can be expired.
   *
   * @return {Observable<string>}
   */
  public getToken(): Observable<string> {
    let getTokenInt = () : Promise<string> => {
      return this.storage.get(AuthService.TOKEN_KEY);
    };

    return Observable.fromPromise(
      this.storage.ready().then(() => {
        return getTokenInt();
      }));
  }

  /**
   * Get the raw auth token of the active user if logged on. The token can be expired.
   *
   * @return {Promise<string>}
   */
  public getTokenAsPromise(): Promise<string> {
    let getTokenInt = () : Promise<string> => {
      return this.storage.get(AuthService.TOKEN_KEY);
    };

    return this.storage.ready().then(() => {
      return getTokenInt();
    });
  }

  /**
   * Redirect the app to the ECAS page for authentication.
   * @return {Observable<boolean|AuthError>} a boolean when authentication is successfully triggered, or an AuthError instance with error details.
   */
  public triggerWebAuthentication(serverUrl: string, redirectUrl: string, healthUrl : string) : Observable<boolean | AuthError> {
      return this.checkHealth(healthUrl)
        .map(() => {
          let redirectURL = encodeURIComponent(redirectUrl);
          let newLocation = `${serverUrl}?redirectURL=${redirectURL}`;
          this.logger.debug("Redirecting to URL " + newLocation);
          window.location.assign(newLocation);
          return true;
        })
        .catch((err) => this.handleLoginFailed(err));
  }

  /**
   * Authenticate using specified token.
   * To be used in combination with triggerWebAuthentication.
   *
   * @param token {string} The ECAS token to be used for getting server side JTW.
   * @param getUserUrl {string} The URL to be used for getting user information, once the JWT is obtained.
   *
   * @return {Observable<UserDetails|AuthError>} an UserDetails with user information when authentication is successfully triggered,
   *  or an AuthError instance with error details.
   */
  public authenticateWithToken(token: string, getUserUrl: string): Observable<any> {
      this.logger.debug("authenticateWithToken(" + token + ", " + getUserUrl + ")");
      if (token == AuthService.NO_ESC_USER_PROFILE_CODE) {
        return this.handleNoEscUserProfile();
      }

      return this.http.get(getUserUrl, {
        headers: this.getHeaders(token)
      }).pipe(
         map(data => new UserWithToken(new DefaultUserDetails(data), token)),
         mergeMap(userWithToken  =>this.storeUserData(userWithToken)),
         map(userWithToken => this.handleUserLoggedIn(userWithToken)),
         catchError((err) => this.handleLoginFailed(err))
      );
  }

  /**
   * Authenticate using ECAS web view.
   *
   * @param authGetToken4TicketUrl {string} The URL to be called for getting user profile, once the ECAS web view provides the user PT.
   * @param healthUrl {string} The URL to be called for ensuring that server is up an running.
   */
  public authenticateViaWebView(authGetToken4TicketUrl: string, healthUrl : string): UserWebViewLoginSession {
    const sessionId:string = "WV-" +new Date().getTime();
    const _authEvents = new Subject<AuthEvent>();
    const _canceled = new BehaviorSubject<boolean>(false);

    // function detecting when login session was explicitly canceled
    const notCanceled = () =>  _canceled.getValue() !== true;
    // functions to notify about login progress, login success or failure
    const notifyLoginInProgress = (progress:string) =>
      this.triggerLoginInProgressEvent(_authEvents, {progress});
    const notifyLoginSucceeded = (userData:UserWithToken) => {
      this.triggerLoginSuccessEvent(_authEvents, userData);
      this.triggerStatusUpdate(AuthenticationStatus.AUTHENTICATED);
    }
    const notifyLoginError = () => this.triggerLoginErrorEvent(_authEvents);

    let userDetails$ = this.isEcasPluginAvailable()
      // notify before checking if remote server is upp
      .do(() => notifyLoginInProgress('1/4'))
      .delay(EXTRA_DELAY_AUTH_VIA_WEB_VIEW) // XXX morujca - delay to allow progress dialog to be visible before moving to next step
      .flatMap(() => this.checkHealth(healthUrl))
      .filter(() => notCanceled())
      // notify before opening ECAS login windows to perform authentication
      .do(() => notifyLoginInProgress('2/4'))
      .flatMap(() => this.requestECASAuthenticationUsingWebView(sessionId))
      .filter(() => notCanceled())
      // notify before asking ECAS to get a DPT for authenticated user
      .do(() => notifyLoginInProgress('3/4'))
      .flatMap(userWithDPGT => this.requestEcasDesktopProxyTicket(userWithDPGT, sessionId))
      .filter(() => notCanceled())
      // notify before getting user profile and token
      .do(() => notifyLoginInProgress('4/4'))
      .flatMap(userWithDPT => this.getESCToken(authGetToken4TicketUrl, userWithDPT, sessionId))
      .filter(() => notCanceled())
      // store user data, including token
      .flatMap(userWithToken => this.storeUserData(userWithToken, sessionId))
      // notify login ended successfully and that user is now authenticated
      .do((userData) => notifyLoginSucceeded(userData))
      .map(userData => this.handleUserLoggedIn(userData, sessionId))
      .catch((err) => {
        notifyLoginError();
        return this.handleLoginFailed(err, sessionId);
      });

    return new UserWebViewLoginSession(sessionId, _authEvents.asObservable(), userDetails$, _canceled, this.logger);
  }


    /**
     * Authenticate using FAKE.
     *
     * @param fakeAuthGetToken4TicketUrl {string} The URL to be called for getting user profile,
     * @param healthUrl {string} The URL to be called for ensuring that server is up an running.
     *
     *
     */
    fakeLoginAuthentication(fakeAuthGetToken4TicketUrl: string, healthUrl : string): UserWebViewLoginSession {
        let sessionId:string = "WV-" +new Date().getTime();
        let _authEvents = new Subject<AuthEvent>();
        let _canceled = new BehaviorSubject<boolean>(false);

        let notCanceled = function () {
            return _canceled.getValue() !== true;
        };

        let userDetails$ =  this.getFakeESCToken(fakeAuthGetToken4TicketUrl, "guptaas", sessionId)
            .filter(() => notCanceled())
            .flatMap(userWithToken => this.storeUserData(userWithToken, sessionId))
            .do((userData) => {
                this.triggerLoginSuccessEvent(_authEvents, userData);
            })
            .map(userData => this.handleUserLoggedIn(userData, sessionId))
            .catch((err) => {
                this.triggerLoginErrorEvent(_authEvents);
                return this.handleLoginFailed(err, sessionId);
            });

        return new UserWebViewLoginSession(sessionId, _authEvents.asObservable(), userDetails$, _canceled, this.logger);
    }

  /**
   * Check if ECAS plugin is installed.
   */
  public isEcasPluginAvailable(): Observable<boolean | AuthError> {
    return this.ecasApi.isEcasPluginAvailable()
      .catch((err:EcasError) => {
        return Observable.throw(
          this.createAuthError(-100,err.message, err.code)
        );
      });
  }

  /**
   * Logout the user. Any previously persisted info about the user is to be removed.
   */
  public logout(): Observable<boolean> {
    return Observable.fromPromise(
        this.storage.remove(AuthService.TOKEN_KEY).then(() => {
          return this.userService.clearUserDetails();
        }).then(() => {
            this.triggerStatusUpdate(AuthenticationStatus.NOT_AUTHENTICATED);
            return true;
          },
          (err) => {
            return Promise.reject(err);
          })
      );
  }

  private handleNoEscUserProfile() {
    this.logger.debug("handleNoEscUserProfile()");

    let loginError : AuthError = this.createAuthError(403,'User has no ESC profile!', AuthService.NO_ESC_USER_PROFILE_CODE);
    this.logger.error("auth error: ", loginError);
    this.triggerStatusUpdate(AuthenticationStatus.NOT_AUTHENTICATED);
    return Observable.throw(loginError);
  }

  private storeUserData(data: UserWithToken, sessionId?:string): Observable<UserWithToken> {
    let logPrefix = this.createLogPrefix(sessionId);
    return new Observable<UserWithToken>((observer) => {
      this.logger.debug(logPrefix + "Persisting user details and token ...");
      this.userService.setUserDetails(data.userDetails)
        .then(() => {
          return this.storage.set(AuthService.TOKEN_KEY, data.token);
        }).then(() => {
          this.logger.debug(logPrefix + "User details and token successfully persisted");
          observer.next(data);
          observer.complete();
        }).catch((err) => {
          // error is to be logged by the main error handler
          this.logger.debug(logPrefix + "Could not persist user details and/or token!");
          observer.error(err);
      });
    });
  }

  private handleUserLoggedIn(data: UserWithToken, sessionId? : string) : UserDetails {
    if (sessionId) {
      this.logger.debug("[" + sessionId + "] handleUserLoggedIn(" + this.stringifySafe(data) + ")");
    } else {
      this.logger.debug("handleUserLoggedIn(" + this.stringifySafe(data) + ")");
    }

    return data.userDetails;
  }

  private handleLoginFailed(err: any, sessionId? : string): Observable<AuthError> {
    let logPrefix = this.createLogPrefix(sessionId);
    this.logger.debug(logPrefix + "handleLoginFailed(" + this.stringifySafe(err) + ")");

    this.triggerStatusUpdate(AuthenticationStatus.NOT_AUTHENTICATED);

    let errorToReport: AuthError;
    if (err instanceof AuthError) {
      // error was already converted by some handler up in the call chain
      errorToReport = err;
    } else if (err instanceof HttpErrorResponse) {
      errorToReport = this.convertHttpError(err);
    } else {
      errorToReport = this.convertGenericError(err);
    }
    return Observable.throw(errorToReport);
  }

  private triggerStatusUpdate(newStatus):void {
    this.ngZone.run(() => {
      this.statusStream.next(newStatus);
    });
  }

  private triggerLoginSuccessEvent(authEvents:Subject<AuthEvent>, userData: any) {
    this.runInsideAngularZone(() => {
      authEvents.next(new AuthEvent(AuthEventType.LOGIN_SUCCESS, userData));
    });
  }

  private triggerLoginInProgressEvent(authEvents:Subject<AuthEvent>, progress: any) {
    this.runInsideAngularZone(() => {
      authEvents.next(new AuthEvent(AuthEventType.LOGIN_IN_PROGRESS, progress));
    });
  }

  private triggerLoginErrorEvent(authEvents:Subject<AuthEvent>) {
    this.runInsideAngularZone(() => {
      authEvents.next(new AuthEvent(AuthEventType.LOGIN_ERROR));
    });
  }

  private runInsideAngularZone(fn: () => any) : any {
    return this.ngZone.run(() => {
      return fn();
    });
  }

  private convertHttpError(error: HttpErrorResponse) : AuthError {
    this.logger.warn("HTTP error response: " + this.stringifySafe(error));

    // Errors that can occur when checking the health of the server
    if (error.status === 404 || error.status === 0 || error.status == -1) {
      return this.createAuthError(error.status, this.getNoInternetConnectionMessage());
    }

    try {
      // handler errors when validating ECAS token
      let serverResponse: ServerErrorResponse = JSON.parse(error.error);
      if (serverResponse.message) {
        return this.createAuthError(error.status, serverResponse.message, serverResponse.code);
      }
    } catch (exception) {
      this.logger.warn("Could not convert response to JSON! Got exception " + this.stringifySafe(exception));
    }
    return this.createAuthError(error.status, this.getGenericErrorMessage(),'GENERIC_ERROR', this.stringifySafe(error));
  }

  private checkHealth(healthUrl : string) : Observable<boolean> {
    // just validate that we can successfully access the server
    return this.http
        .get(healthUrl)
      .timeout(this.httpTimeoutInMs)
      .map(() => true)
      .catch((err) => {
        if (this.isTimeoutError(err)) {
          const errorDetails = "Timeout while checking if server is up. Error: "+ this.stringifySafe(err);
          const authError = this.createAuthError(-100, this.getGenericErrorMessage(), AuthService.HTTP_TIMEOUT_CODE, errorDetails);
          return Observable.throw(authError);
        }
        // let the global handler provide a better exception
        return Observable.throw(err);
      });
  }

  private requestECASAuthenticationUsingWebView(sessionId : string): Observable<EULoginWithDPGT> {
    return this.ecasApi.requestAuthenticationViaWebView(sessionId)
      .catch((err:EcasError) => {
        // convert error to the right AuthError
        if (err.code === EcasApi.AUTHENTICATION_CANCELLED_CODE) {
          return Observable.throw(this.createAuthError(-100, err.message, AuthService.AUTHENTICATION_CANCELLED_CODE, this.stringifySafe(err)));
        }
        // NOTE: the original error message is too technical to be included in the error at this level
        this.logger.warn(this.createLogPrefix(sessionId) + " ECAS authentication via web view has failed! Details: " + this.stringifySafe(err));
        return Observable.throw(this.createAuthError(-100, this.getGenericErrorMessage(), err.code, this.stringifySafe(err)));
      });
  }

  private requestEcasDesktopProxyTicket(euLoginUser: EULoginWithDPGT, sessionId:string): Observable<EULoginUserWithDPT> {
    return this.ecasApi.requestDesktopProxyTicket(euLoginUser.dpgt, sessionId)
      .map(dpt => new EULoginUserWithDPT(euLoginUser.user, dpt))
      .catch((err:EcasError) => {
        const details = "Could not get DPT from ECAS for user: " +
          this.stringifySafe(euLoginUser.user) + "! Details: " + this.stringifySafe(err);
        this.logger.warn(this.createLogPrefix(sessionId) + " " + details);
        return Observable.throw(this.createAuthError(-100, this.getGenericErrorMessage(), err.code, details));
      });
  }

  private getESCToken(authGetToken4TicketUrl: string, userWithDPT: EULoginUserWithDPT,  sessionId:string): Observable<UserWithToken> {
    let logPrefix = this.createLogPrefix(sessionId);
    let url = `${authGetToken4TicketUrl}?ecasTicket=${userWithDPT.dpt}`;
    this.logger.debug(logPrefix + "Getting ESC token using URL: " + url);

    return this.http.get(url)
        .timeout(this.httpTimeoutInMs)
        .pipe(
          map((data: any) => {
            this.logger.debug(logPrefix + "Got data: " + this.stringifySafe(data));
            return new UserWithToken(new DefaultUserDetails(data), data["token"]);
          }),
          catchError((err) => {
            if (this.isTimeoutError(err)) {
              const userInfo = this.stringifySafe(userWithDPT);
              const errorDetails = "Timeout while getting server token for user " + userInfo + ". Error: " + this.stringifySafe(err);
              const authError = this.createAuthError(-100, this.getGenericErrorMessage(), AuthService.HTTP_TIMEOUT_CODE, errorDetails);
              return Observable.throw(authError);
            }
            // let the global handler provide a better exception
            return Observable.throw(err);
          }));

  }


    private getFakeESCToken(authGetToken4TicketUrl: string, ecasUid: string,  sessionId:string): Observable<UserWithToken> {
        let logPrefix = this.createLogPrefix(sessionId);
        let url = `${authGetToken4TicketUrl}?ecasUid=${ecasUid}`;
        this.logger.debug(logPrefix + "Getting ESC token using URL: " + url);

        return this.http.get(url).pipe(
            map((data: any) => {
                this.logger.debug(logPrefix + "Got data: " + this.stringifySafe(data));
                return new UserWithToken(new DefaultUserDetails(data), data["token"]);
            }));

    }

  private getHeaders(authToken: string) {
    this.logger.debug("Creating Header with Bearer " + authToken);
    let headers = new HttpHeaders();
    headers =  headers.append('Authorization', 'Bearer ' + authToken)
      .append('Accept', 'application/json;charset=UTF-8')
      .append('Content-Type', 'application/json;charset=utf-8')
      .append('Accept-Language', this.translateService.currentLang);
    console.log("headers --->", headers);
    return headers;
  }

  private convertGenericError(error: any) : AuthError {
    this.logger.debug("Generic error response: " + this.stringifySafe(error));
    return this.createGenericErrorObject(error);
  }

  private createGenericErrorObject(error?:any) : AuthError {
    if (error) {
      return this.createAuthError(-100,this.getGenericErrorMessage(), 'GENERIC_ERROR', this.stringifySafe(error));
    }
    return this.createAuthError(-100,this.getGenericErrorMessage());
  }

  private getGenericErrorMessage() {
    return this.translateService.instant('GENERIC_ERROR_MESSAGE');
  }

  private getNoInternetConnectionMessage() {
    return this.translateService.instant('NO_INTERNET_CONNECTION');
  }

  private createAuthError(status:number, message: string, code? : string, details?:string) : AuthError {
    let error = new AuthError();
    error.status = status;
    error.message = message;
    if (code) {
      error.code = code;
    }
    if (details) {
      error.details = details;
    }

    this.logger.debug('Created auth error: ' + error);
    return error;
  }

  private isTimeoutError(err:any) {
    return err && err.name && err.name === 'TimeoutError';
  }

  private stringifySafe(obj:any) : string {
    let objAsStr = obj.toString();
    try {
      objAsStr = stringify(obj);
    } catch (exception) {
      this.logger.warn("Could not stringify the object " + obj + "! Got exception " + stringify(exception));
    }

    return objAsStr;
  }

  private createLogPrefix(sessionId?: string) {
    return `${sessionId ? '[' + sessionId + '] ' : ''}`;
  }
}

/**
 * Inner classes.
 */
class UserWithToken {
  constructor(public userDetails : UserDetails, public token : string) {
    if (!token) {
      throw new Error("No token specified for UserWithToken!");
    }
  }
}

class EULoginUserWithDPT {
  constructor(public user: EULoginUser, public dpt: string) {
  }
}

/**
 * Internal object that follows the structure of a server side error issued when doing HTTP calls to ESC server.
 */
class ServerErrorResponse {
  id : string;
  code : string;
  message : string;
}
