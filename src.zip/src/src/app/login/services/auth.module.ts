import {CommonModule} from "@angular/common";
import {HttpClient} from "@angular/common/http";
import {NgModule, NgZone} from "@angular/core";
import {FileTransfer} from "@ionic-native/file-transfer";
import {Storage} from "@ionic/storage";
import {TranslateModule, TranslateService} from "@ngx-translate/core";
import {IonicModule} from "ionic-angular";
import {EscAppVersion} from "../../core/app-info/esc-app-version";
import {HttpErrorHandler} from "../../core/http/http-error-handler";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {AuthService} from "./auth.service";
import {EcasApi} from "./ecas-api";
import {EscFiles} from "../../core/http/esc-files";
import {EscHttp} from "../../core/http/esc-http";
import {UserService} from "./user.service";


export function provideAuthService(storage: Storage, http: HttpClient, userService : UserService,
                                   loggerFactory: LoggerFactory, translateService: TranslateService,
                                   ecasApi : EcasApi, ngZone : NgZone) {
    return new AuthService(storage, http, userService, loggerFactory, translateService, ecasApi, ngZone);
}

export function provideUserService(storage: Storage, loggerFactory: LoggerFactory) {
    return new UserService(storage, loggerFactory);
}

export function provideEcasApi(loggerFactory: LoggerFactory) {
  return new EcasApi({}, loggerFactory);
}

export function escHttpService(http: HttpClient, httpErrorHandler: HttpErrorHandler) {
    // use ESC own Http handler, to allow easier customization
    return new EscHttp(http, httpErrorHandler);
}

export function escFilesService(authService : AuthService, transfer : FileTransfer, translateService: TranslateService, appVersion: EscAppVersion, httpErrorHandler: HttpErrorHandler) {
  return new EscFiles(authService, transfer, translateService, appVersion, httpErrorHandler);
}

/*export function tokenInterceptorFactory(authService : Storage, loggerFactory: LoggerFactory) {
  return new TokenInterceptor(authService, loggerFactory);
}*/

@NgModule({
    imports: [
        CommonModule,
        TranslateModule.forChild({
            isolate: false
        }),
        IonicModule],
    providers: [
        // get info about the logged in user
        { provide: UserService,
          useFactory: provideUserService,
          deps: [Storage, LoggerFactory]
        },

        // Wrapper on top of ECAS plugin
        { provide: EcasApi,
          useFactory: provideEcasApi,
          deps: [LoggerFactory]
        },

        // authentication via ECAS web view
        {
            provide: AuthService,
            useFactory: provideAuthService,
            deps: [Storage, HttpClient, UserService, LoggerFactory, TranslateService, EcasApi, NgZone]
        },

        // configure the decorator of AuthHttp that adds additional HTTP headers like X-App-Version and Accept-Language
        {
            provide: EscHttp,
            useFactory: escHttpService,
            deps: [HttpClient, HttpErrorHandler]
        },

        // configure the decorator of uploads of files via native components that adds additional HTTP headers like X-App-Version and Accept-Language
        {
          provide: EscFiles,
          useFactory: escFilesService,
          deps: [AuthService, FileTransfer, TranslateService, EscAppVersion, HttpErrorHandler]
        }/*,
        {
          provide: HTTP_INTERCEPTORS,
          useFactory: tokenInterceptorFactory,
          deps: [Storage, LoggerFactory],
          multi: true
        }*/

    ]
})
export class AuthModule {
}
