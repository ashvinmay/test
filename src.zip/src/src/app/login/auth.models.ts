import {BehaviorSubject} from "rxjs/BehaviorSubject";
import {Observable} from "rxjs/Observable";
import { Logger } from "../core/logger/logger";

/**
 * Error object returned during authentication.
 */
export class AuthError {
    status: number; // usually the HTTP response status
    message: string; // a user friendly message
    code?: string; // optionally, the code received from ESC server,
    details?: string
}

/**
 * Public model classes.
 */
export class AuthEvent {
    constructor(public eventType: AuthEventType, public eventData?: any) {
    }
}

/**
 * Types of events sent when user is authenticating.
 */
export enum AuthEventType {
    /**
     * Triggered when ECAS authentication was performed and the process continues with
     * validating the DPT and getting the ESC token.
     */
    LOGIN_IN_PROGRESS,
    /**
     * Triggered when authentication was successful.
     */
    LOGIN_SUCCESS,
    /**
     * Triggered when there was an error during authentication.
     */
    LOGIN_ERROR
}

/**
 * Possible authentication statuses for a user.
 */
export enum AuthenticationStatus {
    AUTHENTICATED,
    NOT_AUTHENTICATED
}

/**
 * Session object returned to the caller when using ECAS authentication via web view.
 * Caller can then register for getting the user details and also to follow the progress of the login process.
 * The session can also be canceled by the caller.
 */
export class UserWebViewLoginSession {

    constructor(public id: string,
        /**
         * Stream of events to listen to when calling authenticateViaWebView() method.
         * @type {Subject<AuthEvent>}
         */
        private authEvents: Observable<AuthEvent>,
        private userDetails: Observable<any>, // UserDetails
        private canceledSubject: BehaviorSubject<boolean>,
        private logger: Logger) {
    }

    /**
     * @return {Observable<AuthEvent>} progress information about the login process.
     */
    getAuthEvents(): Observable<AuthEvent> {
        return this.authEvents;
    }

    /**
     * @return {Observable<UserDetails|AuthError>} an UserDetails with user information when authentication is successfully triggered,
     *  or an AuthError instance with error details.
     */
    getUserDetails(): Observable<any> {
        return this.userDetails;
    }

    cancel(): void {
        this.logger.info("[" + this.id + "] User has canceled session");
        this.canceledSubject.next(true);
    }

    isCanceled(): boolean {
        return this.canceledSubject.getValue();
    }
}
