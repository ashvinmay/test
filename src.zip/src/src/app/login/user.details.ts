/**
 * @author morujca
 * @since 24/01/2017
 */
export interface UserDetails {
    userIdStr: string;
    firstName: string;
    lastName: string;
    locale: string;
    termsAccepted: boolean;
    acceptedOffer: boolean;
    visibility: string;
    avatarId: string;
    prn: string;
}

/**
 * Default implementation of the UserDetails interface.
 * It knows hot to extract all fields info from user profile data received from our server.
 */
export class DefaultUserDetails implements UserDetails {
  userIdStr: string;
  firstName: string;
  lastName: string;
  locale: string;
  termsAccepted: boolean;
  acceptedOffer: boolean;
  visibility: string;
  avatarId: string;
  prn: string;

  constructor(data: any) {
    if (!data) {
      throw new Error("Cannot build an DefaultUserDetails instance using empty data");
    }
    if (!data['userIdStr']) {
      throw new Error("No userIdStr in provided data: " + data);
    }
    this.userIdStr = data['userIdStr'];
    this.firstName = data['firstName'];
    this.lastName = data['lastName'];
    this.termsAccepted = data['termsAccepted'];
    this.visibility = data['visibility'];
    this.acceptedOffer = data['acceptedOffer'];
    this.prn = data['prn'];
    this.avatarId = data['avatarLastModificationTime'];
    this.locale = data['languageCode'];
  }
}
