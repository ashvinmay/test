
export const PAGES = [
  {
    title: 'FAQ_MENU',
    component: 'FAQPage',
    activeWhenAuth: true,
    activeWhenNotAuth: true,
    icon: 'ios-help-circle-outline'
  },
  {
    title: 'LANGUAGE_MENU',
    component: 'SettingsPage',
    activeWhenAuth: true,
    activeWhenNotAuth: true,
    icon: 'ios-settings-outline'
  },
  {
    title: 'CONTACT_MENU',
    component: null,
    activeWhenAuth: true,
    activeWhenNotAuth: false,
    icon: 'ios-mail-outline'
  },
  {
    title: 'ABOUT_MENU',
    component: 'AboutPage',
    activeWhenAuth: true,
    activeWhenNotAuth: true,
    icon: 'ios-information-circle-outline'
  }
];
