import {Component} from '@angular/core';

@Component({
    selector: 'page-initial',
    templateUrl: 'initial.html'
})
export class InitialPage {

    constructor() {
    }

}