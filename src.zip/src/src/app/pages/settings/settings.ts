import {Component} from '@angular/core';
import {IonicPage, Loading, LoadingController, NavController, NavParams} from 'ionic-angular';
import {TranslateService} from "@ngx-translate/core";
import {AnalyticService} from "../../core/analytics/analytic.service";
import {LANGUAGES} from "../../core/models/languages";
import {AuthService} from "../../login/services/auth.service";
import {AuthenticationStatus} from '../../login/auth.models';
import {UserUpdateService} from "../../login/services/user.update.service";
import {AlertUtils} from "../../core/alert-utils";
import {LangService} from "../../core/lang.service";
import {Subscription} from 'rxjs';

@IonicPage()
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html'
})
export class SettingsPage {

  currentLang: string;
  languages: Array<{ code: string, language: string }>;
  private loading: Loading;
  //languages: Array<string> = [];
  private isUserAuthenticated: boolean = false;
  private userAuthenticationSubscription: Subscription;

  constructor(public translate: TranslateService,
              public navCtrl: NavController,
              public navParams: NavParams,
              private userUpdateService: UserUpdateService,
              private loadingCtrl: LoadingController,
              private alertUtils: AlertUtils,
              private authService: AuthService,
              private langService: LangService,
              private analyticService: AnalyticService) {

    this.currentLang = translate.currentLang;
    this.languages = LANGUAGES;
  }

  ionViewDidLoad() {
    this.userAuthenticationSubscription = this.authService.getAuthenticationStatus()
      .subscribe(status => {
        if (status === AuthenticationStatus.NOT_AUTHENTICATED) {
          this.isUserAuthenticated = false;
        } else {
          this.isUserAuthenticated = true;
        }
      });
  }

  ionViewWillUnload() {
    this.userAuthenticationSubscription.unsubscribe();
  }


  changeLanguage(newLanguage) {
    if (!this.isUserAuthenticated) {
      this.langService.updateLanguage(newLanguage).subscribe(lang => this.currentLang = lang);
    }
    else {
      this.loading = this.loadingCtrl.create({
        content: '<b>' + this.translate.instant('PLEASE_WAIT') + '</b>'
      });
      this.loading.present().then(() => {
        // if server call fails, than appState and ui should not change...
        this.userUpdateService.updateUserLanguage(newLanguage).subscribe(
          (flag) => {
            let oldLang: string = this.currentLang;
            this.langService.updateLanguage(newLanguage).subscribe(lang => {
                this.currentLang = lang;
                 let eventDetails = {
                   "oldLang" : oldLang,
                   "newLang" : newLanguage
                 }
                 this.analyticService.trackEvent('ChangeLang', eventDetails);
                this.hideLoading();
              },
              (err) => {
                this.handleUpdateLangError(err);
              });

          },
          (err) => {
            this.handleUpdateLangError(err);
          }
        );
      });
    }

  }


  private handleUpdateLangError(error: any) {
    this.hideLoading();
    return this.alertUtils.handleGetPostsError(error);
  }

  private hideLoading() {
    if (this.loading) {
      this.loading.dismiss();
      this.loading = null;
    }
  }
}
