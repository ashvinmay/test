import {Component} from '@angular/core';
import {IonicPage, NavController, NavParams} from 'ionic-angular';
import {BrowserService} from "../../core/browser-service";
import {TranslateService} from "@ngx-translate/core";
import {StatusBar} from "@ionic-native/status-bar";


@IonicPage()
@Component({
    selector: 'page-learning',
    templateUrl: 'learning.html',
})
export class LearningPage {
    private currentLang: string = "en";

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                private browserService: BrowserService,
                private translateService: TranslateService,
                private statusBar: StatusBar) {
        this.currentLang = this.translateService.currentLang;
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#A81573');
        this.statusBar.styleLightContent();
    }

    openTraining1() {
        let url = "https://europa.eu/youth/solidarity/dashboard/training/175_" + this.currentLang;
        this.browserService.openUrl(url);
    }

    openTraining2() {
        let url = "https://europa.eu/youth/solidarity/dashboard/training/178_" + this.currentLang;
        this.browserService.openUrl(url);
    }

    openTraining3() {
        let url = "https://europa.eu/youth/solidarity/dashboard/training/181_" + this.currentLang;
        this.browserService.openUrl(url);
    }

    openTraining4() {
        let url = "https://europa.eu/youth/solidarity/dashboard/training/185_" + this.currentLang;
        this.browserService.openUrl(url);
    }
}
