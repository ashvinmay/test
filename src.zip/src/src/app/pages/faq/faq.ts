import {Component} from '@angular/core';
import {IonicPage, NavController, NavParams} from 'ionic-angular';
import {AnalyticService} from "../../core/analytics/analytic.service";
import {FAQS} from "./faqs";
import {Faq} from "./faq.model";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage()
@Component({
    selector: 'page-faq',
    templateUrl: 'faq.html'
})
export class FAQPage {

    faqs: Array<Faq>;

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                private statusBar: StatusBar,
                private analyticService: AnalyticService) {
        this.faqs = FAQS;
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#3A3B81');
        this.statusBar.styleLightContent();
    }

    itemTapped(event, faq) {
        // That's right, we're pushing to ourselves!
        this.navCtrl.push('FaqDetailPage', {
            faq: faq
        }).then(data => {
            let pageDetails = {
                "faqId": faq.id,
                "faqQuestion": faq.question,
                "faqAnswer": faq.answer,
            };
            this.analyticService.trackPageView('FaqDetailPage', pageDetails);
        });
    }

}