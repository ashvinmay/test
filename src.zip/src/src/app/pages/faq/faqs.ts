import {Faq} from "./faq.model";

export const FAQS: Array<Faq> = [
    {
        id: 1,
        question: "FAQ_Q1",
        answer: "FAQ_A1"
    },
    {
        id: 2,
        question: "FAQ_Q2",
        answer: "FAQ_A2"
    },
    {
        id: 3,
        question: "FAQ_Q3",
        answer: "FAQ_A3"
    },
    {
        id: 4,
        question: "FAQ_Q4",
        answer: "FAQ_A4"
    },
    {
        id: 5,
        question: "FAQ_Q5",
        answer: "FAQ_A5"
    },
    {
        id: 6,
        question: "FAQ_Q6",
        answer: "FAQ_A6"
    },
    {
        id: 7,
        question: "FAQ_Q7",
        answer: "FAQ_A7"
    },
    {
        id: 8,
        question: "FAQ_Q8",
        answer: "FAQ_A8"
    },
    {
        id: 9,
        question: "FAQ_Q9",
        answer: "FAQ_A9"
    },
    {
        id: 10,
        question: "FAQ_Q10",
        answer: "FAQ_A10"
    },
    {
        id: 11,
        question: "FAQ_Q11",
        answer: "FAQ_A11"
    },
    {
        id: 12,
        question: "FAQ_Q12",
        answer: "FAQ_A12"
    },
    {
        id: 13,
        question: "FAQ_Q13",
        answer: "FAQ_A13"
    }
];