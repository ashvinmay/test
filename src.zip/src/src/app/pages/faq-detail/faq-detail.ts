import {Component, ElementRef} from '@angular/core';
import {IonicPage, NavController, NavParams} from 'ionic-angular';
import {TranslateService} from "@ngx-translate/core";
import {BrowserService} from "../../core/browser-service";
import {StatusBar} from "@ionic-native/status-bar";

@IonicPage({
    name: 'FaqDetailPage'
})
@Component({
    selector: 'page-faq-detail',
    templateUrl: 'faq-detail.html'
})
export class FaqDetailPage {

    question: string;
    answer: string;

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                private statusBar: StatusBar,
                translate: TranslateService,
                private elRef: ElementRef,
                private browserService: BrowserService) {
        // If we navigated to this page, we will have an item available as a nav param
        translate.get(navParams.get('faq').question).subscribe(
            value => {
                this.question = value;
            }
        );
        translate.get(navParams.get('faq').answer).subscribe(
            value => {
                this.answer = value;
            }
        );
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.backgroundColorByHexString('#3A3B81');
        this.statusBar.styleLightContent();
    }

    ngAfterViewInit() {
        this.browserService.fixLinks(this.elRef.nativeElement);
    }

}