import {Injectable} from "@angular/core";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {Logger} from "../../core/logger/logger";
import {TranslateService} from "@ngx-translate/core";
import {EnvConfiguration} from "../../../env/env.configuration";

@Injectable()
export class ContactService {
    private logger: Logger;

    constructor(private config: EnvConfiguration,
                loggerFactory: LoggerFactory, private translate: TranslateService) {
        this.logger = loggerFactory.getLogger("ContactService");
    }

    sendEmail(displayName: string, prn:string) {
        this.logger.debug("send email to support for PRN: "+ displayName+"("+prn+")");
        let emailSubject:string = this.translate.instant('SUPPORT_EMAIL_SUBJECT') + " - " + displayName +" ("+prn+")";
        let link = "mailto:"+ this.config.supportEmail +"?subject="+emailSubject;
        window.open(link, "_system");
    }
}
