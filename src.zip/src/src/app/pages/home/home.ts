import {Component} from "@angular/core";
import {TranslateService} from "@ngx-translate/core";
import {AlertController, MenuController, NavController, NavParams, Platform} from "ionic-angular";
import {Subscription} from "rxjs/Rx";
import {AnalyticService} from "../../core/analytics/analytic.service";
import {BrowserService} from "../../core/browser-service";
import {Logger} from "../../core/logger/logger";
import {LoggerFactory} from "../../core/logger/logger-factory";
import {StorageService} from "../../core/storage-service";
import {UserService} from "../../login/services/user.service";
import {UserUpdateService} from "../../login/services/user.update.service";
import {UserDetails} from "../../login/user.details";
import {NotificationService} from "../../notification/services/notification.service";
import {StatusBar} from "@ionic-native/status-bar";

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
    private logger: Logger;
    items: Array<{title: string, image: string, count: number, active: boolean}>;
    userDetails: UserDetails;
    private subscriptions: Array<Subscription>;
    newNotificationCount: number;

    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                public menu: MenuController,
                private userService: UserService,
                private storageService: StorageService,
                private alertCtrl: AlertController,
                private translateService: TranslateService,
                private browserService: BrowserService,
                private userUpdateService: UserUpdateService,
                private notificationService: NotificationService,
                public platform: Platform,
                private analyticService: AnalyticService,
                private statusBar: StatusBar,
                loggerFactory: LoggerFactory) {
        this.logger = loggerFactory.getLogger("HomePage");
        this.items = [
            {
                title: 'COMMUNITY_PROFILE_MY_JOURNAL',
                image: "ios-paper-outline",
                count: 0,
                active: true
            },
            {
                title: 'MY_COMMUNITY_TITLE',
                image: "ios-people-outline",
                count: 0,
                active: true
            },
            {
                title: 'LEARNING_RESOURCES',
                image: "ios-book-outline",
                count: 0,
                active: true
            },
            {
                title: 'MY_PROFILE_MENU',
                image: "ios-person-outline",
                count: 0,
                active: true
            },
            {
                title: 'MY_NOTIFICATIONS',
                image: "ios-notifications-outline",
                count: 0,
                active: true
            },
            {
                title: 'ACTIVITIES_TITLE',
                image: "ios-pin-outline",
                count: 0,
                active: true
            }
        ];
    }

    ionViewWillEnter() {
        // Set status bar color
        this.statusBar.overlaysWebView(false); // For Ios
        this.statusBar.styleDefault();
        this.logger.debug("Versions: ", this.platform.versions());
        if (this.platform.is("ios")) {
            this.statusBar.backgroundColorByHexString('#f8f8f8');
        } else if (this.platform.versions().android.num < 6) {
            // Status-text cannot be black (we use gray background for Android 5)
            this.statusBar.backgroundColorByHexString('#b0b0b0');
        } else {
            this.statusBar.backgroundColorByHexString('#f8f8f8');
        }
    }

    ionViewDidEnter() {
        this.subscriptions = [];
        // Refresh user details.
        this.subscriptions.push(this.userUpdateService.refreshUser().subscribe( data => {
            this.subscriptions.push(this.storageService.getUserFirstLogin()
                .subscribe((firstLogin) => {
                    this.subscriptions.push(this.userService.getUserDetailsUpdates()
                        .subscribe(userDetails => {
                            // Get alert flags from storage
                            if (!userDetails.acceptedOffer) {
                                this.storageService.getUnAcceptedOfferAlertDisplayed()
                                    .subscribe((displayed) => {
                                        if (!displayed) {
                                            this.presentParticipantAlert('WELCOME_TEXT_ALL_USER');
                                            this.storageService.setUnAcceptedOfferAlertDisplayed(true);
                                        }
                                    });
                                this.storageService.setUserFirstLogin(false);
                            } else {
                                if (firstLogin) {
                                    this.storageService.getAcceptedOfferAlertDisplayed()
                                        .subscribe((displayed) => {
                                            if (!displayed) {
                                                this.presentParticipantAlert('WELCOME_TEXT_FIRST_LOGIN_ACCEPTED_OFFER');
                                                this.storageService.setAcceptedOfferAlertDisplayed(true);
                                            }
                                        });
                                    this.storageService.setUserFirstLogin(false);
                                } else {
                                    this.storageService.getAcceptedOfferAlertDisplayed()
                                        .subscribe((displayed) => {
                                            if (!displayed) {
                                                this.AfterLoginAcceptedOfferAlert('WELCOME_TEXT_ACCEPTED_OFFER_AFTER_LOGIN');
                                                this.storageService.setAcceptedOfferAlertDisplayed(true);
                                            }
                                        });
                                }
                            }
                        }));
                }));
        }));

        this.subscriptions.push(this.storageService.getUserFirstLogin()
            .subscribe((firstLogin) => {
                this.subscriptions.push(this.userService.getUserDetailsUpdates()
                    .subscribe(userDetails => {
                        // Get alert flags from storage
                        if (!userDetails.acceptedOffer) {
                            this.storageService.getUnAcceptedOfferAlertDisplayed()
                                .subscribe((displayed) => {
                                    if (!displayed) {
                                        this.presentParticipantAlert('WELCOME_TEXT_ALL_USER');
                                        this.storageService.setUnAcceptedOfferAlertDisplayed(true);
                                    }
                                });
                            this.storageService.setUserFirstLogin(false);
                        } else {
                            if (firstLogin) {
                                this.storageService.getAcceptedOfferAlertDisplayed()
                                    .subscribe((displayed) => {
                                        if (!displayed) {
                                            this.presentParticipantAlert('WELCOME_TEXT_FIRST_LOGIN_ACCEPTED_OFFER');
                                            this.storageService.setAcceptedOfferAlertDisplayed(true);
                                        }
                                    });
                                this.storageService.setUserFirstLogin(false);
                            } else {
                                this.storageService.getAcceptedOfferAlertDisplayed()
                                    .subscribe((displayed) => {
                                        if (!displayed) {
                                            this.AfterLoginAcceptedOfferAlert('WELCOME_TEXT_ACCEPTED_OFFER_AFTER_LOGIN');
                                            this.storageService.setAcceptedOfferAlertDisplayed(true);
                                        }
                                    });
                            }
                        }
                    }));
            }));

        //Get new notification count
        this.notificationService.getUnreadCount().subscribe(data => {
            this.newNotificationCount = data;
        });
        this.subscriptions.push(this.notificationService.subscribeToUnreadCountUpdates().subscribe(
            count => {
                if(count > 0) {
                    this.logger.debug("New count for unread is "+ count);
                    this.newNotificationCount = count;
                }

            }
        ));
        // The menu should be enabled on the main page
        this.menu.enable(true, 'escMenu');
    }

    openLearning() {
       /* let language = this.translateService.currentLang;
        let url = "https://europa.eu/youth/solidarity/dashboard/training_" + language;
        this.browserService.openUrl(url);*/
        this.navCtrl.push('LearningPage').then(data => {
          this.analyticService.trackPageView('LearningPage')
        });
    }

    openCommunity() {
        this.navCtrl.push('CommunityPage').then(data => {
          this.analyticService.trackPageView('CommunityPage')
        });
    }

    openMyProfile() {
        this.navCtrl.push('MyProfilePage').then(data => {
          this.analyticService.trackPageView('MyProfilePage');
        });
    }

    openMyJournal() {
        // Get user info
        this.userService.getUserDetails()
            .subscribe(userDetails => {
                // Set userId param for MyJournal
                let params = {
                    userId: userDetails.userIdStr
                };
                this.navCtrl.push('CommunityProfilePage', params).then(data => {
                  let pageDetails = {
                    "userId" : userDetails.userIdStr
                  }
                  this.analyticService.trackPageView('CommunityProfilePage', pageDetails);
                });
            });
    }

    openMyNotifications () {
        this.navCtrl.push('NotificationPage').then(data => {
          this.analyticService.trackPageView('NotificationPage')
        });
    }

    openPlacements() {
      this.navCtrl.push('ActivitiesPage').then(data => {
        this.analyticService.trackPageView('ActivitiesPage')
      });
    }

    openFeedBackForm() {
        let url = "https://ec.europa.eu/eusurvey/runner/EU-Solidarity-Corps-app-feedback";
        this.browserService.openUrl(url);
    }

    ionViewWillLeave() {
        this.subscriptions.forEach(s => {
            if (s) s.unsubscribe();
        });
        this.subscriptions = [];
        // The menu should be disabled on the pages
        this.menu.enable(false);

    }

    private presentParticipantAlert(message: string) {
        let alert = this.alertCtrl.create({
            message: this.translateService.instant(message),
            buttons: this.isAndroid()?[this.closeBtn, this.openMyJournalBtn]:[this.openMyJournalBtn,this.closeBtn],
            cssClass: 'alert-btn-center'
        });
        alert.present();
    }

    private closeBtn = {
        text: this.translateService.instant('GLOBAL_CLOSE'),
        role: 'cancel',
        handler: () => {
        }
    };

    private openMyJournalBtn = {
        text: this.translateService.instant('ACCEPTED_OFFER_BTN'),
        handler: () => {
            this.openMyJournal();
        }
    };


    private AfterLoginAcceptedOfferAlert(message: string) {
        let alert = this.alertCtrl.create({
            message: this.translateService.instant(message),
            buttons: [
                {
                    text: this.translateService.instant('GLOBAL_CLOSE'),
                    role: 'cancel',
                    handler: () => {
                    }
                }
            ],
            cssClass: 'alert-btn-center'
        });
        alert.present();
    }


    private isAndroid(): boolean {
        return this.platform.is('android')
    }

}
