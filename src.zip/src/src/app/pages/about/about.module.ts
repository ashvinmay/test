import {NgModule} from "@angular/core";
import {AboutPage} from "./about";
import {IonicPageModule} from "ionic-angular";
import {TranslateModule} from "@ngx-translate/core";

@NgModule({
    declarations :[
        AboutPage
    ],
    imports : [
        IonicPageModule.forChild(AboutPage),
        TranslateModule.forChild()
    ]
})
export class AboutPageModule{}