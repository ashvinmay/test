import {Component} from "@angular/core";
import {EscAppVersion} from "../../core/app-info/esc-app-version";
import {AppInfo} from "../../core/app-info/app-info.model";
import {TranslateService} from "@ngx-translate/core";
import {AlertController, IonicPage} from "ionic-angular";
import {EnvConfiguration} from "../../../env/env.configuration";

/**
 * Page displaying the app name and current version.
 * Plus all plugins and libraries used.
 */
@IonicPage()
@Component({
    selector: 'page-about',
    templateUrl: './about.html'
})
export class AboutPage {

    appInfo: AppInfo;
    environment: string;

    constructor(private appVersionService: EscAppVersion,
                private alertCtrl: AlertController,
                private config:EnvConfiguration,
                private translateService: TranslateService) {
    }

    ionViewWillEnter() {
        let self = this;
        this.appVersionService.getAppInfo().then((appInfo) => {
            self.appInfo = appInfo;
        });
        let env = this.config.env;
        this.environment = ((env && env.toLowerCase() != "prod") ? env : null);
    }

    openEUPLicense() {
        this.presentAlert("EUP License", "EUP_LICENSE");
    }

    openBSDLicense() {
        this.presentAlert("BSD License", "BSD_LICENSE");
    }

    openMITLicense() {
        this.presentAlert("MIT License", "MIT_LICENSE");
    }

    openApacheV2License() {
        this.presentAlert("Apache 2.0 License", "APACHEV2_LICENSE");
    }

    private presentAlert(title: string, message: string) {
        let alert = this.alertCtrl.create({
            title: title,
            message: this.translateService.instant(message),
            buttons: [
                {
                    text: this.translateService.instant('GLOBAL_OK'),
                    role: 'cancel'
                }
            ]
        });
        alert.present();
    }

}