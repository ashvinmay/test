"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var testing_1 = require("@angular/core/testing");
var lang_service_1 = require("./lang.service");
var logger_factory_1 = require("../logger/logger-factory");
var core_1 = require("@ngx-translate/core");
var storage_service_1 = require("./storage-service");
var http_1 = require("@angular/common/http");
var storage_1 = require("@ionic/storage");
var http_loader_1 = require("@ngx-translate/http-loader");
var fr_1 = require("@angular/common/locales/fr");
// or load it from app.module...?!
function createTranslateLoader(http) {
    return new http_loader_1.TranslateHttpLoader(http, 'assets/i18n/', '.json');
    //return new TranslateFakeLoader();
}
exports.createTranslateLoader = createTranslateLoader;
var storageConfig = {
    name: '_escstorage',
    storeName: '_esckv',
    driverOrder: ['sqlite', 'indexeddb', 'websql', 'localstorage']
};
describe('LangService tests', function () {
    var supportedLanguages = ['bg', 'cs', 'da', 'de', 'el', 'en', 'es', 'et', 'fi', 'fr', 'ga', 'hr', 'hu', 'is', 'it', 'lt', 'lv', 'mk', 'mt', 'nl', 'no', 'pl', 'pt', 'ro', 'sk', 'sl', 'sv', 'tr'];
    beforeEach(function () {
        testing_1.TestBed.configureTestingModule({
            imports: [
                http_1.HttpClientModule,
                core_1.TranslateModule.forRoot({
                    loader: {
                        provide: core_1.TranslateLoader,
                        useFactory: (createTranslateLoader),
                        deps: [http_1.HttpClient]
                    }
                }),
                storage_1.IonicStorageModule.forRoot(storageConfig),
            ],
            providers: [lang_service_1.LangService, logger_factory_1.LoggerFactory, storage_service_1.StorageService]
            // declarations: [
            //   LangService
            // ]
        });
    });
    it("should init all supported languages", testing_1.inject([lang_service_1.LangService], function (langService) {
        expect(langService).toBeTruthy();
        var languageSettings = Object.keys(langService.langCodesToNgLangResourceMap);
        expect(languageSettings).toEqual(supportedLanguages);
    }));
    it("should map 'fr' to 'localeFr' ", testing_1.inject([lang_service_1.LangService], function (langService) {
        expect(langService.langCodesToNgLangResourceMap['fr']).toEqual(fr_1.default);
    }));
    it("should be possible to change to known language' ", testing_1.inject([lang_service_1.LangService], function (langService) {
        var newLanguage = supportedLanguages[4];
        console.log("known language: ", newLanguage);
        expect(langService.updateLanguage(newLanguage)).toEqual(newLanguage);
    }));
    it("should fallback to default EN when change to unknown language' ", testing_1.inject([lang_service_1.LangService], function (langService) {
        var newLanguage = "pz";
        expect(langService.updateLanguage(newLanguage)).toEqual(lang_service_1.LangService.DEFAULT_APP_LANGUAGE);
    }));
});
