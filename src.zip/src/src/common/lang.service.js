"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var fr_1 = require("@angular/common/locales/fr");
var bg_1 = require("@angular/common/locales/bg");
var cs_1 = require("@angular/common/locales/cs");
var da_1 = require("@angular/common/locales/da");
var de_1 = require("@angular/common/locales/de");
var el_1 = require("@angular/common/locales/el");
var en_1 = require("@angular/common/locales/en");
var es_1 = require("@angular/common/locales/es");
var et_1 = require("@angular/common/locales/et");
var fi_1 = require("@angular/common/locales/fi");
var ga_1 = require("@angular/common/locales/ga");
var hr_1 = require("@angular/common/locales/hr");
var hu_1 = require("@angular/common/locales/hu");
var is_1 = require("@angular/common/locales/is");
var it_1 = require("@angular/common/locales/it");
var lt_1 = require("@angular/common/locales/lt");
var lv_1 = require("@angular/common/locales/lv");
var mk_1 = require("@angular/common/locales/mk");
var mt_1 = require("@angular/common/locales/mt");
var nl_1 = require("@angular/common/locales/nl");
var nb_1 = require("@angular/common/locales/nb");
var pl_1 = require("@angular/common/locales/pl");
var pt_1 = require("@angular/common/locales/pt");
var ro_1 = require("@angular/common/locales/ro");
var sk_1 = require("@angular/common/locales/sk");
var sl_1 = require("@angular/common/locales/sl");
var sv_1 = require("@angular/common/locales/sv");
var tr_1 = require("@angular/common/locales/tr");
/**
 * Manages current app language
 */
var LangService = /** @class */ (function () {
    function LangService(loggerFactory, translateService, storageService, translateLoader) {
        this.translateService = translateService;
        this.storageService = storageService;
        this.translateLoader = translateLoader;
        // app lang codes to ng resource names
        this._langCodesToNgLangResourceMap = {
            'bg': bg_1.default, 'cs': cs_1.default, 'da': da_1.default, 'de': de_1.default, 'el': el_1.default,
            'en': en_1.default, 'es': es_1.default, 'et': et_1.default, 'fi': fi_1.default, 'fr': fr_1.default,
            'ga': ga_1.default, 'hr': hr_1.default, 'hu': hu_1.default, 'is': is_1.default, 'it': it_1.default,
            'lt': lt_1.default, 'lv': lv_1.default, 'mk': mk_1.default, 'mt': mt_1.default, 'nl': nl_1.default,
            'no': nb_1.default, 'pl': pl_1.default, 'pt': pt_1.default, 'ro': ro_1.default, 'sk': sk_1.default,
            'sl': sl_1.default, 'sv': sv_1.default, 'tr': tr_1.default
        };
        this.logger = loggerFactory.getLogger("LangService");
        this.translateService.addLangs(Object.keys(this._langCodesToNgLangResourceMap));
        // this language will be used as a fallback when a translation isn't found in the current language
        this.translateService.setDefaultLang(LangService_1.DEFAULT_APP_LANGUAGE);
    }
    LangService_1 = LangService;
    LangService.prototype.initTranslations = function () {
        var _this = this;
        // the lang to use, if the lang isn't available, it will use the current loader to get them
        this.storageService.getUserSelectedLanguage().subscribe(function (lang) {
            _this.logger.info("Init Translations to...", lang);
            if (lang) {
                // update app language // load lang
                _this.switchTranslationsTo(lang);
            }
            else {
                // the en - default_app_lang is loaded by default by Angular!
                _this.translateService.use(LangService_1.DEFAULT_APP_LANGUAGE);
            }
        });
    };
    /**
     * tries to switch to new language, if it doesn't succeed it will switch to #DEFAULT_APP_LANGUAGE.
     * @param {string} lang
     * @returns {string} the given lang or the #DEFAULT_APP_LANGUAGE
     */
    LangService.prototype.switchTranslationsTo = function (lang) {
        this.logger.debug("changing app language to: ", lang);
        var currentLang = this.checkLangOrUseDefault(lang);
        // System.import(`@angular/common/locales/${localeId}.js`) // declare var System;
        // update translation files
        this.translateService.use(currentLang);
        var ngLangLocaleFile = this.langCodesToNgLangResourceMap[currentLang];
        common_1.registerLocaleData(ngLangLocaleFile, currentLang, this.translateLoader.getTranslation(currentLang));
        return currentLang;
    };
    /**
     * updates application language to the new one, meaning
     *  - switching translations
     *  - updates user language
     *
     * @param {string} newLanguage
     * @returns {string}
     */
    LangService.prototype.updateLanguage = function (newLanguage) {
        this.logger.debug("update language to ", newLanguage);
        var currentLang = this.switchTranslationsTo(newLanguage);
        this.storageService.setUserSelectedLanguage(currentLang);
        return currentLang;
    };
    /**
     * if the translation service doesn't support the newLanguage, the #DEFAULT_APP_LANGUAGE - en will be returned
     * @param {string} newLanguage
     * @returns {string}
     */
    LangService.prototype.checkLangOrUseDefault = function (newLanguage) {
        var currentLang = newLanguage;
        // not found fallback to default
        if (this.translateService.getLangs().indexOf(newLanguage) < 0) {
            this.logger.debug("could not find " + newLanguage + ", falling back to default: ", this.translateService.defaultLang);
            currentLang = this.translateService.defaultLang;
        }
        this.logger.debug("check new lang " + newLanguage + " to " + currentLang);
        return currentLang;
    };
    Object.defineProperty(LangService.prototype, "langCodesToNgLangResourceMap", {
        get: function () {
            return this._langCodesToNgLangResourceMap;
        },
        enumerable: true,
        configurable: true
    });
    LangService.DEFAULT_APP_LANGUAGE = 'en';
    LangService = LangService_1 = __decorate([
        core_1.Injectable()
    ], LangService);
    return LangService;
    var LangService_1;
}());
exports.LangService = LangService;
