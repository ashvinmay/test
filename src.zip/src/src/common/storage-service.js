"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Observable_1 = require("rxjs/Observable");
var StorageService = /** @class */ (function () {
    function StorageService(storage, loggerFactory) {
        this.storage = storage;
        this.logger = loggerFactory.getLogger("StorageService");
    }
    StorageService_1 = StorageService;
    StorageService.prototype.getUnAcceptedOfferAlertDisplayed = function () {
        var self = this;
        function getValueInternal() {
            return self.storage.get(StorageService_1.UNACCEPTED_OFFER_ALERT);
        }
        return Observable_1.Observable.fromPromise(this.storage.ready().then(function () {
            return getValueInternal();
        }));
    };
    StorageService.prototype.setUnAcceptedOfferAlertDisplayed = function (displayed) {
        var _this = this;
        return this.storage.set(StorageService_1.UNACCEPTED_OFFER_ALERT, displayed)
            .then(function () {
            _this.logger.debug("Persisted unaccepted_offer_alert=" + displayed);
            return {
                result: true
            };
        });
    };
    StorageService.prototype.getAcceptedOfferAlertDisplayed = function () {
        var self = this;
        function getValueInternal() {
            return self.storage.get(StorageService_1.ACCEPTED_OFFER_ALERT);
        }
        return Observable_1.Observable.fromPromise(this.storage.ready().then(function () {
            return getValueInternal();
        }));
    };
    StorageService.prototype.setAcceptedOfferAlertDisplayed = function (displayed) {
        var _this = this;
        return this.storage.set(StorageService_1.ACCEPTED_OFFER_ALERT, displayed)
            .then(function () {
            _this.logger.debug("Persisted accepted_offer_alert=" + displayed);
            return {
                result: true
            };
        });
    };
    StorageService.prototype.getEditProfileAlertDisplayed = function () {
        var self = this;
        function getValueInternal() {
            return self.storage.get(StorageService_1.EDIT_PROFILE_ALERT);
        }
        return Observable_1.Observable.fromPromise(this.storage.ready().then(function () {
            return getValueInternal();
        }));
    };
    StorageService.prototype.setEditProfileAlertDisplayed = function (displayed) {
        var _this = this;
        return this.storage.set(StorageService_1.EDIT_PROFILE_ALERT, displayed)
            .then(function () {
            _this.logger.debug("Persisted edit_profile_alert=" + displayed);
            return {
                result: true
            };
        });
    };
    StorageService.prototype.getUserSelectedLanguage = function () {
        var self = this;
        function getValueInternal() {
            return self.storage.get(StorageService_1.USER_SELECTED_LANG);
        }
        return Observable_1.Observable.fromPromise(this.storage.ready().then(function () {
            return getValueInternal();
        }));
    };
    StorageService.prototype.setUserSelectedLanguage = function (lang) {
        var _this = this;
        return this.storage.set(StorageService_1.USER_SELECTED_LANG, lang)
            .then(function () {
            _this.logger.debug("Persisted user selected language=" + lang);
            return {
                result: true
            };
        });
    };
    /**
     * Key for displaying not acceptedOffer alert message.
     */
    StorageService.UNACCEPTED_OFFER_ALERT = "unaccepted_offer_alert";
    /**
     * Key for displaying acceptedOffer alert message.
     */
    StorageService.ACCEPTED_OFFER_ALERT = "accepted_offer_alert";
    /**
     * Key for displaying edit profile not allowed alert message.
     */
    StorageService.EDIT_PROFILE_ALERT = "edit_profile_alert";
    /**
     * Key for user selected language. Need to store, in case user log out
     */
    StorageService.USER_SELECTED_LANG = "user_selected_lang";
    StorageService = StorageService_1 = __decorate([
        core_1.Injectable()
    ], StorageService);
    return StorageService;
    var StorageService_1;
}());
exports.StorageService = StorageService;
