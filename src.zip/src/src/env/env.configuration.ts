/**
/**
 * Configuration file for the application. The content is automatically generated when executing either
 *    'ionic server --env=<env>'
 * or something like
 *    'ionic build --prod --env=<env>'
 * Generated on: "2018-10-25T14:08:27.182Z"
 */
import {Injectable} from "@angular/core";

@Injectable()
export class EnvConfiguration {
    env:string = "acc";
    apiBaseUrl: string = "https://webgate.acceptance.ec.europa.eu/esc";
    supportEmail: string = "eu-solidarity-corps@ec.europa.eu";
    reportErrors: boolean = true;
    fakeLogin: boolean = false;
    builtAt: string = "2018-10-25T14:08:27.182Z";

    fakeAuthGetToken4TicketUrl: string = this.apiBaseUrl + "/api/dev/auth/token4Ticket/fake";
    authGetToken4TicketUrl: string = this.apiBaseUrl + "/api/auth/token4Ticket";
    authRemoteServerUrl: string = this.apiBaseUrl + "/api/auth/token4Password";
    authRedirectPath: string = `http://${window.location.hostname}:${window.location.port}/#/ecas-web-callback`;

    postUrl: string = this.apiBaseUrl + "/api/v1/community/post";
    imageUrl: string = this.apiBaseUrl + "/api/v1/community/image";
    getCommunityProfileUrl = this.apiBaseUrl + "/api/v1/community/profile/";
    saveCommunityProfileUrl = this.apiBaseUrl +"/api/v1/community/profile/save";
    getPostSuffix: string = "/posts";
    commentsSuffix: string = "/comments";
    addAvatarUrl: string = this.apiBaseUrl + "/api/v1/community/profile/add/avatar";
    getAvatarUrl: string = this.apiBaseUrl + "/api/v1/community/profile/avatar/";
    getJournalBackgroundImgUrl: string = this.apiBaseUrl + "/api/v1/community/profile/journalBgImage/";
    addJournalBackgroundImgUrl: string = this.apiBaseUrl + "/api/v1/community/profile/add/journalBgImage/";
    deleteAvatarUrl: string = this.apiBaseUrl + "/api/v1/community/profile/delete/avatar/";
    deleteJournalBgImageUrl: string = this.apiBaseUrl + "/api/v1/community/profile/delete/journalBgImage/";

    myProfileUrl: string = this.apiBaseUrl + "/api/v1/myprofile";
    termsAcceptedUrl: string = this.apiBaseUrl +"/api/v1/user/termsaccepted";
    termsConditionUrl?: string = this.apiBaseUrl +"/api/v1/termsconditions";

    updateLangUrl: string = this.apiBaseUrl + "/api/v1/user/language/";

    logErrorUrl: string = this.apiBaseUrl + "/api/v1/clienterror";

    healthUrl : string = this.apiBaseUrl + "/health";

    publicShareUrl : string = this.apiBaseUrl + "/public/share/";

    notificationsUrl : string = this.apiBaseUrl + "/api/v1/notifications/";
    unreadnotificationscountUrl : string = this.apiBaseUrl + "/api/v1/notifications/count/unread";
    registerDeviceUrl : string = this.apiBaseUrl + "/api/v1/device/register";

    // search
    usersSearchUrl: string = this.apiBaseUrl + "/api/v1/search/" + "users";

    // FCM sender ID to be used on Android devices
    fcmAndroidSenderId:string = '${fcmAndroidSenderId}';

    // Analytics
    analyticsUrl: string = this.apiBaseUrl + "/api/v1/analytics";

	// Activities
    activitiesTopicsUrl: string = this.apiBaseUrl + "/api/v1/activities/topics";
    activitiesUrl: string = this.apiBaseUrl + "/api/v1/activities";
    activityUrl: string = this.apiBaseUrl + "/api/v1/activities/";

}