"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Class responsible for logging to the console.
 */
var Logger = /** @class */ (function () {
    /**
     * @param {string} name The name to be printed as a prefix for all messages logged by this new instance.
     * @param {boolean} prodMode Enable/ disable the production mode. When set to true only WARN and ERROR messages are
     *        to be logged. Default is false.
     */
    function Logger(name, prodMode) {
        this.prodMode = false;
        this.name = name;
        if (prodMode) {
            this.prodMode = prodMode;
        }
    }
    Logger.prototype.debug = function (message) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        if (this.prodMode) {
            return;
        }
        if (optionalParams) {
            console.debug.apply(console, [this.getMessage(message)].concat(optionalParams));
        }
        else {
            console.debug.apply(console, [this.getMessage(message)]);
        }
    };
    Logger.prototype.info = function (message) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        if (this.prodMode) {
            return;
        }
        if (optionalParams) {
            console.info.apply(console, [this.getMessage(message)].concat(optionalParams));
        }
        else {
            console.info.apply(console, [this.getMessage(message)]);
        }
    };
    Logger.prototype.warn = function (message) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        if (optionalParams) {
            console.warn.apply(console, [this.getMessage(message)].concat(optionalParams));
        }
        else {
            console.warn.apply(console, [this.getMessage(message)]);
        }
    };
    Logger.prototype.error = function (message) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        if (optionalParams) {
            console.error.apply(console, [this.getMessage(message)].concat(optionalParams));
        }
        else {
            console.error.apply(console, [this.getMessage(message)]);
        }
    };
    Logger.prototype.getMessage = function (message) {
        if (message) {
            return this.name + " -- " + message;
        }
        return this.name + " -- ";
    };
    return Logger;
}());
exports.Logger = Logger;
